#!/usr/bin/env python3
# ============================================================
# FinMLLM / eval_cloze.py
# Cloze-style evaluation: compare the log-likelihood of a single label token
# instead of trusting free-form generation. Works on BASE models too.
# 完形填空式评测：直接比较标签词的 log-likelihood，不依赖自由生成。
# 对 base 模型也有效。
#
# Author : Raymond Xiaohu Fan
# Note   : A base model cannot follow instructions, but it can still rank tokens.
#          base 模型不会听指令，但它仍然会给 token 排序。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/eval_cloze.py --dataset fpb --base_only --limit 200
#   python scripts/eval_cloze.py --dataset fpb --adapter ckpts_c/bank_r8 --limit 200
# ============================================================
import os, sys, json, argparse, time
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)
LABELS = ["negative", "neutral", "positive"]

PROMPT = "Sentence: {}\nSentiment:"




def _norm_label(raw):
    """Map numeric or mixed labels onto negative/neutral/positive.
    把数字或混合形式的标签统一到 negative/neutral/positive。
    FiQA-SA 用 -1/0/1，FPB 用单词 —— 不归一化就会全部过滤掉。"""
    s = str(raw).strip().lower()
    table = {
        "-1": "negative", "-1.0": "negative", "0": "neutral", "0.0": "neutral",
        "1": "positive", "1.0": "positive",
        "neg": "negative", "neu": "neutral", "pos": "positive",
        "negative": "negative", "neutral": "neutral", "positive": "positive",
    }
    return table.get(s, s)

def _holdout_split(items, holdout=0.2, seed=42):
    """Deterministic 80/20 split shared by training and evaluation.
    训练与评测共用的确定性 80/20 划分 —— FPB 的 AllAgree 是 50Agree 的子集，
    只按原始 split 分仍会泄漏，必须统一重划。
    """
    import random as _r
    idx = list(range(len(items)))
    _r.Random(seed).shuffle(idx)
    cut = int(len(items) * (1 - holdout))
    tr = [items[i] for i in idx[:cut]]
    te = [items[i] for i in idx[cut:]]
    return tr, te

def load_rows(dataset, limit, seed=42, binary=False, split="test", holdout=0.2):
    """binary=True drops 'neutral' (ambiguous, 59% of FPB) and keeps pos/neg.
    binary=True 去掉歧义最大的 neutral（占 FPB 约 59%），只留正负两类。"""
    path = os.path.join(ROOT, "data", "unified", f"{dataset}.jsonl")
    keep = ["negative", "positive"] if binary else LABELS
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            t = str(r.get("text", "")).strip()
            lab = _norm_label(r.get("label", ""))
            if t and lab in keep:
                rows.append((t, lab))
    tr, te = _holdout_split(rows, holdout, seed)
    rows = te if split == "test" else tr
    if limit and len(rows) > limit:
        rng = np.random.RandomState(seed)
        idx = rng.choice(len(rows), limit, replace=False)
        rows = [rows[i] for i in idx]
    return rows


def build(base, adapter, device="cuda"):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                             bnb_4bit_use_double_quant=True,
                             bnb_4bit_compute_dtype=torch.bfloat16)
    tok = AutoTokenizer.from_pretrained(base, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        base, quantization_config=bnb, device_map={"": 0}, trust_remote_code=True)
    if adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, adapter)
    model.eval()
    return tok, model


def label_token_ids(tok):
    """First token id of each label, prefixed with a space.
    每个标签词（带前导空格）的首 token id。"""
    ids = {}
    for lab in LABELS:
        for variant in (" " + lab, lab):
            t = tok(variant, add_special_tokens=False)["input_ids"]
            if t:
                ids[lab] = t[0]
                break
    return ids


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="fpb", choices=["fpb", "fiqa_sa", "tfns"])
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--base_only", action="store_true")
    ap.add_argument("--base", default=os.environ.get("BASE_MODEL", "/root/autodl-tmp/models/Qwen2.5-3B"))
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--binary", action="store_true",
                    help="pos/neg only, drops neutral / 二分类，去掉中性")
    ap.add_argument("--classes", type=int, default=None, choices=[2, 3],
                    help="2 or 3 classes, overrides --binary / 覆盖 --binary")
    ap.add_argument("--split", default="test",
                    help="test|train / 评测用哪一份（默认 test）")
    ap.add_argument("--holdout", type=float, default=0.2, help="test ratio / 留出比例")
    ap.add_argument("--calibrate", action="store_true", default=True,
                    help="subtract null-context logits to remove token priors / 减去空上下文基线，消除 token 先验")
    ap.add_argument("--out", default=None)
    ap.add_argument("--save-preds", action="store_true",
                    help="save per-sample predictions for McNemar tests / 保存逐样本预测，供 McNemar 配对检验")
    args = ap.parse_args()

    import torch
    binary = args.binary if args.classes is None else (args.classes == 2)
    rows = load_rows(args.dataset, args.limit, binary=binary,
                     split=args.split, holdout=args.holdout)
    global LABELS
    if binary:
        LABELS = ["negative", "positive"]
    print("=" * 72)
    print(f" CLOZE EVAL | {args.dataset} | n={len(rows)} | adapter={args.adapter or '(base)'}")
    print("=" * 72)
    if not rows:
        print("❌ no usable rows")
        return 2

    tok, model = build(args.base, None if args.base_only else args.adapter)
    ids = label_token_ids(tok)
    print("label token ids:", ids)
    if len(set(ids.values())) < len(LABELS):
        print("⚠️  标签首 token 有重复，结果会失真；改用序列 logprob 更稳")

    # Null-context baseline: without this, "negative" (id 8225) always beats
    # "positive" (id 6785) purely because of token priors — that is exactly the
    # all-negative collapse we just saw.
    # 空上下文基线：不减去它，"negative" 的 token 先验永远压过 "positive"，
    # 就会复现刚才"全猜 negative"的塌缩。
    null_logits = None
    if args.calibrate:
        null_enc = tok("Sentence: \nSentiment:", return_tensors="pt").to("cuda")
        with torch.no_grad():
            null_logits = model(**null_enc).logits[0, -1].clone()
        print("calibration: ON (subtracting null-context logits)")

    conf = {a: {b: 0 for b in LABELS} for a in LABELS}
    preds = []          # per-sample records, index-aligned across runs / 逐样本记录，跨运行按 index 对齐
    t0 = time.time()
    for i, (text, gold) in enumerate(rows):
        prompt = PROMPT.format(text[:800])
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to("cuda")
        with torch.no_grad():
            logits = model(**enc).logits[0, -1]
        scores = {}
        for lab in LABELS:
            v = float(logits[ids[lab]].item())
            if null_logits is not None:
                v -= float(null_logits[ids[lab]].item())
            scores[lab] = v
        pred = max(scores, key=scores.get)
        conf[gold][pred] += 1
        if args.save_preds:
            preds.append({"i": i, "gold": gold, "pred": pred,
                          "ok": int(pred == gold)})
        if (i + 1) % 50 == 0:
            acc = sum(conf[a][a] for a in LABELS) / (i + 1)
            print(f"  {i+1}/{len(rows)}  running_acc={acc:.3f}  {time.time()-t0:.0f}s", flush=True)

    correct = sum(conf[a][a] for a in LABELS)
    acc = correct / len(rows)
    print("\n" + "-" * 72)
    print(f" accuracy = {acc:.4f}  ({correct}/{len(rows)})  dur={time.time()-t0:.0f}s")
    print(f"{'gold\\pred':<12}" + "".join(f"{b:>10}" for b in LABELS))
    for a in LABELS:
        print(f"{a:<12}" + "".join(f"{conf[a][b]:>10}" for b in LABELS))

    out = {"dataset": args.dataset, "adapter": args.adapter, "base_only": args.base_only,
           "binary": args.binary, "labels": LABELS,
           "n": len(rows), "accuracy": acc, "confusion": conf, "mode": "cloze",
           "dur_sec": round(time.time() - t0, 1)}
    if args.save_preds:
        out["preds"] = preds
    p = args.out or os.path.join(REP, f"cloze_{args.dataset}_{os.path.basename(args.adapter or 'base')}.json")
    json.dump(out, open(p, "w"), indent=2, ensure_ascii=False)
    print(f"💾 saved -> {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
