#!/usr/bin/env python3
# ============================================================
# FinMLLM / make_docx_frl.py
# FRL（Elsevier short letter）版 docx：单栏、12pt、双倍行距、2 表 1 图。
# Elsevier short-letter layout: single column, 12 pt, double spaced, 2 tables 1 figure.
#
# 与长文版的差别：没有行号、没有小节编号之外的层级、图只有一张、
# Highlights 单独列出（Elsevier 投稿系统的硬性要求）。
# Differences from the full paper: no line numbers, one figure only, and a
# separate Highlights block, which Elsevier requires at submission.
#
# Author : Raymond Xiaohu Fan
# ============================================================
import os, re, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
# 2026-11-10 改：v1（30_）是"全面缩减"版，v2（31_）是"重点突出"重构版。
# 以后默认指向 v2；要回v1就 SRC=... make_docx_frl.py 覆盖环境变量。
# Switched the default to v2 (the focused rewrite). Override via the SRC env var.
SRC = os.environ.get("SRC", os.path.join(PROJ, "31_FRL_v2_focused.md"))
FIG = os.path.join(PROJ, "outputs", "figs", "frl_fig1_ratio_vs_cost.png")
OUT = os.path.join(PROJ, "outputs", "FinMLLM_FRL_short_letter.docx")

TABLE1 = {
    "no": 1,
    "cap": "Compression–accuracy frontier on the Financial PhraseBank. Binary task n = 394 held-out "
           "items; ternary task n = 968. Values are the reference seed (split seed 42, training seed 42); "
           "three-seed means for ranks 16 and 1 are given in the text. Ranks correspond to a compression ratio "
           "of 1×, 2×, 4×, 8× and 16×. Paired McNemar tests of rank 1 against rank 16 are reported "
           "in the text.",
    "head": ["Rank", "Size (MB)", "CR", "Binary acc.", "Ternary acc."],
    "rows": [
        ["16", "115.0", "1×",  "0.9873", "0.7831"],
        ["8",  "57.1",  "2×",  "0.9898", "0.7831"],
        ["4",  "28.5",  "4×",  "0.9898", "0.7800"],
        ["2",  "14.3",  "8×",  "0.9924", "0.7810"],
        ["1",  "7.1",   "16×", "0.9898", "0.8161"],
    ],
}

TABLE2 = {
    "no": 2,
    "cap": "Effective rank against a Gaussian baseline of identical shape. Noise is the closed-form "
           "stable rank kd/(√k+√d)² applied per layer. Ratio is stable rank divided by that baseline.",
    "head": ["Model", "Task", "r", "Stable", "PR", "eRank", "n90", "Noise", "Ratio"],
    "rows": [
        ["3B", "binary",  "16", "1.98", "8.50",  "11.40", "6.46",  "14.08", "0.141"],
        ["3B", "ternary", "16", "1.86", "8.02",  "11.04", "6.02",  "14.08", "0.133"],
        ["3B", "FiQA",    "16", "2.28", "9.42",  "12.04", "7.40",  "14.08", "0.163"],
        ["3B", "binary",  "64", "2.33", "22.02", "37.06", "13.89", "50.09", "0.047"],
        ["3B", "ternary", "64", "2.50", "23.90", "38.42", "16.24", "50.09", "0.050"],
        ["7B", "binary",  "16", "1.94", "8.25",  "11.20", "6.22",  "14.51", "0.134"],
        ["7B", "ternary", "16", "1.74", "7.54",  "10.67", "5.42",  "14.51", "0.120"],
        ["7B", "binary",  "64", "2.08", "20.73", "36.46", "13.20", "52.96", "0.039"],
        ["7B", "ternary", "64", "1.95", "18.87", "33.98", "12.25", "52.96", "0.037"],
    ],
}


def base_font(doc):
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    pf.line_spacing = 2.0
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)


def page_number(par):
    run = par.add_run()
    f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
    run._r.append(f1); run._r.append(it); run._r.append(f2)
    run.font.size = Pt(10)


def md_runs(par, text, size=12):
    for tok in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", text):
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**") and len(tok) > 4:
            r = par.add_run(tok[2:-2]); r.bold = True
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            r = par.add_run(tok[1:-1]); r.italic = True
        else:
            r = par.add_run(tok)
        r.font.size = Pt(size)
        r.font.name = "Times New Roman"


def booktabs(table):
    tblPr = table._tbl.tblPr
    for e in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(e)
    b = OxmlElement("w:tblBorders")
    for edge, sz in [("top", 12), ("bottom", 12), ("left", 0),
                     ("right", 0), ("insideH", 0), ("insideV", 0)]:
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single" if sz else "none")
        el.set(qn("w:sz"), str(sz)); el.set(qn("w:space"), "0"); el.set(qn("w:color"), "000000")
        b.append(el)
    tblPr.insert_element_before(b, "w:shd", "w:tblLayout", "w:tblCellMar",
                                "w:tblLook", "w:tblCaption", "w:tblDescription")
    for cell in table.rows[0].cells:
        tcPr = cell._tc.get_or_add_tcPr()
        for e in tcPr.findall(qn("w:tcBorders")):
            tcPr.remove(e)
        tb = OxmlElement("w:tcBorders")
        bt = OxmlElement("w:bottom")
        bt.set(qn("w:val"), "single"); bt.set(qn("w:sz"), "6"); bt.set(qn("w:color"), "000000")
        tb.append(bt)
        tcPr.insert_element_before(tb, "w:shd", "w:noWrap", "w:tcMar",
                                   "w:textDirection", "w:tcFitText", "w:vAlign")


def add_table(doc, spec):
    cap = doc.add_paragraph()
    cap.paragraph_format.space_before = Pt(12)
    cap.paragraph_format.space_after = Pt(4)
    cap.paragraph_format.line_spacing = 1.0
    cap.paragraph_format.keep_with_next = True
    r = cap.add_run(f"Table {spec['no']}. "); r.bold = True; r.font.size = Pt(9)
    r2 = cap.add_run(spec["cap"]); r2.font.size = Pt(9)

    t = doc.add_table(rows=1, cols=len(spec["head"]))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(spec["head"]):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = 1.0
        rr = p.add_run(h); rr.bold = True; rr.font.size = Pt(8.5)
        rr.font.name = "Times New Roman"
    for row in spec["rows"]:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing = 1.0
            rr = p.add_run(v); rr.font.size = Pt(8.5)
            rr.font.name = "Times New Roman"
    booktabs(t)
    for row in t.rows:
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(10)
    sp.paragraph_format.line_spacing = 1.0


def add_figure(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.keep_with_next = True
    if os.path.exists(FIG):
        p.add_run().add_picture(FIG, width=Cm(15.0))
    else:
        r = p.add_run("[MISSING FIGURE]"); r.font.color.rgb = RGBColor(0xC0, 0, 0)
    cp = doc.add_paragraph()
    cp.paragraph_format.space_after = Pt(16)
    cp.paragraph_format.line_spacing = 1.0
    r = cp.add_run("Figure 1. "); r.bold = True; r.font.size = Pt(9)
    r2 = cp.add_run("The rank ratio predicts what compression costs. Each point is a task; the horizontal "
                    "axis is the adapter's effective rank divided by a Gaussian baseline of identical shape, "
                    "the vertical axis the accuracy change after sixteenfold truncation. The three tasks "
                    "order identically on both axes.")
    r2.font.size = Pt(9)


def main():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.5)
    sec.top_margin = sec.bottom_margin = Cm(2.5)
    base_font(doc)
    fp = sec.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    page_number(fp)

    lines = open(SRC, encoding="utf-8").read().split("\n")
    i = 0
    cur = ""
    fig_done = False
    tbl_done = set()

    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln.strip() or ln.strip() in ("---", "***", "___"):
            i += 1; continue

        mh = re.match(r"^(#{1,3})\s+(.*)$", ln)
        if mh:
            level = len(mh.group(1))
            txt = mh.group(2).strip()
            if txt.lower().startswith("abstract"):
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(14)
                p.paragraph_format.space_after = Pt(4)
                p.paragraph_format.line_spacing = 1.0
                r = p.add_run("Abstract"); r.bold = True; r.font.size = Pt(12)
            elif txt.lower().startswith("highlight"):
                cur = "Highlights"
                doc.add_page_break()
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(8)
                p.paragraph_format.line_spacing = 1.0
                r = p.add_run("Highlights"); r.bold = True; r.font.size = Pt(13)
            elif txt.lower().startswith("references"):
                cur = "References"
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(18)
                p.paragraph_format.space_after = Pt(6)
                p.paragraph_format.line_spacing = 1.0
                p.paragraph_format.keep_with_next = True
                r = p.add_run("References"); r.bold = True; r.font.size = Pt(13)
            elif level == 2:
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(12)
                p.paragraph_format.space_after = Pt(3)
                p.paragraph_format.line_spacing = 1.0
                p.paragraph_format.keep_with_next = True
                r = p.add_run(txt); r.bold = True; r.italic = True; r.font.size = Pt(12)
                cur = txt
            elif re.match(r"^\d+\.\s", txt):
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(14)
                p.paragraph_format.space_after = Pt(4)
                p.paragraph_format.line_spacing = 1.0
                p.paragraph_format.keep_with_next = True
                r = p.add_run(txt); r.bold = True; r.font.size = Pt(12)
                cur = txt
            else:
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(8)
                p.paragraph_format.line_spacing = 1.0
                r = p.add_run(txt); r.bold = True; r.font.size = Pt(15)
            i += 1; continue

        # Highlights 小标题（md 里是粗体行）
        if ln.strip() in ("**Highlights**", "**Highlights:**", "Highlights"):
            cur = "Highlights"
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.keep_with_next = True
            r = p.add_run("Highlights"); r.bold = True; r.font.size = Pt(12)
            i += 1; continue

        # References 条目
        m = re.match(r"^(\d+)\.\s+(.*)$", ln.strip())
        if cur == "References" and m:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.8)
            p.paragraph_format.first_line_indent = Cm(-0.8)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.space_after = Pt(3)
            md_runs(p, f"{m.group(1)}. {m.group(2)}", size=9)
            i += 1; continue

        # Highlights 条目
        if cur == "Highlights" and ln.strip().startswith("- "):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.6)
            p.paragraph_format.first_line_indent = Cm(-0.4)
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.space_after = Pt(3)
            md_runs(p, "\u2022 " + ln.strip()[2:], size=11)
            i += 1; continue

        # Keywords / JEL 行：悬挂、不缩进
        if re.match(r"^\*\*(Keywords|JEL)[:：]?\*\*", ln.strip()):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.line_spacing = 1.0
            md_runs(p, ln.strip())
            i += 1; continue

        # 正文段落
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0.75)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        md_runs(p, ln.strip())

        # 图表插入点
        if not ("T", 1) in tbl_done and re.search(r"Table 1 reports", ln):
            add_table(doc, TABLE1); tbl_done.add(("T", 1))
        if not ("T", 2) in tbl_done and re.search(r"Table 2 reports", ln):
            add_table(doc, TABLE2); tbl_done.add(("T", 2))
        if not fig_done and re.search(r"The ordering is the finding", ln):
            add_figure(doc); fig_done = True
        i += 1

    cp = doc.core_properties
    cp.title = "Compressing financial sentiment adapters: effective rank, not spectral energy, sets the limit"
    cp.author = "Xiaohu Fan"
    cp.subject = "Finance Research Letters submission"

    doc.save(OUT)
    print(f"✅ {OUT}")
    print(f"   {os.path.getsize(OUT)/1024:.0f} KB | tables {sorted(x[1] for x in tbl_done)} | figure {fig_done}")


if __name__ == "__main__":
    sys.exit(main())
