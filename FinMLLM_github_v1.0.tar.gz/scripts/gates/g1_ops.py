#!/usr/bin/env python3
# ============================================================
# FinMLLM / g1_ops.py
# G1 operator self-check: DCT orthogonality, projection, isometry, Gamma_D.
# G1 算子自检：DCT 正交性、投影重建、保距性、Γ_D。
#
# Author : Raymond Xiaohu Fan
# Note   : If the math is wrong, everything after is decoration. / 数学错了，后面都是装饰。
# Updated: 2026-10-19
# ============================================================

"""G1 · 算子自检（纯 numpy/scipy，无卡可跑）。

验证：DCT 正交性、Π_θ 投影-重建、频谱保距性、Γ_D 谱轮廓、跨域 KL。
判定：各项误差 < 1e-8。
"""
import numpy as np
from scipy.fftpack import dct, idct

RTOL = 1e-8
ok_all = True

def report(name, err, tol=RTOL):
    global ok_all
    ok = err < tol
    ok_all &= ok
    print(f"{'✅' if ok else '❌'} {name:<38} err={err:.3e}  (tol={tol:.0e})")

def dct2(x):
    return dct(dct(x.T, norm="ortho").T, norm="ortho")

def idct2(X):
    return idct(idct(X.T, norm="ortho").T, norm="ortho")

def project(X, ratio):
    """Π_θ：保留能量最大的 ratio 比例系数，其余置零，再重建。"""
    C = dct2(X)
    flat = np.abs(C).ravel()
    k = max(1, int(len(flat) * ratio))
    thr = np.partition(flat, -k)[-k]
    mask = np.abs(C) >= thr
    return idct2(C * mask), mask, C

def gamma_profile(X, n_bands=3):
    """Γ_D：把 2D-DCT 能量按频率半径分带，归一化为概率分布。"""
    C = dct2(X)
    E = np.abs(C) ** 2
    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    r = np.sqrt((yy / max(h - 1, 1)) ** 2 + (xx / max(w - 1, 1)) ** 2)
    r = r / r.max()
    edges = np.linspace(0, 1, n_bands + 1)
    prof = np.array([E[(r >= edges[i]) & (r <= edges[i + 1] + 1e-12)].sum() for i in range(n_bands)])
    s = prof.sum()
    return prof / s if s > 0 else prof

def kl(p, q, eps=1e-12):
    p = np.asarray(p) + eps; q = np.asarray(q) + eps
    p = p / p.sum(); q = q / q.sum()
    return float(np.sum(p * np.log(p / q)))

if __name__ == "__main__":
    print("=" * 70)
    print("G1 · 算子自检")
    print("=" * 70)
    rng = np.random.default_rng(42)

    # 1) DCT orthogonality: D @ D.T should equal the identity
    # 1) DCT 正交性：D 矩阵 D D^T = I
    n = 64
    from scipy.fftpack import dct as _dct
    D = np.zeros((n, n))
    for i in range(n):
        e = np.zeros(n); e[i] = 1.0
        D[:, i] = _dct(e, norm="ortho")
    report("DCT 正交性 ||DDᵀ−I||_F", float(np.linalg.norm(D @ D.T - np.eye(n))))

    # 2) Projection and reconstruction
    # 2) 投影-重建
    X = rng.standard_normal((64, 64))
    Xr, mask, C = project(X, 1.0)
    report("全系数重建 ||Π(x)−x||_F/||x||_F", float(np.linalg.norm(Xr - X) / np.linalg.norm(X)))

    # 3) Spectral isometry: an orthogonal transform preserves the Frobenius norm
    # 3) 频谱保距性（正交变换保范数）
    ref = dct2(X)
    report("保距性 |‖DCT(x)‖−‖x‖|/‖x‖", abs(np.linalg.norm(ref) - np.linalg.norm(X)) / np.linalg.norm(X))

    # 4) Monotone truncation distortion: a smaller ratio must give a larger error
    # 4) 截断失真单调性（ratio 越小误差越大）
    errs = []
    for r in (0.01, 0.05, 0.2, 0.5, 1.0):
        Xr, _, _ = project(X, r)
        errs.append(np.linalg.norm(Xr - X) / np.linalg.norm(X))
    mono = all(errs[i] >= errs[i + 1] - 1e-9 for i in range(len(errs) - 1))
    print(f"{'✅' if mono else '❌'} 截断失真单调性                     ratios={['%.2f'%e for e in errs]}")
    ok_all &= mono

    # 5) Gamma_D profiles and cross-domain KL divergence
    # 5) Γ_D 与跨域 KL
    A = project(rng.standard_normal((64, 64)), 0.3)[0]
    B = project(rng.standard_normal((64, 64)) * 0.01, 0.3)[0]
    pa, pb = gamma_profile(A), gamma_profile(B)
    k = kl(pa, pb)
    print(f"ℹ️  Γ_D(A)={np.round(pa,4)}  Γ_D(B)={np.round(pb,4)}  KL(A||B)={k:.4f}")
    report("Γ_D 归一化 Σp=1", float(abs(pa.sum() - 1.0)))
    ok_kl = k > 0
    print(f"{'✅' if ok_kl else '❌'} 跨域 KL > 0                        KL={k:.4f}")
    ok_all &= ok_kl

    print("-" * 70)
    print("🎉 G1 PASS" if ok_all else "⚠️ G1 FAIL — 算子地基有问题，先修再往下跑")
    raise SystemExit(0 if ok_all else 3)
