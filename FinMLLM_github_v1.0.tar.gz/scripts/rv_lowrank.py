#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_lowrank.py
# 快速 rank-k 截断：QR-core 技巧，不重建稠密矩阵。
# Fast rank-k truncation via QR-core. Never materialises the dense update.
#
# 为什么快：
#   ΔW = B @ A，形状 [out, in]。直接 SVD 是 O(out*in*min(out,in))。
#   但 A 是 [r, in]、B 是 [out, r]，r 只有 16。
#   先做 QR 把两边压到 r 维，只需对 r×r 的小矩阵做 SVD。
#
#   B = Q_B R_B        Q_B:[out,r]  R_B:[r,r]
#   A^T = Q_A R_A      Q_A:[in,r]   R_A:[r,r]
#   ΔW = Q_B (R_B R_A^T) Q_A^T
#   SVD(R_B R_A^T) = U_m S V_m^T   -> 前 k 个方向
#   B_new = Q_B U_m[:,:k] sqrt(S[:k])
#   A_new = sqrt(S[:k]) V_m[:,:k]^T Q_A^T
#
# Author : Raymond Xiaohu Fan
# Usage:
#   python scripts/rv_lowrank.py --src ckpts_rv/bin_r16_s123 --rank 1 --out ckpts_rv/bin_r1_s123
# ============================================================
import os, sys, json, argparse, shutil
import numpy as np
from safetensors.torch import load_file, save_file
import torch


def truncate_pair(A, B, k):
    """A:[r,in]  B:[out,r]  ->  rank-k 的 (A_new, B_new)，保持 ΔW = B@A 最优近似。"""
    r = A.shape[0]
    k = min(k, r)
    A32 = A.astype(np.float32)
    B32 = B.astype(np.float32)

    # QR 压到 r 维 / compress both sides to r dims
    Q_B, R_B = np.linalg.qr(B32)          # Q_B:[out,r] R_B:[r,r]
    Q_A, R_A = np.linalg.qr(A32.T)        # Q_A:[in,r]  R_A:[r,r]

    M = R_B @ R_A.T                       # [r,r] 小矩阵
    U_m, S, V_mt = np.linalg.svd(M, full_matrices=False)

    B_new = (Q_B @ U_m[:, :k]) * np.sqrt(S[:k])          # [out,k]
    A_new = np.sqrt(S[:k])[:, None] * (V_mt[:k] @ Q_A.T) # [k,in]
    return A_new.astype(np.float32), B_new.astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--rank", type=int, required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    src_st = os.path.join(a.src, "adapter_model.safetensors")
    src_cf = os.path.join(a.src, "adapter_config.json")
    assert os.path.exists(src_st), f"缺 {src_st}"
    sd = load_file(src_st)
    cfg = json.load(open(src_cf, encoding="utf-8"))

    old_r = cfg.get("r") or cfg.get("lora_alpha")
    alpha = cfg.get("lora_alpha", old_r)
    k = min(a.rank, int(old_r))

    keymap = {}
    for key in list(sd.keys()):
        if "lora_A" in key:
            kb = key.replace("lora_A", "lora_B")
            if kb in sd:
                keymap[key] = kb

    new_sd = {k2: v for k2, v in sd.items()
              if "lora_A" not in k2 and "lora_B" not in k2}

    errs = []
    for ka, kb in keymap.items():
        A = sd[ka].float().numpy()
        B = sd[kb].float().numpy()
        A2, B2 = truncate_pair(A, B, k)
        new_sd[ka] = torch.from_numpy(np.ascontiguousarray(A2))
        new_sd[kb] = torch.from_numpy(np.ascontiguousarray(B2))
        # 自检：重建误差 / 原范数
        full = B @ A
        approx = B2 @ A2
        errs.append(np.linalg.norm(full - approx) / (np.linalg.norm(full) + 1e-12))

    os.makedirs(a.out, exist_ok=True)
    save_file({k2: v.contiguous() for k2, v in new_sd.items()},
              os.path.join(a.out, "adapter_model.safetensors"))

    cfg["r"] = k
    cfg["lora_alpha"] = k * alpha / old_r     # 保持 scaling = alpha/r 不变
    json.dump(cfg, open(os.path.join(a.out, "adapter_config.json"), "w"),
              indent=2, ensure_ascii=False)
    for extra in ("tokenizer_config.json", "special_tokens_map.json",
                  "tokenizer.json", "vocab.json", "merges.txt"):
        p = os.path.join(a.src, extra)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(a.out, extra))

    sz = os.path.getsize(os.path.join(a.out, "adapter_model.safetensors")) / 1024**2
    print(f"✅ {a.out}  r={k}  alpha={cfg['lora_alpha']:.2f}  "
          f"{sz:.1f}MB  矩阵 {len(keymap)} 个")
    print(f"   重建相对误差: mean={np.mean(errs):.5f} max={np.max(errs):.5f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
