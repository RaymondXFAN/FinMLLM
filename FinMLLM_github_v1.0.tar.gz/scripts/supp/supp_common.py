#!/usr/bin/env python3
# ============================================================
# FinMLLM / supp / supp_common.py
# Shared helpers for the supplementary experiments (S1-S5 / A1-A4).
# 补充实验（S1–S5 / A1–A4）的共享工具。
#
# Author : Raymond Xiaohu Fan
# Note   : Three different ranks, one paper. Do not mix them up.
#          三个"秩"、一篇论文，千万别混着写。
#             rank_cfg  = a hyper-parameter (hard ceiling) / 配置秩，超参，硬上限
#             eff_rank  = a measurement of the SVD spectrum / 有效秩，谱的测量值
#             int_dim   = a property of the optimisation landscape / 内在维度，优化景观属性
# Updated: 2026-10-25
# ============================================================
import os, sys, json, glob, time, math, random
import numpy as np

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(PROJ, "outputs", "reports")
LOGS = os.path.join(PROJ, "outputs", "logs")
for d in (REP, LOGS):
    os.makedirs(d, exist_ok=True)

_T0 = time.time()


def probe(msg, level="STEP"):
    """Timestamped probe line so a 3-hour background run stays traceable.
    带时间戳的探针输出 —— 三个小时的后台任务也能一眼 trace 到哪里断了。"""
    el = time.time() - _T0
    print(f"[{time.strftime('%H:%M:%S')}] [+{el:7.1f}s] [{level}] {msg}", flush=True)


def gpu_snapshot():
    """Print a one-line GPU snapshot (free MiB / utilisation). Cheap and always on.
    打印一行显存快照，便宜、永远开着。"""
    try:
        import subprocess
        q = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.used,memory.total,utilization.gpu",
             "--format=csv,noheader,nounits"], text=True, timeout=10).strip().splitlines()[0]
        used, total, util = [x.strip() for x in q.split(",")]
        probe(f"GPU {used}/{total} MiB used, util {util}%", "GPU")
        return int(total) - int(used)
    except Exception as e:
        probe(f"gpu_snapshot failed: {e}", "WARN")
        return -1


def gpu_free_mib():
    try:
        import subprocess
        q = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.free", "--format=csv,noheader,nounits"],
            text=True, timeout=10).strip().splitlines()[0]
        return int(float(q))
    except Exception:
        return -1


# ------------------------------------------------------------
# Adapter I/O / adapter 读写
# ------------------------------------------------------------
def find_adapters(roots=None):
    """Walk the project and return every directory that holds a LoRA adapter.
    扫全项目，返回所有含 LoRA adapter 的目录。"""
    roots = roots or [PROJ]
    out = []
    for root in roots:
        for cfg in glob.glob(os.path.join(root, "**", "adapter_config.json"), recursive=True):
            d = os.path.dirname(cfg)
            if glob.glob(os.path.join(d, "*.safetensors")):
                out.append(d)
    return sorted(set(out))


def load_lora_pairs(adapter_dir):
    """Return (cfg, [(key, A, B)]) with A:(r,in) B:(out,r) as float32 numpy.
    返回配置与所有 (A,B) 对，A:(r,in)，B:(out,r)。"""
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files:
        raise FileNotFoundError(f"no safetensors in {adapter_dir}")
    sd = load_file(files[0])
    cfg = {}
    p = os.path.join(adapter_dir, "adapter_config.json")
    if os.path.exists(p):
        cfg = json.load(open(p))
    pairs = []
    for kA in sorted(k for k in sd if "lora_A" in k):
        kB = kA.replace("lora_A", "lora_B")
        if kB not in sd:
            continue
        A = sd[kA].float().cpu().numpy()
        B = sd[kB].float().cpu().numpy()
        pairs.append((kA, A, B))
    return cfg, pairs


def lora_scale(cfg):
    """Effective LoRA scale alpha/r. / LoRA 的有效缩放 alpha/r。"""
    r = cfg.get("r") or cfg.get("lora_r") or 16
    alpha = cfg.get("lora_alpha") or 2 * r
    return float(alpha) / float(r), int(r)


def singular_values(A, B, scale, top=None):
    """Singular values of Delta-W = scale * B @ A WITHOUT forming the d x d matrix.
    不显式构造 d×d 矩阵就拿到 Delta-W 的奇异值。

    Why this trick matters / 为什么要这个技巧:
      Delta-W is rank<=r by construction, so a full 2048x2048 SVD is pure waste.
      Delta-W 的秩按构造不超过 r，对 2048×2048 做完整 SVD 纯属浪费。
      QR on the thin factors gives an r×r problem instead -> ~500x faster.
      对瘦因子做 QR，问题降到 r×r，快约 500 倍。
      (Same trick as LoRA-Squeeze, arXiv:2602.10993.)
    """
    r = A.shape[0]
    r = min(r, top) if top else r
    Qa, Ra = np.linalg.qr(A.T)          # A.T: (in, r) -> Ra: (r, r)
    Qb, Rb = np.linalg.qr(B)            # B  : (out, r) -> Rb: (r, r)
    core = Rb @ Ra.T                    # (r, r)
    s = np.linalg.svd(core, compute_uv=False)
    return np.maximum(s * scale, 0.0)


# ------------------------------------------------------------
# Effective-rank metrics / 有效秩度量（三种不同阶，缺一不可）
# ------------------------------------------------------------
def rank_metrics(s):
    """Three metrics of DIFFERENT Rényi order + energy-rank. Never report only one.
    三种不同 Rényi 阶的度量 + 能量秩。只报一个数会被指责度量挑选。

      stable rank  = ||W||_F^2 / ||W||_2^2      (order inf, favours top directions)
      participation= (sum s^2)^2 / sum s^4      (order 2)
      erank        = exp(-sum p log p), p=s^2/sum s^2   (entropy)
      n90          = #singular values for 90% energy    (counting)
    """
    s = np.asarray(s, dtype=np.float64)
    s = s[s > 0]
    if s.size == 0:
        return None
    e = s ** 2
    tot = e.sum()
    p = e / tot
    stable = float(tot / (s[0] ** 2))
    pr = float(1.0 / np.sum(p ** 2))
    ent = float(-np.sum(p * np.log(p + 1e-30)))
    erank = float(math.exp(ent))
    cum = np.cumsum(p)
    n50 = int(np.searchsorted(cum, 0.50) + 1)
    n90 = int(np.searchsorted(cum, 0.90) + 1)
    n99 = int(np.searchsorted(cum, 0.99) + 1)
    return {
        "stable_rank": stable, "participation_ratio": pr, "erank_entropy": erank,
        "n50": n50, "n90": n90, "n99": n99,
        "top1_share": float(p[0]), "spectral_norm": float(s[0]),
        "fro_norm": float(math.sqrt(tot)), "n_sv": int(s.size),
    }


def noise_baseline(shape_out, shape_in, rank, n_draws=20, seed=0):
    """Gaussian noise of the SAME shape, same LoRA parameterisation.
    同形状、同 LoRA 参数化下的高斯噪声基线。

    This is the single most important guard rail: without it, "effective rank is
    low" is not evidence at all - random matrices are also low-rank by these metrics.
    这是最重要的护栏：没有它，"有效秩低"根本不构成证据 —— 随机矩阵按这些度量也低秩。
    """
    rng = np.random.default_rng(seed)
    scale = 1.0 / math.sqrt(max(rank, 1))
    acc = []
    for _ in range(n_draws):
        A = rng.standard_normal((rank, shape_in)) * scale
        B = rng.standard_normal((shape_out, rank)) * scale
        s = singular_values(A, B, 1.0)
        m = rank_metrics(s)
        if m:
            acc.append(m)
    if not acc:
        return None
    keys = [k for k in acc[0] if isinstance(acc[0][k], float)]
    return {k: {"mean": float(np.mean([a[k] for a in acc])),
                "std": float(np.std([a[k] for a in acc])),
                "p05": float(np.percentile([a[k] for a in acc], 5)),
                "p95": float(np.percentile([a[k] for a in acc], 95))} for k in keys}


def subspace_diagnostics(s_full, k):
    """What exactly are we throwing away when we keep only the top-k triplets?
    只保留前 k 个奇异三元组时，我们到底丢掉了什么？

    A plain cosine between the truncated spectrum and the full one is ALWAYS 1.0
    for SVD truncation (the truncation is a prefix by construction), so it measures
    nothing. The questions that actually matter are:
    截断谱与全谱做余弦永远是 1.0（截断本来就是前缀），等于什么都没测。
    真正有信息量的是这三个量：

      energy_dropped        how much energy leaves the building / 丢掉多少能量
      dropped_max_over_s1   largest discarded sigma, relative to sigma_1
                            被丢弃的最大奇异值相对 sigma_1 有多大
                            -> small means "pure tail" / 很小说明只是长尾
                            -> near 1 means "you just cut a real direction"
                               / 接近 1 说明你剪了一条真正的方向（危险）
      spectral_gap          sigma_{k-1} / sigma_k at the cut point
                            截断点的谱间隙 -> large gap = safe place to cut
                            间隙大 = 这个位置切下去很安全
    """
    s_full = np.asarray(s_full, dtype=np.float64)
    k = int(k)
    if s_full.size < 2 or k < 1:
        return {}
    k = min(k, s_full.size)
    kept, dropped = s_full[:k], s_full[k:]
    tot = float((s_full ** 2).sum()) or 1e-30
    out = {
        "k": k,
        "energy_kept": float((kept ** 2).sum() / tot),
        "energy_dropped": float((dropped ** 2).sum() / tot) if dropped.size else 0.0,
        "dropped_max_over_s1": float(dropped[0] / s_full[0]) if dropped.size else 0.0,
        "spectral_gap": float(s_full[k - 1] / s_full[k]) if k < s_full.size else float("inf"),
    }
    return out



def dump_json(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    probe(f"saved -> {path}", "IO")
    return path
