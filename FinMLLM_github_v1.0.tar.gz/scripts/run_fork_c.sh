#!/usr/bin/env bash
# ============================================================
# FinMLLM / run_fork_c.sh
# Fork C pipeline: compress every adapter across ranks, evaluate each one,
# then emit the compression-accuracy table.
# Fork C 全流程：对每个 adapter 扫一遍秩，逐个评测，最后出"压缩-精度"表。
#
# Author : Raymond Xiaohu Fan
# Note   : No training. Only SVD, inference and counting. / 不训练，只有 SVD、推理和计数。
# Updated: 2026-10-23
# ============================================================
set -uo pipefail
cd /root/autodl-tmp/FinMLLM || exit 1
source setup_env.sh 2>/dev/null || true
export BASE_MODEL="${BASE_MODEL:-/root/autodl-tmp/models/Qwen2.5-3B}"

DATASET="${DATASET:-fpb}"
LIMIT="${LIMIT:-300}"
RANKS="${RANKS:-16 8 4 2 1}"
mkdir -p ckpts_c outputs/reports

for src in ckpts/bank_qlora_s42 ckpts/insurance_qlora_s42 ckpts/securities_qlora_s42; do
  [ -d "$src" ] || { echo "skip $src"; continue; }
  name=$(basename "$src" _qlora_s42)
  for r in $RANKS; do
    out="ckpts_c/${name}_r${r}"
    if [ ! -f "$out/adapter_model.safetensors" ]; then
      echo "---- compress $name -> r=$r"
      python scripts/make_lowrank_adapter.py --src "$src" --rank "$r" --out "$out" || continue
    fi
    echo "---- eval $name r=$r on $DATASET"
    python scripts/eval_adapter.py --dataset "$DATASET" \
      --adapter "$out" --limit "$LIMIT" \
      --out "outputs/reports/eval_${name}_${DATASET}_r${r}.json" || continue
  done
done

echo ""
echo "==== DONE. Build the table with: ===="
echo "  python scripts/table_fork_c.py"
