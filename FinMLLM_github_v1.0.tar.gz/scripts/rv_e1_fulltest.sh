#!/usr/bin/env bash
# FinMLLM / rv_e1_fulltest.sh  (v2: 走 rv_eval_preds.py, 支持种子目录)
# 全量测试集重跑。Full test-partition rerun with per-item predictions.
# Author: Raymond Xiaohu Fan
set -u
cd /root/autodl-tmp/FinMLLM || exit 1

OUT=outputs/reports/rv_full
DRY=0
[ "${1:-}" = "--dry" ] && DRY=1
mkdir -p "$OUT" logs

declare -a JOBS=()
add_job () { JOBS+=("$1|$2|$3|$4"); }

# ---- A. ckpts_sft / ckpts_sft3（fpb 命名，含全部 rank）----
for cfg in $(find ckpts_sft ckpts_sft3 -name adapter_config.json 2>/dev/null); do
  dir=$(dirname "$cfg"); base=$(basename "$dir"); parent=$(basename "$(dirname "$dir")")
  rank=$(echo "$base" | grep -oE 'r[0-9]+$' | tr -d 'r'); [ -z "$rank" ] && continue
  if echo "$parent" | grep -q "sft3"; then task=tri; else task=bin; fi
  add_job "$task" 42 "$rank" "$dir"
done

# ---- B. ckpts_seed123 / ckpts_seed2024（目录名 r{N}，默认 binary）----
for cfg in $(find ckpts_seed123 ckpts_seed2024 -name adapter_config.json 2>/dev/null); do
  dir=$(dirname "$cfg"); base=$(basename "$dir")
  rank=$(echo "$base" | grep -oE '^r[0-9]+$' | tr -d 'r'); [ -z "$rank" ] && continue
  seed=42
  case "$dir" in
    *seed123*)  seed=123 ;;
    *seed2024*) seed=2024 ;;
  esac
  add_job "bin" "$seed" "$rank" "$dir"
done

[ ${#JOBS[@]} -eq 0 ] && { echo "no adapter found"; exit 1; }
mapfile -t JOBS < <(printf '%s\n' "${JOBS[@]}" | sort -t'|' -k1,1 -k2,2n -k3,3nr -u)

echo "================================================================"
echo " found ${#JOBS[@]} adapters"
echo "================================================================"
printf "%-6s %-6s %-5s %s\n" task seed rank path
printf -- "----------------------------------------------------------------\n"
for j in "${JOBS[@]}"; do
  IFS='|' read -r t s r p <<< "$j"
  printf "%-6s %-6s %-5s %s\n" "$t" "$s" "$r" "$p"
done

if [ $DRY -eq 1 ]; then echo ""; echo "(dry-run)"; exit 0; fi

echo ""
echo "start $(date '+%F %T')"
FAIL=0
for j in "${JOBS[@]}"; do
  IFS='|' read -r t s r p <<< "$j"
  out="$OUT/${t}_s${s}_r${r}.json"
  if [ -s "$out" ]; then echo "  skip: $out"; continue; fi
  classes=3; [ "$t" = "bin" ] && classes=2
  echo ">>> $t s$s r$r  <- $p"
  python scripts/rv_eval_preds.py \
      --dataset fpb --classes $classes \
      --adapter "$p" --limit 0 \
      --out "$out" || { echo "  FAIL $t s$s r$r"; FAIL=$((FAIL+1)); }
done

echo ""
echo "done $(date '+%F %T'), failed=$FAIL"
echo "summarize: python scripts/rv_summarize.py --dir $OUT"
