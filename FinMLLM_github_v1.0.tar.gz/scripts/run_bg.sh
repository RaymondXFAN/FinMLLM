#!/usr/bin/env bash
# ============================================================
# FinMLLM / run_bg.sh
# Launch ANY long task in the background with a timestamped run directory,
# PID file and probe log. Closing the MacBook lid must never kill a job.
# 把任何长任务放到后台，自动建"时间戳版本目录"、PID 文件与探针日志。
# 合盖断 SSH 也绝不中断任务。
#
# Author : Raymond Xiaohu Fan
# Note   : If it runs in the foreground, it isn't running at all. / 跑在前台的，等于没在跑。
# Updated: 2026-10-19
#
# Usage / 用法:
#   bash scripts/run_bg.sh <tag> "<command>"
#   e.g. bash scripts/run_bg.sh download "bash scripts/download_data.sh"
#        bash scripts/run_bg.sh e0 "python scripts/e0_spectral.py --seed 42"
#
# Then / 然后:
#   bash scripts/status.sh            # one-shot status panel / 单次状态面板
#   bash scripts/status.sh --watch    # live dashboard / 实时看板
# ============================================================
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
TAG="${1:?用法: bash scripts/run_bg.sh <tag> \"<command>\"}"
CMD="${2:?缺少要执行的命令}"
STAMP="$(date +%Y%m%d_%H%M%S)"
RUN_ID="${STAMP}_${TAG}"
RUNDIR="$PROJ/runs/$RUN_ID"

mkdir -p "$RUNDIR/logs" "$RUNDIR/outputs"

# Snapshot the environment so a failed run can be reproduced later.
# 快照环境，方便失败后复盘复现。
{
  echo "run_id=$RUN_ID"
  echo "tag=$TAG"
  echo "cmd=$CMD"
  echo "started=$(date '+%F %T')"
  echo "host=$(hostname)"
  echo "pwd=$(pwd)"
  echo "python=$(python -V 2>&1)"
  echo "--- env (filtered) ---"
  env | grep -E '^(PROJ|HF_|CUDA|PYTORCH|TOKENIZERS)' | sort
  echo "--- disk ---"; df -h /root/autodl-tmp 2>/dev/null | tail -1
  echo "--- gpu ---"; (nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader 2>/dev/null || echo "no gpu")
} > "$RUNDIR/env_snapshot.txt"

# Launch detached. nohup + disown + setsid = survives SSH logout.
# 后台启动，三层保险，SSH 断开也不死。
export PROBE_TAG="$RUN_ID"
nohup setsid bash -c "source '$PROJ/scripts/lib_probe.sh' 2>/dev/null; probe_init '$RUN_ID'; cd '$PROJ'; $CMD" \
  > "$RUNDIR/logs/stdout.log" 2> "$RUNDIR/logs/stderr.log" &
PID=$!
echo "$PID" > "$RUNDIR/pid"
echo "$RUN_ID" > "$PROJ/runs/.latest"

sleep 2
if kill -0 "$PID" 2>/dev/null; then
  STATE="RUNNING"
else
  STATE="EXITED_EARLY"
fi

cat <<EOF

============================================================
 🚀 Background job started / 后台任务已启动
 run_id : $RUN_ID
 pid    : $PID
 state  : $STATE
 dir    : $RUNDIR
 stdout : $RUNDIR/logs/stdout.log
 stderr : $RUNDIR/logs/stderr.log
============================================================
 Monitor / 监控:
   bash scripts/status.sh --watch
 Tail / 跟踪:
   tail -f $RUNDIR/logs/stdout.log
 Kill / 终止:
   kill $PID
============================================================
EOF

# Handy one-liner to paste later / 方便复制的跟踪命令
echo "TAIL_CMD=\"tail -f $RUNDIR/logs/stdout.log\"" > "$RUNDIR/howto.sh"
