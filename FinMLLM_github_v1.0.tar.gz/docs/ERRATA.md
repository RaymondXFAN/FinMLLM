# ERRATA · 实验与代码勘误记录

> 建立：2026-11-09
> 目的：记录我们在 FinMLLM 项目里**犯过的每一个错、为什么错、怎么改的**。
> 这份文件不进论文，但进代码仓库——审稿人要复现时，先看这里，别重走我们的弯路。
> 打包交付时只放**修正后的代码**，错误的实现一律不留。

---

## E-01 · `train_sft.py` 的 seed 同时控制数据划分与模型初始化（最严重）

**症状**
用 `--seed 123` 和 `--seed 2024` 训出来的三元 adapter，测试精度分别是 0.9401 和 0.9132，而 `--seed 42` 只有 0.7541。三个种子差 0.19，不像随机波动。

**原因**

```python
# 原代码
pairs = load_pairs(..., seed=args.seed)   # ← 这个 seed 决定了谁是训练集
...
random.seed(args.seed)                     # ← 同一个 seed 又决定了初始化
```

而评测脚本固定用 `seed=42` 划分测试集。于是：

| 训练 seed | 训练集与 seed42 测试集的重叠 |
|---|---|
| 42 | **0 条**（严格互补） |
| 123 | **766 / 968 = 79.1%** |
| 2024 | **752 / 968 = 77.7%** |

训练集里 79% 就是评测时算分的样本，精度当然虚高。

**验证方法**

```python
import sys; sys.path.insert(0, 'scripts')
from train_sft import load_pairs
te42  = set(map(tuple, load_pairs('fpb', False, split='test',  holdout=0.2, seed=42)))
tr123 = set(map(tuple, load_pairs('fpb', False, split='train', holdout=0.2, seed=123)))
print(len(tr123 & te42))   # 766
```

**修复**
拆成两个参数：`--split-seed`（固定 42，决定划分）和 `--seed`（只影响初始化）。
实现见 `scripts/make_rv_train_patch.py`，它从 `train_sft.py` 生成 `rv_train_sft.py`，**不改动原文件**。

```python
pairs = load_pairs(..., seed=args.split_seed)   # 划分永远用 42
set_seed(args.seed)                              # 初始化随种子变
```

**教训**
> **一个 seed 不该同时管两件事。** 凡是「数据怎么分」和「模型怎么初始化」共用一个随机源，迟早出这种事故。

**影响范围**
`10_实验结果总表.md` 里三元两种子（0.8400 / 0.7967）的旧记录无出处，作废。三种子全部重训。

---

## E-02 · `eval_adapter.py` 不按 split 过滤（虚惊，但同样危险）

**症状**
差点误判整篇论文的评测集含训练样本。

**原因**

```python
# eval_adapter.py 的 load_rows
for line in f:
    rows.append((t, lab))          # 读全部，不看 split 字段
rng.choice(len(rows), limit)       # 从 100% 里随机抽 300
```

而 `train_sft.py` 只用 80% 训练。所以 `eval_adapter.py` 抽的 300 条里约 80% 是训练过的。

**为什么最后没事**
论文的数字全部来自 `eval_cloze.py`，它的 `load_rows` 有 `split="test"` 默认值并调用 `_holdout_split`。34 个 report 的 `mode` 字段都是 `cloze`，没有一个是 `eval`。

**修复**
`eval_adapter.py` 是早期遗留脚本，**已废弃不用**。所有评测走 `rv_eval_preds.py`（内部 import `eval_cloze`）。

**教训**
> 两个脚本同名函数、不同语义，是事故的温床。查论文数据来源时，先看 report 里的 `mode` 字段，别信文件名。

---

## E-03 · 往 `adapter_config.json` 写自定义字段导致 PEFT 崩溃

**症状**

```
TypeError: LoraConfig.__init__() got an unexpected keyword argument 'rv_variant'
```

46 个变体全部加载失败，整批评测 3 分钟全 FAIL。

**原因**
我在 `rv_make_variants.py` 的 `_write()` 里做了：

```python
cfg = json.load(...)
if extra_cfg:
    cfg.update(extra_cfg)      # ← 往 adapter_config.json 里塞了 rv_variant
```

PEFT 的 `LoraConfig` 是**严格签名**，多一个键直接 TypeError。

**修复**
自定义元信息写到独立的 `rv_meta.json`，**绝不碰 `adapter_config.json`**。

**教训**
> `adapter_config.json` 是 PEFT 的保留文件，不是我们的记事本。

---

## E-04 · `make_lowrank_adapter.py` 用稠密 SVD，慢 28 倍

**症状**
生成一个 r=1 截断版，CPU 706%、跑了 11 分钟还没出目录。

**原因**

```python
W = B @ A                        # 重建 [4096, 4096] 稠密矩阵
U, S, Vt = np.linalg.svd(W)      # 对这个稠密矩阵做 SVD
```

3B 模型 252 个矩阵，每个稠密 SVD 1–3 秒，累计 10–15 分钟。

**修复：QR-core 技巧**
不用重建稠密矩阵。因为 `A:[r,in]`、`B:[out,r]`，`r=16`：

```
B = Q_B R_B        Q_B:[out,r]  R_B:[r,r]
Aᵀ = Q_A R_A       Q_A:[in,r]   R_A:[r,r]
ΔW = Q_B (R_B R_Aᵀ) Q_Aᵀ
SVD(R_B R_Aᵀ)  ← 只对 r×r 小矩阵做
```

实测 **23 秒 → 7.4 秒**（单 adapter），误差与稠密 SVD 一致。
实现见 `scripts/rv_lowrank.py`。

**验证**
重建相对误差 mean = 0.61–0.65，与理论值 √0.431 ≈ 0.657 吻合（rank-1 保留 56.9% 能量）。

---

## E-05 · PARA 基线逐层不同秩 vs PEFT 全局 `r`

**症状**

```
size mismatch for ...gate_proj.lora_A.default.weight:
copying a param with shape [2, 2048] from checkpoint,
the shape in current model is [1, 2048]
```

几十层全是这个错。

**原因**
PARA 原式是「跨层统一阈值」，**每层保留的数目不同**（实测有 1/2/3/4/7/12 各种）。
但 PEFT 的 `lora r` 是**全局参数**，所有层必须同秩。
我按 `r = round(16 × 平均保留比)` 写 config，与实际的逐层形状对不上。

**修复**
改为统一秩：先用阈值算出总保留量，折算成统一 `k`，再**每层都取前 k 个**。

```python
total_keep = sum(int(np.sum(Sm > thr)) for each layer)
k_uniform  = max(1, round(r0 * total_keep / total_full))
# 每层取前 k_uniform 个
```

**必须在论文里声明**
> "PARA allocates rank per layer under a global threshold; the PEFT interface we use fixes a single rank for all layers. We therefore take the uniform rank whose total parameter count matches PARA's threshold rule, which makes our implementation a constrained version of their method rather than a faithful one."

**不写这句，审稿人一复现就发现我们的 PARA 不是 PARA。**

---

## E-06 · `np.percentile` 的参数被多除了一次 100

**症状**
PARA 扫 50/60/70/80/90 分位，保留秩比全是 **0.991–0.995**，几乎没压缩。

**原因**

```python
thr = np.percentile(flat, q / 100.0)
```

`np.percentile` 第二个参数**本身就是 0–100 的百分位**，不该再除 100。`q=50` 传成 `0.5`，取的是 0.5% 分位，阈值极低，几乎全保留。

**修复**

```python
thr = np.percentile(flat, q)   # q 直接是 0-100
```

修完后保留秩比正常：q=40 → 0.60，q=98 → 0.063。

**教训**
> 凡是把「百分比」传进库里，先看库要的是 0–1 还是 0–100。

---

## E-07 · 随机方向实验只做单次抽样，得出假反转

**症状**
旧结果：三元 r=4 时，随机挑方向 0.8833，比按奇异值排序的 0.7800 **高 10 个点**。一度以为"能量排序有害"，还写了一整段机制解释。

**原因**
`build_randdir` 用固定种子每个 rank **只抽一次**：

```python
rng = np.random.default_rng(20261025)   # 一个种子，一个 draw
idx = np.sort(rng.choice(len(s), size=k, replace=False))
```

**修复：5 次抽样**

| 三分类 r=4 | 精度 |
|---|---|
| 旧（单次，n=300） | **0.8833** ← 离群 |
| 新（5 次，n=968） | **0.7789 ± 0.0575**，最高 0.8337 |
| SVD 排序 | 0.7800 |

**0.8833 是抽样噪声，不是机制。**

更强的发现反而出现了：**秩越低，方向选择越关键**

| | SVD | 随机（5 次） |
|---|---|---|
| r=8 | 0.7831 | 0.7709 ± 0.0272（打平） |
| r=1 | 0.7913 | **0.6231 ± 0.2134**（最差 0.3306，崩了） |

**教训**
> 单次抽样的"反直觉发现"，第一反应应该是"再抽五次"，而不是"写段机制解释"。
> 我们差点把一个噪声写成了贡献。

---

## E-08 · 变体目录没分任务，bin 和 tri 互相覆盖

**症状**
`ckpts_supp/mask_p40_fpb_r16` 这个目录，先由二分类生成，后被三分类覆盖。

**原因**
`rv_make_variants.py` 的目录名用了 `basename(src)`，而 `ckpts_sft/fpb_r16` 和 `ckpts_sft3/fpb_r16` 的 basename 都是 `fpb_r16`。

**修复**
加 `--out-root ckpts_supp/bin` / `ckpts_supp/tri`，按任务分目录。

---

## E-09 · 空目录下 glob 不展开，生成垃圾文件名

**症状**

```
FAIL *__bin
```

**原因**

```bash
for d in ckpts_supp/bin/*/; do basename "$d"; done
```

空目录时 glob 不展开，字面量 `ckpts_supp/bin/*/` 被当成一个路径，`basename` 得到 `*`。

**修复**

```bash
shopt -s nullglob
NB=$(find ckpts_supp/bin -name adapter_config.json | wc -l)
[ "$NB" -eq 0 ] && { echo "没有 adapter，先跑 rv_make_variants.py"; exit 1; }
```

---

## E-10 · 两个训练队列并行导致 CPU 超订卡死

**症状**
开了两个 `nohup bash` 队列同时跑，CPU 100%、GPU 0%、日志十几分钟不动。

**原因**
每个训练进程 `OMP_NUM_THREADS=8`，两个进程 = 16 线程，而 `nproc = 8`。tokenizer 和 dataloader 互相抢锁。

**修复**
- **串行**跑，一次一个队列
- 7B 冒烟实测：单进程 `LOAD = 8.17 / nproc = 8`，**已经打满**，绝对不能并行

**教训**
> 显存够不等于能并行。CPU 核数才是这里的天花板。

---

## E-11 · FiQA 的 `label` 列被 ticker 污染

**症状**
```
dataset=fiqa_sa classes=3 split=train pairs=0
AssertionError: no data
```

**原因**
`prep_data.py` 按列名找 `label` 列，FiQA 的 csv 里恰好有一列叫 `label` 装的是股票代码（`AAPL`、`HCP`、`AMZN`），而真正的情感分数在别的列。统一化后 jsonl 里 `label` 全是 ticker，`lab not in LABELS` 全部过滤掉。

**修复**
`scripts/supp/fix_fiqa.py`：**按取值判定**，不按列名。

```python
# 对每一列统计"归一化后能识别出情感的比例"
for c in cols:
    score = sum(norm(r.get(c)) is not None for r in recs) / len(recs)
# 取 score 最高的那列
```

连续分数按 ±0.2 阈值转三类。

**教训**
> 别信叫 `label` 的列，要信它装的值。

---

## E-12 · Table 1 混用了两套训练母体

**症状**
三种子数据里，seed42 来自 `ckpts_sft3`（母体 0.7831），seed123/2024 来自 `ckpts_rv`（母体 0.8254 / 0.7820）。**同一次实验的三种子来自两批训练。**

**原因**
修 E-01 后只重训了 123/2024，没重训 42（因为 42 本来就干净）。

**修复**
统一到 `ckpts_rv`：用 `rv_lowrank.py` 从 `ckpts_rv/tri_r16_s42` 截断出 r8/r4/r2/r1，全部评测。

**取舍**
统一后 s42 母体会从 0.7831 降到 0.7541，数字变难看。**但真实训练方差不能挑好看的用。**

---

## E-13 · 体积口径 130 MB → 115 MB

**早期估算错误**
按参数数推算 adapter 是 130 MB，实际 `ls -lh` 是 **115 MB**。所有派生值（65 / 32.5 / 16.2 / 8.1 MB）全部错位。

**实际值**

| rank | 体积 |
|---|---|
| 16 | 115.0 MB |
| 8 | 57.1 MB |
| 4 | 28.5 MB |
| 2 | 14.3 MB |
| 1 | 7.1 MB |

**教训**
> 体积这种能 `ls` 出来的数字，永远不要算。

---

## E-14 · `analyze_adapter_rank.py` 不吃 `--ckpt`

**症状**
overnight 脚本第 4 步原本要调 `--ckpt`，实测接口是 `--adapter`。

**修复**
改参数名。**这就是为什么谱分析被从 overnight 里剥出来单独跑**——参数名写错，4 小时后才发现第 4 步全挂。

**教训**
> 长队列的每一步，启动前都要 `--help` 验一遍接口。

---

## 汇总：哪些错了、改在哪

| 编号 | 类型 | 影响 | 修复文件 |
|---|---|---|---|
| E-01 | 🔴 数据泄漏 | 三种子全部作废重训 | `make_rv_train_patch.py` → `rv_train_sft.py` |
| E-02 | 🟠 潜在泄漏 | 未影响论文（用错脚本） | 弃用 `eval_adapter.py` |
| E-03 | 🔴 加载崩溃 | 46 个变体全挂 | `rv_make_variants.py` |
| E-04 | 🟠 性能 | 28× 慢 | `rv_lowrank.py`（QR-core） |
| E-05 | 🔴 加载崩溃 | PARA 12 个全挂 | `rv_para_baseline.py` |
| E-06 | 🟠 逻辑 | PARA 没压缩 | `rv_para_baseline.py` |
| E-07 | 🔴 结论错误 | 假反转，机制段作废 | 5 次抽样重跑 |
| E-08 | 🟠 数据覆盖 | bin/tri 互相覆盖 | `--out-root` 分目录 |
| E-09 | 🟡 脚本健壮性 | 生成垃圾文件名 | `nullglob` + 预检 |
| E-10 | 🟠 运行卡死 | 白等 20 分钟 | 改串行 |
| E-11 | 🔴 训练失败 | FiQA 0 样本 | `fix_fiqa.py` |
| E-12 | 🟠 严谨性 | 三种子两套母体 | 统一到 `ckpts_rv` |
| E-13 | 🟡 数据口径 | 体积全错 | 照 `ls` 改 |
| E-14 | 🟡 接口 | 第 4 步会全挂 | 改 `--adapter` |

---

## 交付原则

1. **只打包修正后的代码**，带错误的实现一律不进交付包
2. 每个脚本头部保留双语注释，说明**为什么这么写**
3. 本文件随代码一起交付，审稿人复现时先看这里
4. `DEPRECATED` 标记的旧文件（`07_ForkC_论文初稿.md`、`12_论文正文_v1.md`、`eval_adapter.py`）明确标注，避免误用

---

## E-16 · patch 脚本时赋值顺序颠倒

**症状**：`KeyError: 'noise'`

**原因**：用 python 替换时把 `m["noise_mc"] = m["noise"]` 放在了
`m["noise"] = noise_analytic(...)` 之前，读一个还没赋值的键。

**教训**：批量替换后必须 `sed -n` 看一眼实际代码。
脚本打印"✅ 已修改"只代表字符串替换成功，不代表逻辑正确。

---

## E-17 · 数值秩没按配置秩封顶，高斯基线偏大

**症状**：3B r=64 的 noise 算出 50.09，按 d=2048 手算应为 46.22。

**原因**：`rank_int = (sv > sv[0]*1e-6).sum()` 在 [2048, 2048] 的 SVD 上
把十几个数值零误判为非零，k_eff 被高估。

**修复**：`k_eff = min(rank_int, r_cfg)`。

**注意**：修复后 noise 仍是 50.09 —— 因为真正的解释是 E-18，不是这个。
这条改动是对的（防止未来更大的形状出问题），但不是 50.09 的原因。

---

## E-18 · 高斯基线的 d 被当成常数 2048，实际因层而异

**症状**：3B r16 的 noise 算 14.08，旧表记 13.55。

**原因**：旧值按 d=2048 算，那只对 attention 层成立。
实测 dW 形状分布：`{2048: 144, 11008: 108}` —— 108 个 MLP 层的 d 是 11008。

| 层类型 | d | 解析 noise (r=16) |
|---|---|---|
| q_proj / o_proj | 2048 | 13.51 |
| gate/up/down_proj | 11008 | 14.83 |
| **加权均值** | — | **14.081** |

**修复**：`d_side = max(dW.shape)`，每个矩阵跟自己的形状比。

**验证**：加权均值 14.081，与脚本输出一致。

**影响**：ratio 从 0.15 → 0.141，结论不变。

---

## E-19 · 7B 与 3B 的 adapter 混用同一套指标口径

**症状**：差点用 `analyze_adapter_rank.py` 输出的 `n90=6.25` 去和 Table 3 的
`stable rank=1.98` 比较——两个完全不同的指标。

**原因**：`analyze_adapter_rank.py` 报 n50/n90/n99/top-1 share；
Table 3 报 stable rank / PR / eRank / n90 / noise / ratio。
两套指标里只有 n90 重叠，其余不可比。

**修复**：统一走 `spectral_table3.py`，指标定义写死在文件头，7B 与 3B 同一套。

**教训**：跨模型比较前，先确认两边用的是**同一个脚本的同一组指标**。
文件名相似不代表口径相同。

---

## E-20 · FRL 字数限制记成 3000，官方是 2500（最贵的一次记账错误）

**症状**：FRL 版第一稿 `30_FRL_short_letter.md` 正文 3,078 词，
自以为"控制在 FRL 的 ~3,000 词量级"，还专门写进摘要里当成合格。

**原因**：3,000 这个词来自中文中介网站的二手说法（"字数要求2500以内"
"3000 words"两种说法在网上互相打架，我抓了中间那个听起来最宽松的）。
真正去 Elsevier Guide for Authors 读原文才发现写得很死：

> "Manuscripts should be concise and **not exceed 2500 words (main text only)**.
> The word count includes in-text citations and footnotes, but **excludes the
> abstract, references, tables, figures, captions/notes**, acknowledgements,
> declarations, and any appendices/supplementary material."
> —— Aims and scope + Journal specific information → Writing and formatting

**后果**：超 578 词，超幅 23%。这个数字编辑在 desk review 第一眼就会看，
属于送上去就被退的那一类硬伤，而且和论文质量无关——非常冤。

**修复**：全篇重写正文，逐节定量砍：
Intro 580→410 / Data 593→420 / Results 1106→942 / Discussion 633→545 / Conclusion 164→152，
最终 **2,469 词**，留 31 词缓冲（Word 与 Python 分词口径不同，不能贴着 2500 写）。
另查：Abstract 208 词（限 250）、Highlights 5 条、最长 80 字符（限 85）、
参考文献 12 条（FRL 要求 30–50 是误传，官方不设下限，只要求格式自洽）。

**教训**：投稿的字数、页数、图表数这类硬指标，**只认出版社自己的 Guide for
Authors 原文**，二手攻略一律不作数。而且必须先查再动笔——先写完 3,078 词
再发现上限是 2,500，等于白写一遍。

---

## E-21 · `make_fig_frl.py` 的 OUT 写死服务器路径

**症状**：
```
FileNotFoundError: '/root/autodl-tmp/FinMLLM/outputs/figs/frl_fig1_ratio_vs_cost.png'
```

**原因**：从长文版 `make_figures.py` 里抄路径，把服务器的绝对路径带进了
在沙箱里执行的脚本。

**修复**：
```python
OUT = os.path.join(os.environ.get("PROJ", "/sandbox/workspace/FinMLLM"), "outputs", "figs")
os.makedirs(OUT, exist_ok=True)
```
同一套代码服务器和沙箱都能跑。

**教训**：所有脚本的输出目录都走 `PROJ` 环境变量 + `os.path.join`，
不要出现第二个硬编码的绝对路径。

---

## E-22 · md → docx 只匹配 `# `，`## 3.1` 和 `**Highlights**` 全漏了

**症状**：FRL 版 docx 里出现三处怪异：`---` 被当成正文输出成一个横线段落；
`3.1. The frontier` 变成普通正文（丢了小标题样式）；
Highlights 的 5 条列表带着 `- ` 前缀挤在正文里。

**原因**：`make_docx_frl.py` 的标题分支写的是 `if ln.startswith("# ")`，
只认一级标题。但 md 里 `## 3.1` 是二级、`**Highlights**` 干脆是粗体行，
两种都匹配不上，一路掉进"正文段落"的兜底分支。

**修复**：
1. 标题统一用 `re.match(r"^(#{1,3})\s+(.*)$", ln)`，按 `len(group(1))` 分级；
2. `**Highlights**` / `Highlights` 单独判定为小标题并置 `cur="Highlights"`，
   列表分支才生效；
3. 过滤 `---` / `***` / `___` 分隔线。

**教训**：写 md→docx 转换器时，**先 printf 一遍所有以 `#` 或 `*` 开头的行**，
把真实出现的标记形式和脚本的匹配规则对齐，再跑。别等生成出来看成品才发现漏。

---

## E-23 · Figure 1 图内注释和数据标签打架

**症状**：第一版图里 `less redundant → compression costs` 这行斜体字
和 `PhraseBank ternary` 标签叠在一起，三个点的标签也有两个偏出视觉归属。

**原因**：注释文字用绝对坐标 `ax.text(0.128, 3.7, ...)` 放在左上角，
正好压在 ratio 最小（0.133）、增益最大（+3.31）那个点上。

**修复**：直接删掉这句注释——它说的意思 Figure caption 里已经写了，
图自己会说话。标签偏移改成 `(9,7) / (11,-4) / (-9,-13)`，
图像宽度在 docx 里从 11.5 cm 提到 15.0 cm（版心 16 cm，占 90%）。

**教训**：图里的说明文字能删就删，能交给 caption 就别放图内。
图内每多一行字，就多一个和数据打架的机会。

---

## E-24 · ternary 增量写了四套数，根因是 McNemar 表的 c 抄错了（已定案 2026-11-11）

**发现时间**：2026-11-10，做 FRL v2 的"重点突出"重构时，把表格和正文逐数对齐，对不上。

**现象**：同一个 ternary 结果，项目里有四套数字，互不自洽：

| 出处 | 数值 | 自洽性 |
|---|---|---|
| `10_实验结果总表.md` L17 | 三种子 +3.72 / +2.79 / +6.30，均值 **+4.27** | 4.27 只与 3.72 自洽 |
| `17_论文正文_SUBMISSION.md` L135 | +3.72 / +2.79 / +6.30，池化 +4.27 | 同上 |
| McNemar 原始表（历史对话） | s42 b=44,c=12 → **+3.31**；s123 b=37,c=10 → +2.79；s2024 b=70,c=9 → +6.30 | 三数均值 4.13 ≠ 4.27 |
| FRL Table 1（`make_docx_frl.py`） | r16 0.7872 → r1 0.7913 = **+0.41 pp** | 与以上全部冲突 |

**判断**：
- `b=44, c=12` 净差 32 项 / 968 = **3.31 pp**，数学闭合，说明 +3.31 有原始 b/c 支撑。
- `+3.72` 找不到对应 b/c 记录，疑为早期口径或笔误；但 4.27 的均值只与 3.72 自洽。
- Table 1 的 ternary 列是**混合口径**（0.7872 疑为三 seed 均值，0.7831/0.7800/0.7810/0.7913 疑为单 seed），同列不可比。

**处置（FRL v2，已执行）**：
1. 正文不写逐 seed 点数，改「每一个种子都上升且各自显著（McNemar p ≤ 0.0001）」——方向性结论不受口径影响。
2. Table 1 表注删除 +3.72/+2.79/+6.30，改 "Paired McNemar tests are reported in the text"。
3. Cover Letter 同步删除 "2.79 to 6.30 points"。
4. 结果：FRL 版内部完全自洽，可安全投稿；代价是损失一个有力数字。

**定案（2026-11-11，服务器 `outputs/reports/rv_final/` 原始 json 重算）**

跑的是 `rv_final/tri_s{42,123,2024}_r{16,1}.json` 里逐样本的 `preds`，结果：

| seed | r16 | r1 | Δ | b | c | p |
|---|---|---|---|---|---|---|
| 42 | 0.7831 | 0.8161 | **+3.31** | **44** | **12** | <0.0001 |
| 123 | 0.8254 | 0.8533 | +2.79 | 37 | 10 | 0.0001 |
| 2024 | 0.7820 | 0.8450 | +6.30 | 70 | 9 | <0.0001 |
| **均值** | **0.7968** | **0.8382** | **+4.13** | | | |

**根因找到了 —— 是 `make_docx.py` 里 McNemar 表的 `c` 手写成了 8：**

```
["Ternary", "968", "42", "44", "8", "+3.72", ...]
                              ↑ 实际是 12
(44 - 8) / 968 * 100 = 3.719  →  就是那个 +3.72
```

一个字段抄错，然后这个错值被下游一路引用：总表 L17 抄表格 → 长文 L135 抄总表 →
FRL 摘要抄长文。**四个地方的四套数，源头只有一处。**

**连带发现的第二处硬伤**：`0.7913` 这个数在**全部评测 json 里根本不存在**
（用 `grep` 扫了 97 个 json）。它被写进 Table 1 的 ternary r=1 格，
还支撑着长文 §4.5「mask 与截断收敛」的整段论证。真实值 s42 的 r1 是 **0.8161**。
那段结论因此**反向翻转**：不是"收敛"，是**截断在 tri 上比 mask 高 2.7–3.8 pp**——
对我们其实更有利。已重写。

**全部修复**：
| 文件 | 改了什么 |
|---|---|
| `scripts/make_docx.py` | Table 1 ternary 改 0.7831/0.8161（全表统一 s42 口径）；Table 2 `c` 8→12、Δ +3.72→+3.31、CI 重算为 [+1.80,+4.81] |
| `scripts/make_docx_frl.py` | Table 1 ternary 同上 |
| `17_论文正文_SUBMISSION.md` | L135 改 3.31/4.13；`75.41%`→`78.20%`（原值也不对）；§4.5 mask 段重写 |
| `31_FRL_v2_focused.md` | 补回真值 +3.31/+2.79/+6.30、均值 +4.13 |
| `30_FRL_short_letter.md` | 同步（已废弃，防误用） |
| `10_实验结果总表.md` | L17 改 0.7968/0.8382/+4.13/+3.31 |
| `scripts/consistency_check.py` | 期望值同步 |
| `verify/verify_all.py` | 新增 116 项双口径校验，**改论文不改这张表就立刻 FAIL** |

**教训**：`b`、`c` 这种两个字段的数，抄错一个就会生成一个"看起来完全合理"的 Δ。
以后任何 Δ 必须由脚本从 `preds` 现场算，不允许在文档里手写中间量。

**教训**：一个指标在不同脚本、不同 adapter 批次下算完，必须绑定 `(ckpt 路径, seed, n)` 三元组一起存。只存 accuracy 一个数，事后就分不清哪两个数是同一对——这次冲突就是这么来的。

---

## E-25 · 全面数字扫描：体积链、样本数、占比共 5 处不一致（2026-11-11）

**起因**：E-24 那个 `c=8` 太像真的了，于是决定把所有"手写的中间量"系统扫一遍，
凡是能从文件/json 重算的都重算。结果又抓到 5 处。

### ① 体积链整条错（最严重）

实测 `ckpts_sft3/fpb_r16/adapter_model.safetensors` = **119,801,496 B = 114.25 MiB**。
论文写 115 MB。而 `16.2×` 这个"精确比率"正是 `115/7.1` 算出来的 —— 两个错数凑出一个假精度。

| 项 | 论文原值 | 实测 | 修正 |
|---|---|---|---|
| r=16 | 115.0 MB | 114.25 MiB | **114.3** |
| r=8 | 57.1 MB | 57.16 MiB | **57.2** |
| r=4 | 28.5 MB | 28.61 MiB | **28.6** |
| r=2 | 14.3 MB | 14.34 MiB | 14.3 ✓ |
| r=1 | 7.1 MB | 7.20 MiB | **7.2** |
| on-disk 比率 | 16.2× | 114.25/7.20 = **15.87** | **15.9×** |
| 12 个 adapter | 1.4 GB | 1.34 GiB | **1.3 GB** |
| 压缩后 12 个 | 85 MB | 86.4 MiB | **86 MB** |

**为什么是 114.25**：adapter 以 **float32** 存储，29,933,568 参数 × 4 B = 119.7 MB ≈ 114.25 MiB。
换成 fp16 会是 57 MiB，但 PEFT 默认存 fp32，论文 §3.2 也写了 "stored in float32"。

### ② 成本模型跟着变

| 项 | 论文原值 | 重算 | 修正 |
|---|---|---|---|
| 三年存储（未压缩） | $7.60 | 1.34 × 0.15 × 36 = $7.23 | **$7.2** |
| 三年存储（压缩） | $0.46 | 0.0844 × 0.15 × 36 = $0.456 | $0.46 ✓（一度被我改成 0.47，改回来了） |
| 部署差额上界 | $85,000 | (3000−735) × 36 = **$81,540** | **$82,000** |
| 下界 | $45,000 | (2000−735) × 36 = $45,540 | $45,000 ✓ |

### ③ binary 语料句子数差 1

论文："The binary variant removes the neutral class and leaves **1,966** sentences."
实测：positive 1,363 + negative 604 = **1,967**。
（测试集 394 仍对：sklearn 的 `train_test_split(test_size=0.2)` 用 **ceil**，ceil(1967×0.2)=394）

### ④ 类别分布两个数用了截断而非四舍五入

全语料 4,840 条实测：neutral **59.36%** / positive **28.16%** / negative **12.48%**。
论文写 59.4% / **28.1%** / **12.4%** —— 第一个四舍五入，后两个却截断了，同一句两种规则。
改为 **28.2% / 12.5%**。

### ⑤ 参数占比 0.96% → 0.97%

实测 `Qwen2.5-3B` 基座 **3,085,938,688** 参数，LoRA **29,933,568**。
29,933,568 / 3,085,938,688 = **0.970%**，论文写 0.96%。

**教训（和 E-24 同一条，但更狠）**：凡是能从文件/原始 json 算出来的数，
一个都不要手写。手写的数一旦错了，下游会原样抄三遍，而且每个抄的人都以为上游是对的。
这次 5 处里有 4 处是"差一点点"，单看都不像错——正是这种最难被抓到。

---

## E-26 · §4.6 迁移三数基于重建前的旧数据（已定案 2026-11-12）

无卡模式下只能做文件/算术核对，以下两项需要 GPU 或较大算力，**暂时挂起**。
（2026-11-12 开卡后已全部跑完，结果见下。）

### ① FiQA 跨域迁移的三个数

`§4.6`（长文）/ 总表第八节 的
零样本 **0.2428** / +FPB r16 → **0.6749** / +FPB r1 → **0.6543**（+43.2pp, p=0.2668）

**在服务器 `outputs/reports/` 下用 grep 扫不到任何 json 含这三个值** —— 是早期实验，没落盘。
目前**不可追溯**。明早开卡后用 `ckpts_sft3/fpb_r16` 评 `fiqa_sa`（classes=3）重跑即可定案，
预计 3 分钟（243 条 × 2 条件）。

### ② Table A2 的能量丢弃诊断

E_drop **0.4306 (43.1%)** / 最大被丢 σ/σ₁ **0.5199** / 谱间隙 **1.95**

纯 numpy 可算（不需要 GPU），但要读 114 MB safetensors 并对 252 个矩阵做 QR。
无卡模式下与宿主其他负载抢核（load avg 46），跑一次要几分钟，且我之前起的几个
超时进程没清理，互相抢 BLAS 线程把机器压到 load 28 —— **已全部 pkill，不再在无卡模式下跑**。
开卡后 `OMP_NUM_THREADS=1 python3 scripts/check_energy_drop.py ckpts_sft/fpb_r16 1`，
预计 1 分钟。


---

### ✅ 定案结果（2026-11-12 06:47，RTX 4090）

**① FiQA 跨域迁移 —— 论文三个数全部作废，已替换**

`scripts/verify_fiqa_transfer.py`，测试项与已存档 `fiqa_s42_r16.json` **完全同一批 243 项**（已校验）。

| 条件 | 论文原值 | 实测 | 判定 |
|---|---|---|---|
| base（零样本+校准） | 0.2428 | **0.2181** | ❌ → 已改 |
| + FPB tri r16 | 0.6749 | **0.6626** | ❌ → 已改 |
| + FPB tri r1（16×） | 0.6543 | **0.6749** | ❌ → 已改 |
| base→r16 提升 | +43.2 pp | **+44.44 pp** | ❌ → 已改 |
| r16→r1 差 | −2.06 pp, p=0.2668 | **+1.23 pp, p=0.6072** | ❌ → 已改 |

**根因**：`fiqa_sa.jsonl` 在 11-10 06:16 被 `fix_fiqa.py` 重建过（E-11：label 列原本是股票代码）。
论文那三个数是**重建之前**跑的，而且从未落盘。行为模式倒是对得上 ——
base 实测 235/243 判 neutral，论文写 234/243，差 1 条，说明评测逻辑没变，**变的是数据**。

**有意思的连带效果**：新结果里 r1（0.6749）**高于** r16（0.6626），方向与论文相反。
但 p=0.6072 很不显著，所以正文写的是「no detectable change」而不是「压缩提升」——
不能因为数字反过来了就顺势吹。

**② Table A2 能量诊断 —— 三个数完美复现**

`scripts/check_energy_drop.py ckpts_sft/fpb_r16 1`（r×r 核 SVD，避免 11008×2048 稠密分解）：

| 指标 | 论文 | 实测 |
|---|---|---|
| E_drop（1/16 截断） | 0.4306 | **0.4306** ✅ |
| 最大被丢 σ/σ₁ | 0.5199 | **0.5199** ✅ |
| 截断点谱间隙 | 1.95 | **1.9471** ✅（中位数） |

一位不差。Table A2 从此有据可查。

**顺带修的两个脚本 bug**（都会让审稿人第一步就失败）：
1. `--bg` 分支用 `$0` 相对路径重新拉起自己，但脚本已 `cd` 到 `$PROJ` → `No such file or directory`
2. 调用子脚本用相对路径 `scripts/xxx.py`，同样因 `cd` 失效 → 改成 `$SCRIPT_DIR/xxx.py`

**新增守护**：`verify_all.py` 从 116 项扩到 **121 项**（§4.6 的 base/r16/r1/Δ/gain 全纳入）。
