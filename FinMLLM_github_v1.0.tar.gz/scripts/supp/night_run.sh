#!/usr/bin/env bash
# ============================================================
# FinMLLM / supp / night_run.sh
# One shot, overnight. Fills every hole left in the results tables.
# 一次启动、通宵跑完：把结果表里所有缺口补齐。
#
# What it fills / 补什么:
#   G1  ternary seeds 123 / 2024 trained from scratch (r=16)       ~35-45 min
#   G2  both seeds truncated to r = 8 / 4 / 2 / 1                  seconds
#   G3  every missing cell evaluated (ternary 5 rungs x 2 seeds,
#       binary r=8/r=2 x 2 seeds, FiQA with --save-preds,
#       mask 60/80 on binary, all random-direction variants)        ~8 min
#   C1  McNemar paired tests on everything that has predictions     seconds
#   C2  final table regenerated into outputs/night_<stamp>/         seconds
#
# Author : Raymond Xiaohu Fan
# Note   : Start it, close the lid, go home. It will not need you.
#          启动、合盖、回家。它不需要你。
# Updated: 2026-10-25
#
# Usage / 用法:
#   bash scripts/supp/night_run.sh              # foreground
#   bash scripts/supp/night_run.sh --bg         # detach (recommended)
#   AUTO_SHUTDOWN=1 bash scripts/supp/night_run.sh --bg    # power off when done
# ============================================================
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
cd "$PROJ" || { echo "FATAL: $PROJ not found"; exit 1; }

STAMP="${STAMP:-$(date +%Y%m%d_%H%M)}"
export STAMP
PAR="${PAR:-3}"
LIMIT="${EVAL_LIMIT:-300}"
BASE="${BASE_MODEL:-/root/autodl-tmp/models/Qwen2.5-3B}"
SUPP="ckpts_supp"
LOGD="outputs/logs/supp"
OUTD="outputs/night_${STAMP}"
mkdir -p "$SUPP" "$LOGD" "$OUTD" outputs/reports

export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_XET=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True TOKENIZERS_PARALLELISM=false

REPORT="$OUTD/MORNING_REPORT.txt"
: > "$REPORT"

say()  { echo "[$(date +%H:%M:%S)] $*" | tee -a "$REPORT"; }
hr()   { echo "============================================================" | tee -a "$REPORT"; }

# ---------------- detach ----------------
if [ "${1:-}" = "--bg" ]; then
  mkdir -p "$LOGD"
  LOG="$LOGD/night_${STAMP}.log"
  echo "detaching -> $LOG"
  setsid nohup env STAMP="$STAMP" PAR="$PAR" EVAL_LIMIT="$LIMIT" \
      AUTO_SHUTDOWN="${AUTO_SHUTDOWN:-0}" \
      bash "$0" >>"$LOG" 2>&1 &
  sleep 3
  echo
  echo "✅ 已后台启动，可以合盖下班了"
  echo "   主日志 : $PROJ/$LOG"
  echo "   早报   : $PROJ/$REPORT"
  echo "   状态   : bash scripts/supp/status_supp.sh"
  exit 0
fi

T0=$(date +%s)
hr
say "NIGHT RUN STARTED  stamp=$STAMP  PAR=$PAR  EVAL_LIMIT=$LIMIT"
hr
nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader | tee -a "$REPORT"

wait_free() {
  local need="${1:-6000}" tries=0
  while :; do
    local free
    free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
    free=${free:-0}
    [ "$free" -ge "$need" ] && return 0
    tries=$((tries+1))
    [ $((tries % 10)) -eq 1 ] && say "  GPU gate: ${free} MiB free < ${need}, waiting"
    sleep 30
  done
}

run_pool() {   # run_pool <parallel> <name:cmd>...
  local maxp="$1"; shift
  local -a pids=() names=()
  for spec in "$@"; do
    local name="${spec%%::*}" cmd="${spec#*::}"
    while [ "${#pids[@]}" -ge "$maxp" ]; do
      wait "${pids[0]}" && say "  ok   ${names[0]}" || say "  FAIL ${names[0]}"
      pids=("${pids[@]:1}"); names=("${names[@]:1}")
    done
    wait_free
    say "  launch $name"
    ( echo "=== START $name $(date '+%F %T') ==="; bash -c "$cmd"; rc=$?; \
      echo "=== EXIT rc=$rc $(date '+%F %T') ==="; exit $rc ) \
      > "$LOGD/night_${name}.log" 2>&1 &
    pids+=($!); names+=("$name")
    sleep 12
  done
  if [ "${#pids[@]}" -gt 0 ]; then
    for i in "${!pids[@]}"; do
      wait "${pids[$i]}" && say "  ok   ${names[$i]}" || say "  FAIL ${names[$i]}"
    done
  fi
}

# ============================================================
# G1 · ternary seeds trained from scratch / 三分类补种子
# ============================================================
hr
say "G1  ternary r=16 training: seed 123, seed 2024   (est. 35-45 min)"
T=()
for S in 123 2024; do
  d="$SUPP/sft3_r16_s${S}"
  if [ -f "$d/adapter_model.safetensors" ]; then
    say "  $d exists, skip training"
    continue
  fi
  T+=("train_sft3_s${S}::python scripts/train_sft.py --dataset fpb --classes 3 --rank 16 --seed $S --split-seed 42 --bs 8 --epochs 3 --base $BASE --out $d")
done
[ "${#T[@]}" -gt 0 ] && run_pool 2 "${T[@]}" || say "  nothing to train"

# ============================================================
# G2 · truncate every new adapter / 截断
# ============================================================
hr
say "G2  truncation (QR-core SVD, ~1.3 s per adapter)"
for S in 123 2024; do
  SRC="$SUPP/sft3_r16_s${S}"
  [ -f "$SRC/adapter_model.safetensors" ] || { say "  skip $SRC (missing)"; continue; }
  for K in 8 4 2 1; do
    OUT="$SUPP/sft3_r${K}_s${S}"
    [ -f "$OUT/adapter_model.safetensors" ] && { say "  $OUT exists"; continue; }
    python scripts/make_lowrank_adapter.py --src "$SRC" --rank $K --out "$OUT" \
      >> "$LOGD/night_trunc.log" 2>&1 && say "  built sft3_r${K}_s${S}" || say "  FAIL sft3_r${K}_s${S}"
  done
done
# binary seeds only miss r=8 and r=2 / 二分类只缺 r8 和 r2
for S in 123 2024; do
  SRC="ckpts_sft/fpb_r16"
  for K in 8 2; do
    OUT="ckpts_supp/sft_r${K}_s${S}"
    [ -f "$OUT/adapter_model.safetensors" ] && { say "  $OUT exists"; continue; }
    python scripts/make_lowrank_adapter.py --src "$SRC" --rank $K --out "$OUT" \
      >> "$LOGD/night_trunc.log" 2>&1 && say "  built sft_r${K}_s${S}" || say "  FAIL sft_r${K}_s${S}"
  done
done
say "G2 done"

# ============================================================
# G3 · evaluate every missing cell / 评测所有缺失格子
# ============================================================
hr
say "G3  evaluation  (est. 6-10 min at 3-way)"
E=()
# --- ternary, 5 rungs x 2 seeds ---
for S in 123 2024; do
  for K in 16 8 4 2 1; do
    if [ "$K" = "16" ]; then D="$SUPP/sft3_r16_s${S}"; T="sft3_r16_s${S}"; else D="$SUPP/sft3_r${K}_s${S}"; T="sft3_r${K}_s${S}"; fi
    [ -f "$D/adapter_model.safetensors" ] || continue
    E+=("ev_${T}::python scripts/eval_cloze.py --dataset fpb --classes 3 --adapter $D --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_${T}.json")
  done
done
# --- binary r=8 / r=2 for both seeds ---
for S in 123 2024; do
  for K in 8 2; do
    D="$SUPP/sft_r${K}_s${S}"
    [ -f "$D/adapter_model.safetensors" ] || continue
    E+=("ev_sft_r${K}_s${S}::python scripts/eval_cloze.py --dataset fpb --classes 2 --adapter $D --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_sft_r${K}_s${S}.json")
  done
done
# --- FiQA with predictions saved (for McNemar) ---
E+=("ev_fiqa_r16_preds::python scripts/eval_cloze.py --dataset fiqa_sa --classes 3 --adapter ckpts_sft3/fpb_r16 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fiqa_sft3_r16.json")
E+=("ev_fiqa_r1_preds::python scripts/eval_cloze.py --dataset fiqa_sa --classes 3 --adapter ckpts_sft3/fpb_r1 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fiqa_sft3_r1.json")
# --- FPB with predictions saved, r=16 vs r=1 (binary + ternary) ---
E+=("evp_fpb_bin_r16::python scripts/eval_cloze.py --dataset fpb --classes 2 --adapter ckpts_sft/fpb_r16 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fpb_bin_r16.json")
E+=("evp_fpb_bin_r1::python scripts/eval_cloze.py --dataset fpb --classes 2 --adapter ckpts_sft/fpb_r1 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fpb_bin_r1.json")
E+=("evp_fpb_tri_r16::python scripts/eval_cloze.py --dataset fpb --classes 3 --adapter ckpts_sft3/fpb_r16 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fpb_tri_r16.json")
E+=("evp_fpb_tri_r1::python scripts/eval_cloze.py --dataset fpb --classes 3 --adapter ckpts_sft3/fpb_r1 --split test --holdout 0.2 --limit $LIMIT --save-preds --out outputs/reports/evalp_fpb_tri_r1.json")
# --- mask 60 / 80 on binary (variants already exist) ---
for P in 60 80; do
  for D in ckpts_supp/mask${P}_sft_fpb_r16_fix2; do
    [ -d "$D" ] || continue
    B=$(basename "$D")
    E+=("ev_${B}::python scripts/eval_cloze.py --dataset fpb --classes 2 --adapter $D --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_${B}.json")
  done
done

say "  ${#E[@]} evaluation jobs queued"
[ "${#E[@]}" -gt 0 ] && run_pool "$PAR" "${E[@]}" || say "  nothing to evaluate"

# ============================================================
# C1 · significance tests / 显著性
# ============================================================
hr
say "C1  McNemar + bootstrap CI"
python scripts/supp/sigtest.py --auto 2>&1 | tee -a "$REPORT"
# explicit FiQA pair (filenames carry a 'p' prefix so --auto misses them)
python scripts/supp/sigtest.py \
  --pair outputs/reports/evalp_fiqa_sft3_r16.json outputs/reports/evalp_fiqa_sft3_r1.json \
  2>&1 | tee -a "$REPORT"
python scripts/supp/sigtest.py \
  --pair outputs/reports/evalp_fpb_bin_r16.json outputs/reports/evalp_fpb_bin_r1.json \
  2>&1 | tee -a "$REPORT"
python scripts/supp/sigtest.py \
  --pair outputs/reports/evalp_fpb_tri_r16.json outputs/reports/evalp_fpb_tri_r1.json \
  2>&1 | tee -a "$REPORT"

# ============================================================
# C2 · final tables / 最终表
# ============================================================
hr
say "C2  regenerating tables"
python scripts/supp/s4_summarize.py --stamp "$STAMP" --outdir "$OUTD" 2>&1 | tee -a "$REPORT" || \
  python scripts/supp/s4_summarize.py --stamp "$STAMP" 2>&1 | tee -a "$REPORT"

# -------- compact morning digest / 早报摘要 --------
hr
say "MULTI-SEED SUMMARY"
python3 - > "$OUTD/digest.txt" 2>&1 <<'PYEOF'
import json, glob, os, statistics as st
R = "outputs/reports"
def acc(p):
    try:
        d = json.load(open(p)); return d.get("accuracy")
    except Exception:
        return None

print("\n[ Binary FPB — mean over available seeds ]")
for k, tag in [(16,"r16"),(8,"r8"),(4,"r4"),(2,"r2"),(1,"r1")]:
    vals = []
    for f in glob.glob(os.path.join(R, f"*_c2_r{k}.json")):
        a = acc(f)
        if a is not None: vals.append(a)
    for f in glob.glob(os.path.join(R, f"SFT_fpb_r{k}.json")):
        a = acc(f)
        if a is not None: vals.append(a)
    for f in glob.glob(os.path.join(R, f"eval_sft_r{k}_s*.json")):
        a = acc(f)
        if a is not None: vals.append(a)
    if vals:
        m = st.mean(vals)
        sd = st.pstdev(vals) if len(vals) > 1 else 0.0
        print(f"  r={k:<3} CR={16//k:>2}x  n_seeds={len(vals)}  mean={m:.4f}  sd={sd:.4f}  {[round(v,4) for v in vals]}")

print("\n[ Ternary FPB ]")
vals = []
for k in (16,8,4,2,1):
    v = []
    if os.path.exists(f"{R}/SFT3_fpb_r{k}.json"):
        a = acc(f"{R}/SFT3_fpb_r{k}.json")
        if a: v.append(a)
    v += [x for x in (acc(f) for f in glob.glob(os.path.join(R, f"eval_sft3_r{k}_s*.json"))) if x]
    if v:
        m = st.mean(v)
        print(f"  r={k:<3} CR={16//k:>2}x  n_seeds={len(v)}  mean={m:.4f}  {[round(x,4) for x in v]}")

print("\n[ Cross-dataset FiQA ]")
for n in ["eval_fiqa_base","eval_fiqa_sft3_r16","eval_fiqa_sft3_r1"]:
    p = f"{R}/{n}.json"
    if os.path.exists(p):
        print(f"  {n:<24} acc={acc(p)}")
PYEOF
cat "$OUTD/digest.txt" | tee -a "$REPORT"

# -------- done --------
T1=$(date +%s)
MIN=$(( (T1 - T0) / 60 ))
hr
say "ALL DONE  total ${MIN} min"
say "  tables : $PROJ/$OUTD/"
say "  report : $PROJ/$REPORT"
hr
nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader | tee -a "$REPORT"

if [ "${AUTO_SHUTDOWN:-0}" = "1" ]; then
  say "AUTO_SHUTDOWN=1 -> powering off in 120s.  Ctrl-C to cancel."
  say "AUTO_SHUTDOWN=1 -> 120 秒后关机，想取消就 Ctrl-C（或在另一窗口 shutdown -c）"
  sync
  shutdown -h +2 2>/dev/null || poweroff -d 120 2>/dev/null || say "  shutdown command unavailable, please power off manually"
else
  say "✅ 全部完成，可以手动关机了（如果是按小时计费的话）"
fi
