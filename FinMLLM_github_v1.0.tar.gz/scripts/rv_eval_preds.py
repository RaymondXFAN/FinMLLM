#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_eval_preds.py
# 与 eval_cloze.py 完全同逻辑，额外输出逐样本预测，供 McNemar 配对。
# Same inference path as eval_cloze.py, plus per-item predictions.
#
# 为什么不直接改 eval_cloze.py：
#   那是已经在用的脚本，动它有风险。这里把它的 load_rows / build /
#   label_token_ids 原样 import 进来，主循环照抄，只多存一个 preds 列表。
#   推理一个字都没改 —— 所以同一批样本上的 accuracy 必须一模一样，
#   下面那条验证命令就是查这个的。
#
# Why not patch eval_cloze.py:
#   That script is in active use. This one imports its loader and model
#   builder and reproduces the loop verbatim, adding only a preds list.
#   The accuracy must match the original exactly; the check below verifies it.
#
# Author : Raymond Xiaohu Fan
# Usage:
#   python scripts/rv_eval_preds.py --dataset fpb --classes 2 \
#       --adapter ckpts_sft/fpb_r16 --limit 300 --out /tmp/t.json
# ============================================================
import os, sys, json, time, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eval_cloze as ec          # 复用，不复制 / reuse, do not duplicate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="fpb", choices=["fpb", "fiqa_sa", "tfns"])
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--base", default=os.environ.get("BASE_MODEL", "/root/autodl-tmp/models/Qwen2.5-3B"))
    ap.add_argument("--limit", type=int, default=0, help="0 = full partition / 0 表示全量")
    ap.add_argument("--classes", type=int, default=3, choices=[2, 3])
    ap.add_argument("--split", default="test")
    ap.add_argument("--holdout", type=float, default=0.2)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    import torch
    binary = (args.classes == 2)

    rows = ec.load_rows(args.dataset, args.limit, binary=binary,
                        split=args.split, holdout=args.holdout)
    if binary:
        ec.LABELS = ["negative", "positive"]
    labels = ec.LABELS

    print("=" * 72)
    print(f" PREDS EVAL | {args.dataset} | n={len(rows)} | classes={args.classes} | {args.adapter}")
    print("=" * 72)
    if not rows:
        print("no rows"); return 2

    tok, model = ec.build(args.base, args.adapter)
    ids = ec.label_token_ids(tok)
    print(" label token ids:", ids)

    # 空上下文校准，与原脚本一致 / null-context calibration, same as original
    null_enc = tok("Sentence: \nSentiment:", return_tensors="pt").to("cuda")
    with torch.no_grad():
        null_logits = model(**null_enc).logits[0, -1].clone()
    print(" calibration: ON")

    conf = {a: {b: 0 for b in labels} for a in labels}
    preds = []
    t0 = time.time()
    for i, (text, gold) in enumerate(rows):
        prompt = ec.PROMPT.format(text[:800])
        enc = tok(prompt, return_tensors="pt", truncation=True, max_length=1024).to("cuda")
        with torch.no_grad():
            logits = model(**enc).logits[0, -1]
        scores = {lab: float(logits[ids[lab]].item()) - float(null_logits[ids[lab]].item())
                  for lab in labels}
        pred = max(scores, key=scores.get)
        conf[gold][pred] += 1
        preds.append({"i": i, "gold": gold, "pred": pred, "ok": int(pred == gold)})
        if (i + 1) % 100 == 0:
            acc = sum(conf[a][a] for a in labels) / (i + 1)
            print(f"  {i+1}/{len(rows)}  running_acc={acc:.4f}  {time.time()-t0:.0f}s", flush=True)

    correct = sum(conf[a][a] for a in labels)
    acc = correct / len(rows)
    print("-" * 72)
    print(f" accuracy = {acc:.4f}  ({correct}/{len(rows)})  dur={time.time()-t0:.0f}s")

    out = {"dataset": args.dataset, "adapter": args.adapter, "n": len(rows),
           "classes": args.classes, "labels": labels, "accuracy": acc,
           "confusion": conf, "mode": "cloze", "split": args.split,
           "holdout": args.holdout, "dur_sec": round(time.time() - t0, 1),
           "preds": preds}
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    json.dump(out, open(args.out, "w"), indent=2, ensure_ascii=False)
    print(f" saved -> {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
