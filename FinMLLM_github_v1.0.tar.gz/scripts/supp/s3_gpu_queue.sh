#!/usr/bin/env bash
# ============================================================
# FinMLLM / supp / s3_gpu_queue.sh
# The GPU half of the supplementary experiments. Everything here needs a GPU.
# 补充实验的 GPU 半边 —— 这里每条命令都要占显卡。
#
# Phases / 阶段:
#   P1  train r=64 "over-parameterised" adapters   (3-way parallel)
#       r=64 过参数化对照训练（三路并行）
#       -> if an adapter allowed 4x the rank still learns a low-rank solution,
#          then "low effective rank" is a property of the task, not of the budget.
#       -> 如果给了 4 倍秩却仍学出低秩解，那"有效秩低"是任务性质，不是预算使然。
#   P2  one more seed                               (1-way)
#   P3  truncate r=64 down to 16x / 8x / 4x and evaluate  (3-way parallel)
#       r=64 截到 16×/8×/4× 并评测
#   P4  evaluate every CPU-built variant (energy / randdir / mask)  (3-way)
#       Python 侧造好的变体逐个评测
#
# Author : Raymond Xiaohu Fan
# Note   : A 4090 with 24 GB and a 4.2 GB peak means three at a time, not one.
#          24G 的 4090、4.2G 的峰值 —— 该开三路，不该一路空转。
# Updated: 2026-10-25
#
# Usage / 用法:
#   bash scripts/supp/s3_gpu_queue.sh                # full run
#   PAR=2 bash scripts/supp/s3_gpu_queue.sh          # be gentle / 保守一点
#   SKIP_TRAIN=1 bash scripts/supp/s3_gpu_queue.sh   # only evaluate existing
# ============================================================
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
cd "$PROJ" || { echo "FATAL: $PROJ not found"; exit 1; }

STAMP="${STAMP:-$(date +%Y%m%d_%H%M)}"
PAR="${PAR:-3}"                     # parallel GPU jobs / GPU 并行路数
MIN_FREE="${MIN_FREE:-6000}"        # MiB needed before launching a job / 启动前需要的最小空闲显存
LIMIT="${EVAL_LIMIT:-999999}"       # eval sample cap; keep identical across runs / 评测样本上限，务必一致
BASE="${BASE_MODEL:-/root/autodl-tmp/models/Qwen2.5-3B}"
# ---- r=64 control knobs / r=64 对照的旋钮 ----
# r=64 has 4x the LoRA parameters, so with the SAME step budget each parameter
# gets a quarter of the updates -> underfitting. Raise EPOCHS when retraining.
# r=64 的 LoRA 参数是 4 倍，步数不变就等于每个参数只拿到 1/4 的更新 -> 欠拟合。
# 重训时把 EPOCHS 提上去，或者用 SUFFIX 另存一版，别覆盖旧结果。
EPOCHS="${EPOCHS:-3}"
LR="${LR:-2e-4}"
SUF="${SUFFIX:-}"
SUPP="ckpts_supp"
LOGD="outputs/logs/supp"
mkdir -p "$SUPP" "$LOGD" outputs/reports

export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_XET=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export TOKENIZERS_PARALLELISM=false

say()  { echo "[$(date +%H:%M:%S)] $*"; }
dn()   { echo "[$(date +%H:%M:%S)] ✔ $*"; }
bad()  { echo "[$(date +%H:%M:%S)] ✘ $*"; }

# ---- GPU gate: never launch into a nearly-full card -------------------------
# 显存闸门：显存不够就先等，绝不硬闯
wait_free() {
  local need="${1:-$MIN_FREE}" tries=0
  while :; do
    local free
    free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
    free=${free:-0}
    if [ "$free" -ge "$need" ]; then return 0; fi
    tries=$((tries+1))
    if [ $((tries % 10)) -eq 1 ]; then
      say "GPU gate: ${free} MiB free < ${need} needed, waiting (try $tries)"
      nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu --format=csv,noheader
    fi
    sleep 30
  done
}

# ---- run one command in the background, log it, never abort the queue -------
# 后台跑一条命令，单独落日志，单条失败不拖垮队列
launch() {
  local name="$1"; shift
  wait_free
  local log="${LOGD}/${name}.log"
  say "launch  $name  -> $log"
  ( echo "=== START $name $(date '+%F %T') ==="; \
    "$@" ; rc=$?; \
    echo "=== EXIT  $name rc=$rc $(date '+%F %T') ==="; \
    exit $rc ) >"$log" 2>&1 &
  LAST_PID=$!
  sleep 20   # let CUDA context come up so the gate sees real usage / 让显存先涨起来
}

run_group() {   # run_group <parallel> <name:cmd>...
  local maxp="$1"; shift
  local -a pids=() names=()
  for spec in "$@"; do
    local name="${spec%%::*}"
    local cmd="${spec#*::}"
    while [ "${#pids[@]}" -ge "$maxp" ]; do
      wait "${pids[0]}" && dn "ok   ${names[0]}" || bad "fail ${names[0]}"
      pids=("${pids[@]:1}"); names=("${names[@]:1}")
    done
    wait_free
    local log="${LOGD}/${name}.log"
    say "launch  $name"
    # Capture the real exit code: without `rc=$?; exit $rc` the subshell's last
    # command is `echo`, so `wait` always reports 0 and every failure looks fine.
    # 必须显式 exit $rc：否则子 shell 最后一条是 echo，wait 永远返回 0，
    # 所有失败都会伪装成成功（上次 energy 全挂却全显示 ok 就是这么来的）。
    ( echo "=== START $name $(date '+%F %T') ==="; \
      bash -c "$cmd"; rc=$?; \
      echo "=== EXIT  rc=$rc $(date '+%F %T') ==="; exit $rc ) >"$log" 2>&1 &
    pids+=($!); names+=("$name")
    sleep 15
  done
  if [ "${#pids[@]}" -gt 0 ]; then
    for i in "${!pids[@]}"; do
      wait "${pids[$i]}" && dn "ok   ${names[$i]}" || bad "fail ${names[$i]}"
    done
  fi
}

echo "============================================================"
echo " SUPPLEMENTARY GPU QUEUE   stamp=${STAMP}  parallel=${PAR}"
echo "============================================================"
cat <<'PLAN'
 Time budget (measured on Qwen2.5-3B + QLoRA, 4090, r=16 baseline)
 时间预算（基于 3B + QLoRA、4090、r=16 实测外推）

   P1  r=64 training, rolling pool of 4 jobs      ~35-40 min
       └ bin  : 588 steps x2.1s = 21 min each
       └ tri  : 1452 steps      = 42 min  <- the long pole / 长杆
   P3  truncate + evaluate 8 runs, 3-way          ~3-5 min
   P4  evaluate ~26 variants, 3-way               ~9-12 min
   ------------------------------------------------------------
   GPU total                                      ~50-60 min
   CPU line (audit + variant building) runs at    ~8 min (parallel, off-card)

   If you only need the binary control, cut tri out: ~25 min.
   只要二分类对照的话可以砍掉 tri，约 25 分钟。
PLAN
nvidia-smi --query-gpu=name,memory.total,memory.used,utilization.gpu --format=csv

if [ "${DRY_RUN:-0}" = "1" ]; then
  echo
  say "DRY_RUN=1 -> printing the plan and exiting. Nothing was launched."
  say "P1 jobs:"
  echo "   r64_bin_s42   classes=2 seed=42"
  echo "   r64_bin_s123  classes=2 seed=123"
  echo "   r64_bin_s2024 classes=2 seed=2024"
  echo "   r64_tri_s42   classes=3 seed=42   (long pole)"
  say "P3 = truncate each r=64 to r=4/8/16 and evaluate at EVAL_LIMIT=$LIMIT"
  say "P4 = evaluate every variant built by s2_make_variants.py"
  exit 0
fi

# =============================================================
# P1 · r=64 over-parameterised controls  /  过参数化对照
#     All four run in ONE rolling pool. The pool refills a slot the moment
#     any job finishes, so the long ternary job never blocks the short ones.
#     四个任务放进同一个滚动池：谁先跑完谁让位，长任务不会拖住短任务。
#     把 P1/P2 分成两批串行会白等 15 分钟，这一步就是省那 15 分钟。
# =============================================================
if [ "${SKIP_TRAIN:-0}" != "1" ]; then
  echo; say "===== P1  r=64 over-parameterised training (rolling pool, PAR=$PAR) ====="
  say "  expected: ~35-40 min total (ternary job is the long pole) / 预计 35-40 分钟"

  T=()
  say "  EPOCHS=$EPOCHS  LR=$LR  SUFFIX='${SUF}'"
  T+=("r64_bin_s42${SUF}::python scripts/train_sft.py --dataset fpb --classes 2 --rank 64 --seed 42 --split-seed 42 --bs 8 --epochs $EPOCHS --lr $LR --base $BASE --out $SUPP/r64_bin_s42${SUF}")
  T+=("r64_bin_s123${SUF}::python scripts/train_sft.py --dataset fpb --classes 2 --rank 64 --seed 123 --split-seed 42 --bs 8 --epochs $EPOCHS --lr $LR --base $BASE --out $SUPP/r64_bin_s123${SUF}")
  T+=("r64_tri_s42${SUF}::python scripts/train_sft.py --dataset fpb --classes 3 --rank 64 --seed 42 --split-seed 42 --bs 8 --epochs $EPOCHS --lr $LR --base $BASE --out $SUPP/r64_tri_s42${SUF}")
  T+=("r64_bin_s2024${SUF}::python scripts/train_sft.py --dataset fpb --classes 2 --rank 64 --seed 2024 --split-seed 42 --bs 8 --epochs $EPOCHS --lr $LR --base $BASE --out $SUPP/r64_bin_s2024${SUF}")

  # LPT rule (Longest Processing Time first): launch the 42-min ternary job
  # FIRST, not last. If it queues behind three 21-min jobs it only starts at
  # t=21 and the whole pool takes 63 min instead of 42.
  # LPT 法则：最长的任务必须最先上。若排在三个 21 分钟的任务后面，
  # 它要等到 t=21 才开始，整个池子变成 63 分钟而不是 42 分钟。
  # order: tri(1452 steps) -> bin x3 (588 steps each)
  T_reordered=("${T[2]}" "${T[0]}" "${T[1]}" "${T[3]}")
  say "  launch order (LPT): tri_s42 -> bin_s42 -> bin_s123 -> bin_s2024"
  run_group "$PAR" "${T_reordered[@]}"
else
  say "SKIP_TRAIN=1 -> training skipped / 跳过训练"
fi

# =============================================================
# P3 · truncate the r=64 adapters, then evaluate  /  截断 + 评测
# =============================================================
# ---- health gate: an under-trained adapter makes the whole control meaningless
# 健康闸门：欠拟合的 adapter 会让整个对照失去意义，必须先把 acc 打出来看
echo; say "===== P2  training health check (full accuracy of each r=64 adapter) ====="
H=()
for spec in "bin 2" "tri 3"; do
  set -- $spec; task=$1; cls=$2
  for seed in 42 123 2024; do
    d="$SUPP/r64_${task}_s${seed}${SUF}"
    [ -f "$d/adapter_model.safetensors" ] || continue
    H+=("eval_health_${task}_s${seed}${SUF}::python scripts/eval_cloze.py --dataset fpb --classes $cls --adapter $d --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_health_${task}_s${seed}${SUF}.json")
  done
done
[ "${#H[@]}" -gt 0 ] && run_group "$PAR" "${H[@]}"
echo
say " READ the health numbers above. A healthy binary adapter should be ~0.98."
say " 健康标准：二分类应该在 0.98 上下；明显偏低说明欠拟合，重训时加大 EPOCHS。"

echo; say "===== P3  truncate r=64 -> 4 / 8 / 16 and evaluate ====="
E=()
for task in bin tri; do
  src="$SUPP/r64_${task}_s42${SUF}"
  [ -f "$src/adapter_model.safetensors" ] || { bad "missing $src, skip P3-$task"; continue; }
  for k in 4 8 16; do
    out="$SUPP/r64_${task}_r${k}${SUF}"
    python scripts/make_lowrank_adapter.py --src "$src" --rank "$k" --out "$out" \
      >> "${LOGD}/mk_r64_${task}_r${k}.log" 2>&1 \
      && dn "built $out" || bad "build failed $out"
    cls=2; [ "$task" = "tri" ] && cls=3
    E+=("eval_r64_${task}_r${k}${SUF}::python scripts/eval_cloze.py --dataset fpb --classes $cls --adapter $out --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_r64_${task}_r${k}${SUF}.json")
  done
  # untruncated r=64 baseline / 未截断的 r=64 基线
  cls=2; [ "$task" = "tri" ] && cls=3
  E+=("eval_r64_${task}_full${SUF}::python scripts/eval_cloze.py --dataset fpb --classes $cls --adapter $src --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_r64_${task}_full${SUF}.json")
done
[ "${#E[@]}" -gt 0 ] && run_group "$PAR" "${E[@]}"

# =============================================================
# P4 · evaluate every CPU-built variant  /  评测 Python 侧造好的变体
# =============================================================
echo; say "===== P4  evaluate energy / randdir / mask variants ====="
E2=()
add_evals() {   # add_evals <glob-prefix> <default-classes>
  local prefix="$1" default_cls="$2"
  for d in ${SUPP}/${prefix}*; do
    [ -d "$d" ] || continue
    local b; b=$(basename "$d")
    # Never hardcode classes: a ternary variant must be evaluated as ternary.
    # 绝不能写死 classes —— 三分类的变体必须按三分类评测。
    local cls="$default_cls"
    case "$b" in
      *sft3*|*_tri*|*tri_*) cls=3 ;;
    esac
    E2+=("eval_${b}::python scripts/eval_cloze.py --dataset fpb --classes ${cls} --adapter $d --split test --holdout 0.2 --limit $LIMIT --out outputs/reports/eval_${b}.json")
  done
}
add_evals "energy_" 2
add_evals "randdir_" 2
add_evals "mask" 2
[ "${#E2[@]}" -gt 0 ] && run_group "$PAR" "${E2[@]}" || say "no CPU-built variants found (run s2_make_variants.py first)"

echo
echo "============================================================"
dn "GPU QUEUE FINISHED  stamp=${STAMP}"
echo " logs   : $LOGD/*.log"
echo " ckpts  : $SUPP/"
echo " evals  : outputs/reports/eval_*.json"
echo " next   : python scripts/supp/s4_summarize.py --stamp ${STAMP}"
echo "============================================================"
