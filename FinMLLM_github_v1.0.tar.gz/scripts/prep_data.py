#!/usr/bin/env python3
# ============================================================
# FinMLLM / prep_data.py
# Unify raw datasets into jsonl and split EDGAR into four business lines.
# 把原始数据统一成 jsonl，并按 EDGAR SIC 切成四条业务线。
#
# Author : Raymond Xiaohu Fan
# Note   : Garbage in, garbage out — clean the labels first. / 垃圾进垃圾出，先把标签洗干净。
# Updated: 2026-10-19
# ============================================================

"""把下载到的原始数据统一成训练/评测用的 jsonl，并按 EDGAR SIC 切出四条业务线。

输出：
  data/unified/{fpb,fiqa_sa,tfns,finqa}.jsonl   统一格式 {id,text,label,source,split}
  data/domains/{bank,insurance,securities,regulator}.jsonl   {id,text,domain,sic,split}
"""
import os, sys, json, glob, random

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
DATA = os.path.join(ROOT, "data")
RAW = os.path.join(DATA, "raw")
UNI = os.path.join(DATA, "unified"); DOM = os.path.join(DATA, "domains")
os.makedirs(UNI, exist_ok=True); os.makedirs(DOM, exist_ok=True)
random.seed(42)

SIC_RANGES = {"bank": (6020, 6029), "insurance": (6300, 6399), "securities": (6200, 6299)}

def load_ds(path):
    from datasets import load_from_disk
    return load_from_disk(path)

def pick(d, names):
    for n in names:
        if n in d.column_names:
            return n
    return None

def dump(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  ✅ {os.path.basename(path):<24}{len(rows)} 条")

def unify_sentiment(name, path, text_cols, label_cols):
    if not os.path.isdir(path):
        print(f"  ⚠️  {name} 缺失，跳过"); return
    ds = load_ds(path)
    rows = []
    for split in ds.keys():
        d = ds[split]
        tc = pick(d, text_cols); lc = pick(d, label_cols)
        if not tc or not lc:
            print(f"  ⚠️  {name}[{split}] 找不到字段，可用：{d.column_names}"); continue
        for i, ex in enumerate(d):
            rows.append({"id": f"{name}-{split}-{i}", "text": str(ex[tc]),
                         "label": ex[lc], "source": name, "split": split})
    dump(os.path.join(UNI, f"{name}.jsonl"), rows)

def unify_finqa():
    p = os.path.join(RAW, "finqa")
    if not os.path.isdir(p): print("  ⚠️  finqa 缺失，跳过"); return
    ds = load_ds(p); rows = []
    for split in ds.keys():
        d = ds[split]
        qc = pick(d, ["question", "query"]); ac = pick(d, ["answer", "answers"])
        if not qc or not ac:
            print(f"  ⚠️  finqa[{split}] 字段: {d.column_names}"); continue
        for i, ex in enumerate(d):
            rows.append({"id": f"finqa-{split}-{i}", "text": f"Q: {ex[qc]}\nA:",
                         "label": str(ex[ac]), "source": "finqa", "split": split})
    dump(os.path.join(UNI, "finqa.jsonl"), rows)

def split_domains():
    p = os.path.join(RAW, "edgar_10k")
    if not os.path.isdir(p):
        print("  ⚠️  edgar_10k 缺失 → 业务线无法自动切分")
        print("     解决：下载 astr010/sec-10k-markdown-compressed，或提供带 SIC 的 jsonl")
        return
    ds = load_ds(p)
    split = list(ds.keys())[0]; d = ds[split]
    txt = pick(d, ["text", "markdown", "content", "mdna", "document"])
    sic = pick(d, ["sic", "sic_code", "SIC", "industry_code"])
    if not txt or not sic:
        print(f"  ⚠️  EDGAR 字段不足：text={txt}, sic={sic}, 可用={d.column_names}")
        print("     需先补充 SIC 字段（可从 SEC company_tickers / submissions API 关联）")
        return
    buckets = {k: [] for k in SIC_RANGES}
    for i, ex in enumerate(d):
        try: s = int(str(ex[sic]).strip()[:4])
        except Exception: continue
        for dom, (lo, hi) in SIC_RANGES.items():
            if lo <= s <= hi:
                buckets[dom].append({"id": f"edgar-{i}", "text": str(ex[txt])[:8000],
                                     "domain": dom, "sic": s, "split": "train"})
                break
    for dom, rows in buckets.items():
        dump(os.path.join(DOM, f"{dom}.jsonl"), rows)

if __name__ == "__main__":
    print("=" * 70); print("数据统一与业务线切分"); print("=" * 70)
    print("[1/3] 情感三件套")
    unify_sentiment("fpb",     os.path.join(RAW, "fpb"),     ["sentence","text"], ["label","sentiment"])
    unify_sentiment("fiqa_sa", os.path.join(RAW, "fiqa_sa"), ["sentence","text"], ["label"])
    unify_sentiment("tfns",    os.path.join(RAW, "tfns"),    ["text","sentence"], ["label"])
    print("[2/3] FinQA")
    unify_finqa()
    print("[3/3] EDGAR 业务线切分")
    split_domains()
    print("\n完成。下一步：python scripts/gates/g2_data.py")
