#!/usr/bin/env bash
# ============================================================
# FinMLLM / deploy_remote.sh
# Server side: idempotent deployment that never touches data or results.
# 服务器端：幂等部署，绝不覆盖数据与实验结果。
#
# Author : Raymond Xiaohu Fan
# Note   : Idempotent or bust. / 不幂等的部署脚本就是在给自己挖坑。
# Updated: 2026-10-19
# ============================================================

# ============================================================
# 在【服务器】执行：幂等部署，保护已有数据与实验结果
# 用法： cd /root/autodl-tmp/FinMLLM && bash scripts/deploy_remote.sh
# ============================================================
set -euo pipefail

cd "$(dirname "$0")/.."
PROJ="$(pwd)"
echo "项目目录：$PROJ"

echo "=== [1/5] 结构检查 ==="
for d in scripts scripts/gates configs; do
  [ -d "$d" ] || { echo "❌ 缺少 $d，包可能不完整"; exit 1; }
done
echo "✅ 目录结构完整"

echo "=== [2/5] 创建缺失目录（已存在则跳过，幂等） ==="
mkdir -p data/{raw,unified,domains} shared forks outputs/{logs,tables,figs}
for f in A_flagship B_method C_economics D_framework; do
  mkdir -p "forks/$f"/{configs,ckpts,drafts,outputs/{tables,figs,logs}}
done
echo "✅ 目录就绪"

echo "=== [3/5] 软链共享资产（不复制、不占空间） ==="
# HF cache (shared by symlink, never copied)
# HF 缓存（软链共享，绝不复制）
for cand in /root/autodl-tmp/hf_home /root/autodl-tmp/FinMLLM/shared/hf_home; do
  if [ -d "$cand" ] && [ "$cand" != "$PROJ/shared/hf_home" ]; then
    ln -sfn "$cand" "$PROJ/shared/hf_home"
    echo "  ✅ hf_home -> $cand"
    break
  fi
done
[ -d "$PROJ/shared/hf_home" ] || mkdir -p "$PROJ/shared/hf_home"

# Legacy FinEval dataset
# 旧 FinEval
for cand in /root/FinMeshingLLM/MeshingLLM/data/FinEval \
            /root/autodl-tmp/MeshingLLM/data/FinEval; do
  [ -d "$cand" ] && { ln -sfn "$cand" "$PROJ/shared/FinEval"; echo "  ✅ FinEval -> $cand"; break; }
done

# Legacy meshing kernel from the conference version
# 旧内核
OLD=/root/FinMeshingLLM/MeshingLLM/code/meshing.py
[ -f "$OLD" ] && mkdir -p "$PROJ/shared/legacy" && cp -n "$OLD" "$PROJ/shared/legacy/meshing_v1.py" 2>/dev/null \
  && echo "  ✅ 已备份会议版内核 shared/legacy/meshing_v1.py"

echo "=== [4/5] 数据保护检查（绝不覆盖） ==="
for d in data/raw data/unified data/domains; do
  n=$(find "$d" -type f 2>/dev/null | wc -l | tr -d ' ')
  echo "  $d : $n 个文件（保留不动）"
done
for f in forks/*/ckpts; do
  n=$(find "$f" -type f 2>/dev/null | wc -l | tr -d ' ')
  echo "  $f : $n 个文件（保留不动）"
done

echo "=== [5/5] 生成环境变量 ==="
cat > setup_env.sh <<EOF
export PROJ=$PROJ
export HF_HOME=$PROJ/shared/hf_home
export HF_ENDPOINT=https://hf-mirror.com
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
EOF
echo "✅ source $PROJ/setup_env.sh"

echo ""
echo "🎉 服务器部署完成（数据与结果已保护）"
echo "下一步： bash scripts/init_forks.sh"
