#!/usr/bin/env bash
# FinMLLM / rv_fiqa_pipeline.sh
# FiQA 全流程：重建数据 -> 训 2 个 adapter -> 截断到 r=1 -> 评测 -> 谱分析。
# FiQA end-to-end: rebuild data, train two adapters, truncate, evaluate, spectral.
# Author: Raymond Xiaohu Fan
set -u
cd /root/autodl-tmp/FinMLLM || exit 1
mkdir -p logs outputs/reports/fiqa ckpts_rv
stamp () { date '+[%F %T]'; }
say () { echo "$(stamp) $*"; }
fail=0

say "=== [1/5] rebuild FiQA data ==="
python scripts/supp/fix_fiqa.py || { say "FAIL data"; exit 1; }
python -c "
import json,collections
c=collections.Counter()
for l in open('data/unified/fiqa_sa.jsonl'):
    c[json.loads(l)['label']]+=1
print('  labels:', dict(c))
"

say "=== [2/5] train FiQA adapters ==="
for S in 42 123; do
  OUT=ckpts_rv/fiqa_r16_s${S}
  [ -f "$OUT/adapter_model.safetensors" ] && { say "  skip $OUT"; continue; }
  say "  train fiqa s$S"
  python scripts/rv_train_sft.py --dataset fiqa_sa --classes 3 --rank 16 \
    --seed $S --split-seed 42 --holdout 0.2 --split train \
    --out "$OUT" >> logs/fiqa_train.log 2>&1 \
    && say "    ok" || { say "    FAIL"; fail=$((fail+1)); }
done
[ "$fail" -gt 0 ] && { say "!!! 训练失败，中止"; exit 1; }

say "=== [3/5] truncate to r=1 ==="
for S in 42 123; do
  OUT=ckpts_rv/fiqa_r1_s${S}
  [ -f "$OUT/adapter_model.safetensors" ] && { say "  skip $OUT"; continue; }
  python scripts/rv_lowrank.py --src ckpts_rv/fiqa_r16_s${S} --rank 1 --out "$OUT" 2>&1 | tail -2
done

say "=== [4/5] evaluate (full partition) ==="
for S in 42 123; do
  for R in 16 1; do
    OUT=outputs/reports/fiqa/fiqa_s${S}_r${R}.json
    [ -s "$OUT" ] && { say "  skip $OUT"; continue; }
    say "  eval s$S r$R"
    python scripts/rv_eval_preds.py --dataset fiqa_sa --classes 3 \
      --adapter ckpts_rv/fiqa_r${R}_s${S} --limit 0 --out "$OUT" \
      >/dev/null 2>>logs/fiqa_err.log || { say "    FAIL"; fail=$((fail+1)); }
  done
done

say "=== [5/5] spectral ==="
python scripts/spectral_table3.py --batch \
  fiqa_r16_s42:ckpts_rv/fiqa_r16_s42 \
  fiqa_r16_s123:ckpts_rv/fiqa_r16_s123 \
  >> logs/fiqa_spectral.log 2>&1

say "=== ALL DONE, failures=$fail ==="
