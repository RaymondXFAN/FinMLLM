#!/usr/bin/env python3
# ============================================================
# FinMLLM / g4_profile.py
# G4 resource probe: scan batch sizes, report VRAM and throughput.
# G4 资源探针：扫描 batch，报告显存占用与吞吐。
#
# Author : Raymond Xiaohu Fan
# Note   : Measure, don't guess. / 测，别猜。
# Updated: 2026-10-19
# ============================================================

"""G4 · 资源探针（需 GPU）：决定"并行还是串行"的唯一依据。

扫描 batch ∈ {1,2,4,8}，记录峰值显存与吞吐，输出 outputs/logs/g4_profile.json。
判定规则：
  - 峰值显存 > 20GB           → 只能串行，1 进程
  - 峰值显存 11~20GB          → 串行，但可用 gradient checkpointing 提 batch
  - 峰值显存 < 11GB           → 可尝试 2 进程并行（同卡共享）
"""
import os, sys, json, time, torch

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
MODEL = os.environ.get("BASE_MODEL", "Qwen/Qwen2.5-7B")
OUT = os.path.join(ROOT, "outputs/logs"); os.makedirs(OUT, exist_ok=True)

def build():
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                             bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
    tok = AutoTokenizer.from_pretrained(MODEL, trust_remote_code=True)
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    m = AutoModelForCausalLM.from_pretrained(MODEL, quantization_config=bnb,
                                             device_map={"": 0}, trust_remote_code=True)
    m = prepare_model_for_kbit_training(m)
    m = get_peft_model(m, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias="none",
                                     task_type="CAUSAL_LM",
                                     target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]))
    return tok, m

def main():
    if not torch.cuda.is_available():
        print("❌ 无 GPU，跳过 G4"); return 5
    print("=" * 70); print(f"G4 · 资源探针 | {MODEL}"); print("=" * 70)
    tok, model = build()
    total = torch.cuda.get_device_properties(0).total_memory / 1024**3
    print(f"显存总量 {total:.1f} GB")

    text = ("### Instruction:\nSummarize the credit risk of the following disclosure.\n"
            "### Disclosure:\nThe bank's non-performing loan ratio rose to 2.1%, with provisioning "
            "coverage declining to 148%, while capital adequacy remained above the regulatory floor.\n"
            "### Response:\nRising credit risk with adequate capital.<|endoftext|>")
    results = []
    opt = None
    for bs in [1, 2, 4, 8]:
        try:
            torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
            enc = tok([text] * bs, return_tensors="pt", padding=True, truncation=True, max_length=512).to("cuda")
            labels = enc["input_ids"].clone()
            labels[enc["attention_mask"] == 0] = -100
            model.train()
            if opt is None:
                opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=2e-4)
            # warmup
            out = model(**enc, labels=labels); out.loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
            torch.cuda.synchronize(); t0 = time.time()
            N = 3
            for _ in range(N):
                out = model(**enc, labels=labels)
                out.loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
            torch.cuda.synchronize(); dt = (time.time() - t0) / N
            peak = torch.cuda.max_memory_allocated() / 1024**3
            ntok = int(enc["attention_mask"].sum().item())
            rec = {"batch": bs, "peak_gb": round(peak, 2), "sec_per_step": round(dt, 3),
                   "tokens_per_sec": round(ntok / dt, 1), "status": "ok"}
            print(f"  batch={bs:<2}  peak={peak:5.2f}GB  {dt:5.2f}s/step  {ntok/dt:7.1f} tok/s")
            results.append(rec)
        except torch.cuda.OutOfMemoryError:
            print(f"  batch={bs:<2}  ❌ OOM")
            results.append({"batch": bs, "status": "oom"})
            torch.cuda.empty_cache()
            break

    ok = [r for r in results if r.get("status") == "ok"]
    best = max(ok, key=lambda r: r["tokens_per_sec"]) if ok else None
    advice = "无法评估"
    if best:
        if best["peak_gb"] < 11:
            advice = "峰值<11GB：可尝试 2 进程并行（各占半卡），但需实测争用"
        elif best["peak_gb"] < 20:
            advice = "峰值11~20GB：建议串行（1进程），可开 gradient_checkpointing 提 batch"
        else:
            advice = "峰值>20GB：必须串行，且不能再开第二个进程"
    print("-" * 70)
    print(f"最佳吞吐配置：{best}")
    print(f"👉 结论：{advice}")
    with open(os.path.join(OUT, "g4_profile.json"), "w") as f:
        json.dump({"model": MODEL, "total_gb": round(total, 2), "results": results,
                   "advice": advice, "ts": time.strftime("%Y-%m-%d %H:%M:%S")}, f, indent=2, ensure_ascii=False)
    print(f"已保存 -> {OUT}/g4_profile.json")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
