#!/usr/bin/env python3
# ============================================================
# FinMLLM / fetch_raw.py
# Download raw dataset files straight from the Hub, bypassing both
# loading scripts and gated loaders. No load_dataset() anywhere.
# 直接从 Hub 抓原始文件，绕过 script 型数据集与 gated 数据集，
# 全程不调用 load_dataset()。
#
# Author : Raymond Xiaohu Fan
# Note   : If the loader fights you, go around it. / 加载器跟你较劲，就绕过去。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/fetch_raw.py            # dry-run: list files and pick candidates
#   python scripts/fetch_raw.py --apply    # download the chosen files
# ============================================================
import os, sys, argparse, time, json

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
RAW = os.path.join(ROOT, "data", "raw")
os.makedirs(RAW, exist_ok=True)

# repo -> local subdir. Ordered by preference; first hit wins.
# 仓库 -> 本地子目录；按优先级排序，第一个成功即用。
CANDIDATES = {
    "fpb": [
        "takala/financial_phrasebank",
        "ChanceFocus/financial_phrasebank",
    ],
    "fiqa_sa": [
        "pauri32/fiqa-2018",
        "TheFinAI/fiqa-sentiment-classification",
    ],
    "finqa": [
        "dreamerdeo/finqa",
        "ibm/finqa",
    ],
    "edgar_10k": [
        "astr010/sec-10k-markdown-compressed",
    ],
}

# Only these extensions are worth downloading directly.
# 只下这些后缀的文件。
WANTED_EXT = (".parquet", ".csv", ".json", ".jsonl", ".zip", ".tar.gz", ".zst", ".gz", ".arrow")
MAX_FILE_GB = 3.0


def human(n):
    for u in ["B", "KB", "MB", "GB"]:
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


def list_files(repo):
    """Return file list, or an error string. / 返回文件列表或错误信息。"""
    from huggingface_hub import list_repo_files
    try:
        files = list_repo_files(repo_id=repo, repo_type="dataset")
        return files, None
    except Exception as e:
        return None, f"{type(e).__name__}: {str(e)[:160]}"


def pick(files):
    out = []
    for f in files:
        low = f.lower()
        if low.endswith(WANTED_EXT):
            out.append(f)
    # Prefer parquet, then json/jsonl, then csv, then archives
    def rank(p):
        l = p.lower()
        for i, ext in enumerate([".parquet", ".jsonl", ".json", ".csv", ".zip", ".tar.gz", ".arrow"]):
            if l.endswith(ext):
                return i
        return 99
    return sorted(out, key=rank)


def download(repo, rel, dest_dir):
    from huggingface_hub import hf_hub_download
    local = hf_hub_download(repo_id=repo, filename=rel, repo_type="dataset", local_dir=dest_dir)
    return local


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="actually download / 真正下载")
    ap.add_argument("--only", default=None, help="only one target, e.g. fpb / 只处理一个目标")
    args = ap.parse_args()

    print("=" * 76)
    print(f" RAW FILE FETCHER  |  endpoint={os.environ.get('HF_ENDPOINT','(default)')}")
    print(f" mode={'APPLY' if args.apply else 'DRY-RUN'}  root={RAW}")
    print("=" * 76)

    summary = []
    for target, repos in CANDIDATES.items():
        if args.only and args.only != target:
            continue
        print(f"\n### {target}")
        done = False
        for repo in repos:
            files, err = list_files(repo)
            if err:
                print(f"  ❌ {repo}: {err}")
                if "gated" in err.lower() or "401" in err or "authenticated" in err.lower():
                    print(f"     ↳ gated repo. Accept terms at https://huggingface.co/datasets/{repo}")
                    print(f"     ↳ or: huggingface-cli login  (then re-run)")
                continue
            cands = pick(files)
            print(f"  ✅ {repo}: {len(files)} files, {len(cands)} downloadable")
            for c in cands[:6]:
                print(f"       - {c}")
            if not cands:
                continue
            dest = os.path.join(RAW, f"{target}_files")
            os.makedirs(dest, exist_ok=True)
            if not args.apply:
                print(f"     (dry-run) would download into {dest}")
                done = True
                break
            try:
                for c in cands[:4]:
                    p = download(repo, c, dest)
                    sz = os.path.getsize(p) if os.path.exists(p) else 0
                    print(f"     ⬇ {c}  ({human(sz)})")
                done = True
                summary.append((target, repo, "OK"))
                break
            except Exception as e:
                print(f"     ❌ download failed: {type(e).__name__}: {str(e)[:160]}")
                summary.append((target, repo, f"FAIL {type(e).__name__}"))
        if not done:
            print(f"  ⚠️  no usable source for {target}")
            summary.append((target, "-", "NO SOURCE"))

    print("\n" + "=" * 76)
    print(" SUMMARY / 汇总")
    for t, r, s in summary:
        print(f"  {t:<12}{s:<24}{r}")
    print("\nNext / 下一步:")
    print("  python scripts/prep_raw.py     # convert raw files into unified jsonl")
    print("  (prep_raw.py will be generated once we know which files landed)")


if __name__ == "__main__":
    main()
