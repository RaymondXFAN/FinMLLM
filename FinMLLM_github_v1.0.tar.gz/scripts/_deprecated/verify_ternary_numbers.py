#!/usr/bin/env python3
# ============================================================
# FinMLLM / verify_ternary_numbers.py
# 目的：把 ternary 那套打架的数字定案（见 ERRATA E-24）。
# Purpose: settle the conflicting ternary deltas recorded as ERRATA E-24.
#
# 我为什么写这个：FRL 版里 ternary 的逐 seed 增量有四个版本
# （+3.72/+2.79/+6.30 vs +3.31/+2.79/+6.30 vs 表格里的 +0.41），
# 谁对谁错我不能拍脑袋，必须回到 raw json 上看 b/c 和 n。
# 这个脚本只读不写，扫一遍把每一对 (r16, r1) 的数原样打出来。
#
# 用法 / Usage:
#   ROOT=/root/autodl-tmp/FinMLLM python3 scripts/verify_ternary_numbers.py
# 作者 / Author: Raymond Xiaohu Fan
# ============================================================
import os, json, glob, re, sys

ROOT = os.environ.get("ROOT", "/root/autodl-tmp/FinMLLM")

def walk_json(root):
    for base in ("results", "outputs", "logs", "."):
        d = os.path.join(root, base)
        if not os.path.isdir(d):
            continue
        for p in glob.glob(os.path.join(d, "**", "*.json"), recursive=True):
            yield p

def pick(d, keys):
    """字段名在各版本脚本里不统一，按候选名往上找。"""
    if not isinstance(d, dict):
        return None
    for k in keys:
        if k in d and isinstance(d[k], (int, float)):
            return d[k]
        # 有的包了一层
        for kk, vv in d.items():
            if isinstance(vv, dict) and k in vv and isinstance(vv[k], (int, float)):
                return vv[k]
    return None

rows = []
seen = set()
for p in walk_json(ROOT):
    name = os.path.basename(p).lower()
    if "tri" not in name:
        continue
    if p in seen:
        continue
    seen.add(p)
    try:
        d = json.load(open(p, encoding="utf-8"))
    except Exception as e:
        continue
    acc = pick(d, ["accuracy", "acc", "test_acc"])
    n = pick(d, ["n", "n_test", "n_items", "total"])
    b = pick(d, ["b", "n_01", "only_r16_right"])
    c = pick(d, ["c", "n_10", "only_r1_right"])
    dl = pick(d, ["delta_pp", "delta", "diff_pp"])
    pv = pick(d, ["p", "p_value", "pval"])
    seed = pick(d, ["seed", "train_seed"])
    if acc is None:
        continue
    rows.append(dict(file=os.path.relpath(p, ROOT), seed=seed, n=n,
                     acc=acc, b=b, c=c, delta=dl, p=pv))

if not rows:
    print(f"❌ 在 {ROOT} 下没找到含 'tri' 的评测 json。")
    print("   检查一下路径：项目根是不是 /root/autodl-tmp/FinMLLM ？")
    print("   或者 results/ 是不是被挪走了。")
    sys.exit(1)

print(f"{'file':58s} {'seed':>5s} {'n':>5s} {'acc':>7s} {'b':>4s} {'c':>4s} {'Δpp':>7s} {'p':>8s}")
print("-" * 106)
for r in sorted(rows, key=lambda x: (str(x["seed"]), x["file"])):
    def f(v, w=0, d=4):
        if v is None:
            return " " * w + "-"
        return f"{v:>{w}.{d}f}" if isinstance(v, float) else f"{v:>{w}}"
    print(f"{r['file'][:58]:58s} {f(r['seed'],5,0)} {f(r['n'],5,0)} {f(r['acc'],7,4)} "
          f"{f(r['b'],4,0)} {f(r['c'],4,0)} {f(r['delta'],7,2)} {f(r['p'],8,4)}")

# 顺便把按 seed 配对的 r16 / r1 摆在一起，一眼看出差该是多少
print("\n" + "=" * 106)
print("配对视图（同一个 seed 的 r16 和 r1，差 = r1 - r16）")
print("=" * 106)
by_seed = {}
for r in rows:
    key = (r["seed"], "r1" if re.search(r"_r1(?![0-9])", r["file"]) else
           ("r16" if "_r16" in r["file"] else "other"))
    by_seed.setdefault(r["seed"], {})[key[1]] = r
for seed, d in sorted(by_seed.items(), key=lambda x: str(x[0])):
    if "r16" in d and "r1" in d:
        a16, a1 = d["r16"]["acc"], d["r1"]["acc"]
        n = d["r16"]["n"] or d["r1"]["n"]
        diff = (a1 - a16) * 100 if n is None or n > 1 else (a1 - a16) * 100
        print(f"seed={seed}  r16 {a16:.4f} ({d['r16']['file'].split('/')[-1][:34]})  "
              f"r1 {a1:.4f} ({d['r1']['file'].split('/')[-1][:34]})  → 差 {diff:+.2f} pp")
    else:
        print(f"seed={seed}  缺 r16 或 r1：{sorted(d.keys())}")

print("""
怎么读这张表：
  1. 如果 r1 - r16 算出来是 +3.31 一带，那 ERRATA 里的 +3.72 就是笔误，
     长文版 17_ 的 L135 和总表 L17 要改。
  2. 如果是 +3.72，那 b/c = 44/12 那组数出自另一对 adapter，要查是哪个。
  3. 顺带看 Table 1 的 ternary 列：如果 r16 和 r1 用的是不同 seed 或不同 ckpt 批次，
     那一列本来就不能横向比，必须统一口径。
""")
