#!/usr/bin/env python3
# ============================================================
# FinMLLM / train_sft.py
# Supervised fine-tuning on a classification task (instruction format).
# This produces the TASK adapter that Fork C compresses.
# 在分类任务上做指令式监督微调 —— 产出 Fork C 要压缩的"任务 adapter"。
#
# Author : Raymond Xiaohu Fan
# Note   : A CPT adapter has read a lot; it still needs to be taught the exam format.
#          CPT adapter 读过很多书，但你得先教它考试格式。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/train_sft.py --dataset fpb --binary --epochs 3 --out ckpts_sft/fpb_r16
# ============================================================
import os, sys, json, random, argparse, time
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from lib_probe import step, probe  # noqa: E402




def _norm_label(raw):
    """Map numeric or mixed labels onto negative/neutral/positive.
    把数字或混合形式的标签统一到 negative/neutral/positive。
    FiQA-SA 用 -1/0/1，FPB 用单词 —— 不归一化就会全部过滤掉。"""
    s = str(raw).strip().lower()
    table = {
        "-1": "negative", "-1.0": "negative", "0": "neutral", "0.0": "neutral",
        "1": "positive", "1.0": "positive",
        "neg": "negative", "neu": "neutral", "pos": "positive",
        "negative": "negative", "neutral": "neutral", "positive": "positive",
    }
    return table.get(s, s)

def _holdout_split(items, holdout=0.2, seed=42):
    """Deterministic 80/20 split shared by training and evaluation.
    训练与评测共用的确定性 80/20 划分 —— FPB 的 AllAgree 是 50Agree 的子集，
    只按原始 split 分仍会泄漏，必须统一重划。
    """
    import random as _r
    idx = list(range(len(items)))
    _r.Random(seed).shuffle(idx)
    cut = int(len(items) * (1 - holdout))
    tr = [items[i] for i in idx[:cut]]
    te = [items[i] for i in idx[cut:]]
    return tr, te

def load_pairs(dataset, binary, limit=None, seed=42, split="train", holdout=0.2):
    path = os.path.join(ROOT, "data", "unified", f"{dataset}.jsonl")
    keep = {"negative", "positive"} if binary else {"negative", "neutral", "positive"}
    pairs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            t = str(r.get("text", "")).strip()
            y = _norm_label(r.get("label", ""))
            if t and y in keep:
                pairs.append((t, y))
    tr, te = _holdout_split(pairs, holdout, seed)
    pairs = tr if split == "train" else te
    if limit and len(pairs) > limit:
        random.Random(seed).shuffle(pairs)
        pairs = pairs[:limit]
    return pairs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="fpb")
    ap.add_argument("--binary", action="store_true", default=True,
                    help="keep for backward compat / 兼容旧参数")
    ap.add_argument("--classes", type=int, default=2, choices=[2, 3],
                    help="2=pos/neg (easy), 3=include neutral (hard) / 2 简单，3 困难")
    ap.add_argument("--base", default=os.environ.get("BASE_MODEL", "/root/autodl-tmp/models/Qwen2.5-3B"))
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--seed", type=int, default=42, help="training seed / 训练随机种子")
    ap.add_argument("--split-seed", type=int, default=42,
                    help="data-split seed, MUST match eval_cloze / 数据划分种子，必须与评测一致")
    ap.add_argument("--split", default="train", help="train|test / 训练用哪一份")
    ap.add_argument("--holdout", type=float, default=0.2, help="test ratio / 留出比例")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

    use_binary = (args.classes == 2)
    # Seed everything so multi-seed runs are genuinely independent.
    # 固定所有随机源，保证多种子之间是真正独立的实验。
    random.seed(args.seed)
    np.random.seed(args.seed)
    import torch as _torch
    _torch.manual_seed(args.seed)
    if _torch.cuda.is_available():
        _torch.cuda.manual_seed_all(args.seed)

    # Split with a FIXED seed so every training seed sees the same 80/20 split.
    # If this followed --seed, each seed would get a different split and the
    # evaluation set would overlap training data — that is how we got a fake 1.0000.
    # 数据划分固定用 split_seed，保证多组实验共享同一份 80/20 划分；
    # 若跟着 --seed 变，每个种子的测试集都会和训练集重叠，就会出现虚假的 1.0000。
    pairs = load_pairs(args.dataset, use_binary, args.limit,
                       split=args.split, holdout=args.holdout, seed=args.split_seed)
    print(f"dataset={args.dataset} classes={args.classes} split={args.split} pairs={len(pairs)}")
    assert pairs, "no data"

    with step("load-model", base=args.base):
        tok = AutoTokenizer.from_pretrained(args.base, trust_remote_code=True)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                 bnb_4bit_use_double_quant=True,
                                 bnb_4bit_compute_dtype=torch.bfloat16)
        model = AutoModelForCausalLM.from_pretrained(
            args.base, quantization_config=bnb, device_map={"": 0}, trust_remote_code=True)
        model = prepare_model_for_kbit_training(model)
        model = get_peft_model(model, LoraConfig(
            r=args.rank, lora_alpha=args.rank * 2, lora_dropout=0.05, bias="none",
            task_type="CAUSAL_LM",
            target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]))
        model.print_trainable_parameters()

    # Build examples: loss only on the answer tokens / 只在答案部分计算损失
    def encode(text, label):
        prompt = f"Sentence: {text[:600]}\nSentiment:"
        full = prompt + " " + label
        enc = tok(full, truncation=True, max_length=512, return_tensors="pt")
        p_len = len(tok(prompt, truncation=True, max_length=512)["input_ids"])
        labels = enc["input_ids"].clone()
        labels[:, :p_len] = -100
        enc["labels"] = labels
        return enc

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr)
    steps_per_epoch = max(1, len(pairs) // args.bs)
    total = steps_per_epoch * args.epochs
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(total, 1))

    losses = []
    t0 = time.time()
    model.train()
    with step("train", steps=total):
        for ep in range(args.epochs):
            random.shuffle(pairs)
            for i in range(steps_per_epoch):
                batch = pairs[i * args.bs:(i + 1) * args.bs]
                loss_sum = 0.0
                opt.zero_grad()
                for text, lab in batch:
                    enc = encode(text, lab)
                    enc = {k: v.to("cuda") for k, v in enc.items()}
                    out = model(**enc)
                    (out.loss / len(batch)).backward()
                    loss_sum += float(out.loss)
                torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
                opt.step(); sched.step()
                losses.append(loss_sum / len(batch))
                if (i + 1) % 20 == 0:
                    probe(f"ep{ep} step{i+1}/{steps_per_epoch} loss={np.mean(losses[-20:]):.4f} "
                          f"vram={torch.cuda.max_memory_allocated()/1024**3:.2f}GB")

    os.makedirs(args.out, exist_ok=True)
    model.save_pretrained(args.out)
    tok.save_pretrained(args.out)
    meta = {"dataset": args.dataset, "classes": args.classes, "seed": args.seed,
            "split_seed": args.split_seed, "pairs": len(pairs),
            "epochs": args.epochs, "rank": args.rank,
            "loss_first": losses[0] if losses else None,
            "loss_last": float(np.mean(losses[-50:])) if losses else None,
            "dur_sec": round(time.time() - t0, 1),
            "peak_vram_gb": round(torch.cuda.max_memory_allocated()/1024**3, 2)}
    json.dump(meta, open(os.path.join(args.out, "train_meta.json"), "w"), indent=2, ensure_ascii=False)
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print(f"\n✅ SFT adapter -> {args.out}")
    print("Next / 下一步:")
    print(f"  python scripts/eval_cloze.py --dataset {args.dataset} --binary --limit 300 --adapter {args.out}")


if __name__ == "__main__":
    main()
