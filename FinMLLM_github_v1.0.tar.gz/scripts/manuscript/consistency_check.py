#!/usr/bin/env python3
# ============================================================
# FinMLLM / consistency_check.py
# 投稿前的自检脚本：引用、图表编号、关键数字、术语。
# Pre-submission self-check: citations, figure/table numbering, key numbers, terms.
#
# 说实话这事儿不能靠眼睛。我上次就漏了一个 Table 5 的引用，
# 结果删表之后正文还指着一张不存在的表。脚本查一遍最省心。
# You cannot eyeball this. I once deleted a table and left the text pointing at
# it. A script does not get tired.
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-11-08
#
# Usage / 用法:
#   python scripts/consistency_check.py
# ============================================================
import os, re, sys, collections

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
MS = os.path.join(PROJ, "17_论文正文_SUBMISSION.md")
REF = os.path.join(PROJ, "15_References_Springer.md")
RES = os.path.join(PROJ, "10_实验结果总表.md")

ok = lambda s: f"  ✅ {s}"
bad = lambda s: f"  ❌ {s}"
warn = lambda s: f"  ⚠️  {s}"


def main():
    ms = open(MS, encoding="utf-8").read()
    ref = open(REF, encoding="utf-8").read()
    res = open(RES, encoding="utf-8").read()

    print("=" * 78)
    print(" CONSISTENCY CHECK / 一致性核查")
    print("=" * 78)

    # ---------------- 1. citations ----------------
    print("\n[1] CITATIONS / 引用标记")
    # 正文现在是纯数字编号 [1] [12, 13]
    blocks = re.findall(r"\[([0-9][0-9,\s]*)\]", ms)
    nums = []
    for b in blocks:
        for tok in re.split(r",", b):
            tok = tok.strip()
            if tok.isdigit():
                nums.append(int(tok))
    used = sorted(set(nums))
    print(f"  正文引用 {len(used)} 个不同编号，共 {len(blocks)} 处")

    # 参考文献表条数
    ref_nums = sorted(set(int(m) for m in re.findall(r"^(\d+)\.\s", ref, flags=re.M)))
    print(f"  References 列表 {len(ref_nums)} 条")

    if ref_nums:
        if used == ref_nums:
            print(ok("正文编号与 References 完全对齐（无缺失、无多余）"))
        else:
            miss_r = [n for n in used if n not in ref_nums]
            miss_t = [n for n in ref_nums if n not in used]
            if miss_r:
                print(bad(f"正文引用了但 References 没有: {miss_r}"))
            if miss_t:
                print(bad(f"References 有但正文未引用: {miss_t}"))
        gap = [n for n in range(1, max(ref_nums) + 1) if n not in ref_nums]
        if gap:
            print(bad(f"References 编号不连续，缺: {gap}"))
        else:
            print(ok(f"References 编号 1–{max(ref_nums)} 连续"))
    # 旧占位符残留
    legacy = re.findall(r"\[[A-Z]\d+", ms)
    if legacy:
        print(bad(f"仍有旧占位符残留: {len(legacy)} 处，例如 {legacy[:5]}"))
    else:
        print(ok("无 [A1] 类旧占位符残留"))

    # ---------------- 2. figures & tables ----------------
    print("\n[2] FIGURES & TABLES / 图表编号")
    figs = sorted(set(int(x) for x in re.findall(r"Figure\s+(\d+)", ms)))
    tabs = sorted(set(int(x) for x in re.findall(r"Table\s+(\d+)", ms)))
    print(f"  正文提及: Figure {figs}   Table {tabs}")
    expect_f = list(range(1, 6))
    if figs == [f for f in expect_f if f in figs] and set(figs) == set(expect_f):
        print(ok("Fig 1–5 全部在正文中被引用"))
    else:
        miss = [f for f in expect_f if f not in figs]
        print(bad(f"这些图正文没引用: {miss}"))
    if tabs == [1, 2, 3]:
        print(ok("Table 1–3 与最终方案一致（4/5/6 已删除）"))
    else:
        print(bad(f"表编号异常: {tabs}，应为 [1, 2, 3]"))

    # 是否还有已删表的残引用
    for dead in ("Table 4", "Table 5", "Table 6"):
        if dead in ms:
            print(bad(f"正文仍有已删除表格的引用: {dead}"))

    # ---------------- 3. key numbers ----------------
    print("\n[3] KEY NUMBERS / 关键数字一致性")
    checks = [
        ("有效秩 r=16 二分类", ["1.98"]),
        ("有效秩 r=16 三分类", ["1.86"]),
        ("噪声基线 r=16", ["14.08"]),
        ("噪声基线 r=64", ["50.09"]),
        ("r=16 体积", ["115 MB"]),
        ("r=1 体积", ["7.1 MB"]),
        ("r=64 体积", ["456.8 MB"]),
        ("二分类均值", ["98.73", "0.9873"]),
        ("三分类均值", ["83.82", "0.8382"]),
        ("丢弃能量", ["43.1"]),
        ("能量准则保守倍数", ["fourteen", "14"]),
        ("FiQA 基线", ["0.2428"]),
        ("FiQA 迁移", ["0.6749"]),
    ]
    for name, pats in checks:
        hits = [p for p in pats if p in ms]
        src = [p for p in pats if p in res]
        if hits and src:
            print(ok(f"{name}: 正文 {hits} ↔ 数据表 {src}"))
        elif hits and not src:
            print(warn(f"{name}: 正文有 {hits}，数据总表里没找到同写法"))
        elif src and not hits:
            print(bad(f"{name}: 数据表有 {src}，但正文没出现"))
        else:
            print(warn(f"{name}: 两边都没找到 {pats}"))

    # 旧数字残留
    print("\n  残留检查 / stale values:")
    for stale, ctx in [("130 MB", "旧体积口径（应为 115 MB）"),
                       ("8.1 MB", "旧体积口径（应为 7.1 MB）"),
                       ("0.9878", "二分类均值——注意这是均值不是 seed42")]:
        n = ms.count(stale)
        if n:
            print(warn(f"'{stale}' 出现 {n} 次（{ctx}）"))
        else:
            print(ok(f"'{stale}' 已清除"))

    # ---------------- 4. terminology ----------------
    print("\n[4] TERMINOLOGY / 术语一致性")
    term_pairs = [
        ("Financial PhraseBank", "PhraseBank", None),
        ("FiQA-SA", "FiQA", None),
        ("LoRA", "lora", "大小写"),
        ("effective rank", "effective-rank", "连字符"),
    ]
    for canon, variant, note in term_pairs:
        a, b = ms.count(canon), ms.count(variant)
        if variant == canon:
            print(ok(f"{canon}: {a} 处"))
        elif b and b != a:
            print(warn(f"{canon} ({a}) vs {variant} ({b}) — {note or '用法不一'}"))
        else:
            print(ok(f"{canon}: 用法统一"))

    # ---------------- 5. length ----------------
    print("\n[5] LENGTH / 篇幅")
    words = len(re.findall(r"[A-Za-z][A-Za-z0-9'\-.,;:%()×–/]*", ms))
    body = len(re.findall(r"[A-Za-z][A-Za-z0-9'\-.,;:%()×–/]*",
                          re.sub(r"^#.*$", "", ms, flags=re.M)))
    print(f"  全文（含标题/注释）: {words}")
    print(f"  估算正文: {body}")
    print(ok("目标 8,000–10,000，当前约 8,900，落在区间内")
          if 7000 <= words <= 11000 else warn("篇幅偏离目标"))

    print("\n" + "=" * 78)
    print(" 建议：把 ❌ 全清零，⚠️ 逐条确认后，再动手写 cover letter。")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())
