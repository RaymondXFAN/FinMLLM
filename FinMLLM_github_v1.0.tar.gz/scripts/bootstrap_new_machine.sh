#!/usr/bin/env bash
# ============================================================
# FinMLLM / bootstrap_new_machine.sh
# One-stop bootstrap for a FRESH AutoDL machine, encoding every lesson we
# learned the hard way (script-type datasets, gated repos, Xet 401, SEC API).
# 新机器一键部署，把踩过的坑全部固化成默认行为。
#
# Author : Raymond Xiaohu Fan
# Note   : Every failure below cost us a round-trip. Never again. / 下面每条失败都让我们多跑了一趟，不想再来一次。
# Updated: 2026-10-22
#
# Usage / 用法:
#   bash scripts/bootstrap_new_machine.sh all
#   bash scripts/bootstrap_new_machine.sh env|deps|data|prep|gates
#
# Optional env vars / 可选环境变量:
#   PROJ=/root/autodl-tmp/FinMLLM
#   SEC_EMAIL=you@example.com        # enables SEC EDGAR 10-K download
#   BASE_MODEL=/path/to/model        # skip model download if provided
#   WITH_FINEVAL=1                   # also fetch FinEval insurance subjects
# ============================================================
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
STAGE="${1:-all}"
FAILED=()

say () { echo -e "\n===== [$(date '+%F %T')] $* ====="; }
ok  () { echo "  ✅ $*"; }
bad () { echo "  ❌ $*"; FAILED+=("$*"); }

# ---------- P0: layout ----------
stage_env () {
  say "0. Layout / 目录"
  df -h /root/autodl-tmp 2>/dev/null | tail -1
  mkdir -p "$PROJ"/{code,ckpts,data/{raw,unified,domains},outputs/{logs,reports,tables,figs},shared,forks,scripts/gates,configs,runs}
  for f in A_flagship B_method C_economics D_framework; do
    mkdir -p "$PROJ/forks/$f"/{configs,ckpts,drafts,outputs/{tables,figs,logs}}
  done
  # shared cache lives on the data disk, never the system disk
  # 共享缓存放数据盘，绝不放系统盘
  [ -d "$PROJ/shared/hf_home" ] || mkdir -p "$PROJ/shared/hf_home"

  cat > "$PROJ/setup_env.sh" <<EOF
export PROJ=$PROJ
export HF_HOME=$PROJ/shared/hf_home
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
EOF
  ok "layout ready -> $PROJ"
  echo "  ⚠️  now run: source $PROJ/setup_env.sh"
}

# ---------- P1: deps ----------
stage_deps () {
  say "1. Dependencies / 依赖"
  python -V
  python -m pip install -q -U pip 2>/dev/null || true
  # transformers 5.x exists, but 4.46.x is the battle-tested fallback if G3 explodes.
  # transformers 5.x 能装，但 G3 报错时退回 4.46.x（已验证可用）。
  python -m pip install -q -U \
    "datasets>=2.20" "huggingface_hub>=0.24" accelerate peft bitsandbytes scipy \
    scikit-learn pandas pyyaml safetensors 2>/dev/null || bad "pip install core deps"
  python -m pip show transformers >/dev/null 2>&1 || python -m pip install -q "transformers==4.46.3"
  python - <<'PY'
import importlib
for m in ["torch","transformers","peft","datasets","accelerate","bitsandbytes","scipy","numpy","pandas","sklearn","yaml"]:
    try:
        mod = importlib.import_module(m)
        print(f"  ✅ {m:<14}{getattr(mod,'__version__','?')}")
    except Exception as e:
        print(f"  ❌ {m:<14}{type(e).__name__}")
PY
  ok "deps checked (bitsandbytes may warn without GPU — that is fine)"
}

# ---------- P2: data ----------
stage_data () {
  say "2. Data / 数据（四条已验证路径）"
  export HF_HUB_DISABLE_XET=1
  export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"

  # 2.1 FPB — script-type dataset: pull the zip, never load_dataset()
  # FPB 是 script 型：直接拉 zip，别用 load_dataset()
  if [ ! -d "$PROJ/data/raw/fpb_files" ] || [ -z "$(ls -A "$PROJ/data/raw/fpb_files" 2>/dev/null)" ]; then
    python "$PROJ/scripts/fetch_raw.py" --only fpb --apply || bad "fpb download"
  else ok "fpb already present"; fi

  # 2.2 FiQA-SA
  if [ ! -d "$PROJ/data/raw/fiqa_sa_files" ] || [ -z "$(ls -A "$PROJ/data/raw/fiqa_sa_files" 2>/dev/null)" ]; then
    python "$PROJ/scripts/fetch_raw.py" --only fiqa_sa --apply || bad "fiqa download"
  else ok "fiqa already present"; fi

  # 2.3 TFNS — this one IS a normal dataset, load_dataset works
  if [ ! -d "$PROJ/data/raw/tfns" ]; then
    python - <<'PY' || bad "tfns download"
import os
from datasets import load_dataset
root = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
load_dataset("zeroshot/twitter-financial-news-sentiment").save_to_disk(
    os.path.join(root, "data", "raw", "tfns"))
print("ok tfns")
PY
  else ok "tfns already present"; fi

  # 2.4 FinQA — official GitHub JSON (HF repo is script-only)
  # FinQA：HF 仓库只有脚本，改从官方 GitHub 拿 JSON
  mkdir -p "$PROJ/data/raw/finqa_files"
  for s in train dev test; do
    f="$PROJ/data/raw/finqa_files/$s.json"
    if [ -s "$f" ]; then ok "finqa $s exists"; continue; fi
    curl -fL --retry 3 -o "$f" \
      "https://raw.githubusercontent.com/czyssrs/FinQA/main/dataset/$s.json" \
      || bad "finqa $s"
  done

  # 2.5 Business lines — SEC EDGAR official API
  # 业务线：SEC 官方 API（那个 HF 数据集只覆盖小盘股，靠不住）
  if [ -n "${SEC_EMAIL:-}" ]; then
    python "$PROJ/scripts/fetch_edgar_sec.py" --email "$SEC_EMAIL" --years 3 \
      || bad "edgar_sec"
  else
    echo "  ⚠️  SEC_EMAIL not set, skipping EDGAR. Set it and re-run:"
    echo "      SEC_EMAIL=you@example.com bash scripts/bootstrap_new_machine.sh data"
  fi

  # 2.6 Optional: FinEval insurance backup
  if [ "${WITH_FINEVAL:-0}" = "1" ]; then
    python "$PROJ/scripts/fetch_fineval.py" || bad "fineval"
  fi

  du -sh "$PROJ"/data/raw/* 2>/dev/null | sort -h
}

# ---------- P3: prep ----------
stage_prep () {
  say "3. Convert / 数据转换"
  python "$PROJ/scripts/prep_raw.py"          || bad "prep_raw"
  python "$PROJ/scripts/check_data.py"        || bad "data audit"
}

# ---------- P4: gates ----------
stage_gates () {
  say "4. Gates G0-G2 / 无卡 gate"
  bash "$PROJ/scripts/run_gates.sh" nogpu || bad "gates nogpu"
}

case "$STAGE" in
  env)   stage_env ;;
  deps)  stage_deps ;;
  data)  stage_data ;;
  prep)  stage_prep ;;
  gates) stage_gates ;;
  all)   stage_env; stage_deps; stage_data; stage_prep; stage_gates ;;
  *) echo "usage: bash scripts/bootstrap_new_machine.sh env|deps|data|prep|gates|all"; exit 1 ;;
esac

echo ""
echo "============================================================"
if [ ${#FAILED[@]} -eq 0 ]; then
  echo " 🎉 stage '$STAGE' finished cleanly"
else
  echo " ⚠️  failures in stage '$STAGE':"
  printf '    - %s\n' "${FAILED[@]}"
  echo "    Re-run that stage after fixing; every step is idempotent."
fi
echo "============================================================"
