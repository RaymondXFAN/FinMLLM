#!/usr/bin/env python3
# FinMLLM / supp / fix_fiqa.py
# 从 data/raw/fiqa_sa_files/{train,test,validation}.csv 重建 fiqa_sa.jsonl。
# 按「取值」判定情感列，不按列名 —— 原名 label 的列装的是股票代码。
# Pick the sentiment column by VALUE; the column literally named "label" holds tickers.
# Author: Raymond Xiaohu Fan
import os, sys, json, csv, argparse, collections

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
SRC = os.path.join(ROOT, "data", "raw", "fiqa_sa_files")
UNI = os.path.join(ROOT, "data", "unified")


def norm(v):
    s = str(v).strip().lower()
    m = {"-1": "negative", "-1.0": "negative", "-1.00": "negative",
         "0": "neutral", "0.0": "neutral", "0.00": "neutral",
         "1": "positive", "1.0": "positive", "1.00": "positive",
         "neg": "negative", "neu": "neutral", "pos": "positive",
         "negative": "negative", "neutral": "neutral", "positive": "positive"}
    if s in m:
        return m[s]
    try:
        f = float(s)
        if -1.0 <= f <= 1.0:
            return "negative" if f <= -0.2 else ("positive" if f >= 0.2 else "neutral")
    except Exception:
        pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    rows, chosen = [], None
    for split in ("train", "validation", "test"):
        p = os.path.join(SRC, f"{split}.csv")
        if not os.path.exists(p):
            print(f"  缺 {p}"); continue
        with open(p, encoding="utf-8") as fh:
            recs = list(csv.DictReader(fh))
        if not recs:
            continue
        cols = list(recs[0].keys())

        if chosen is None:                       # 用 train 定列，三个 split 共用
            best, score = None, 0.0
            for c in cols:
                s_ = sum(norm(r.get(c)) is not None for r in recs[:800]) / min(len(recs), 800)
                if s_ > score:
                    best, score = c, s_
            print(f"  选定情感列: '{best}'  命中率 {score:.2%}")
            print(f"  全部列: {cols}")
            if score < 0.8:
                print("❌ 没有哪一列像情感分数，需要人工看 csv")
                return 2
            chosen = best
            tcol = next((c for c in cols if c.lower() in
                         ("sentence", "text", "headline", "content", "post")), None)
            if tcol is None:
                tcol = max(cols, key=lambda c: sum(len(str(r.get(c, ""))) for r in recs[:200]))
            print(f"  文本列: '{tcol}'")

        for i, r in enumerate(recs):
            lab = norm(r.get(chosen))
            txt = str(r.get(tcol, "")).strip()
            if not lab or not txt:
                continue
            rows.append({"id": f"fiqa-{split}-{i}", "text": txt, "label": lab,
                         "source": "fiqa_sa", "split": split})

    print(f"\n可用样本 {len(rows)} 条")
    print("标签分布:", dict(collections.Counter(r["label"] for r in rows)))
    if not rows:
        return 2
    out = os.path.join(UNI, "fiqa_sa.jsonl")
    if a.dry_run:
        print(f"（dry-run，未写 {out}）"); return 0
    with open(out, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"✅ 写入 {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
