#!/usr/bin/env python3
# FinMLLM / spectral_table3.py -- Table 3 的唯一权威实现
# Authoritative implementation behind Table 3.
#
# 指标定义 / definitions:
#   对象 = ΔW = B @ A（重建出来算，不算 lora_A）
#   stable rank = Σσ²/σ₁²      PR = (Σσ)²/Σσ²
#   eRank = exp(-Σp·log p)     n90 = 累计 90% 能量方向数
#   noise = 同形状 [k,d] 高斯矩阵的 stable rank，k=ΔW 数值秩，d=较大边
#   ratio = stable / noise
#
# 已验证锚点: 3B bin r16 -> stable 1.983, n90 6.46, noise 13.55, ratio 0.146
# 已知修正: 早期 PR=3.27 / eRank=5.29 是错的，实测 8.50 / 11.40（见 ERRATA E-15）
import os, sys, json, argparse
import numpy as np
from safetensors.torch import load_file

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
OUTDIR = os.path.join(PROJ, "outputs", "reports", "table3")


def sv_metrics(sv):
    e = sv ** 2
    tot = e.sum()
    if tot <= 0 or sv[0] <= 0:
        return None
    p = sv / sv.sum(); p = p[p > 0]
    return dict(stable=float(tot / sv[0] ** 2),
                pr=float(sv.sum() ** 2 / tot),
                erank=float(np.exp(-(p * np.log(p)).sum())),
                n90=int(np.searchsorted(np.cumsum(e) / tot, 0.90) + 1),
                rank_int=int((sv > sv[0] * 1e-6).sum()))


def noise_stable(k, d, trials=200, seed=0):
    rng = np.random.default_rng(seed)
    k, d = min(k, d), max(k, d)
    vals = []
    for _ in range(trials):
        G = rng.standard_normal((k, d))
        sv = np.linalg.svd(G, compute_uv=False)
        vals.append((sv ** 2).sum() / sv[0] ** 2)
    return float(np.mean(vals))


def noise_analytic(k, d):
    """解析基线：k×d 高斯矩阵 stable rank 的渐近值。
    Analytic baseline: asymptotic stable rank of a k×d Gaussian matrix.
    比 MC 更可复现，论文里报这个。"""
    k, d = min(k, d), max(k, d)
    return float((k * d) / (np.sqrt(k) + np.sqrt(d)) ** 2)


def analyse(adapter, max_layers=0):
    sd = load_file(os.path.join(adapter, "adapter_model.safetensors"))
    pairs = [(k, k.replace("lora_A", "lora_B")) for k in sd
             if "lora_A" in k and k.replace("lora_A", "lora_B") in sd]
    if max_layers:
        pairs = pairs[:max_layers]
    rows = []
    for ka, kb in pairs:
        A = sd[ka].float().numpy(); B = sd[kb].float().numpy()
        dW = B @ A
        sv = np.linalg.svd(dW, compute_uv=False)
        m = sv_metrics(sv)
        if m is None:
            continue
        # 数值秩必须按配置秩封顶：ΔW 的秩不可能超过 r，
        # 但 SVD 的数值噪声会让十几个"零"奇异值越过 1e-6 阈值。
        # Numerical rank must be capped at the configured r; otherwise SVD
        # noise inflates it and the baseline comes out too large.
        k_eff = min(m["rank_int"], A.shape[0])
        d_side = max(dW.shape)
        # 只用解析基线：无随机性，可复现，比 MC 更稳。
        # Analytic baseline only — deterministic and reproducible, no MC noise.
        m["noise"] = noise_analytic(k_eff, d_side)
        m["noise_mc"] = m["noise"]
        m["ratio"] = m["stable"] / m["noise"]
        m["r_cfg"] = A.shape[0]
        rows.append(m)
    return rows


def report(tag, rows):
    agg = {k: float(np.mean([r[k] for r in rows]))
           for k in ("stable", "pr", "erank", "n90", "noise", "ratio")}
    print("=" * 76)
    print(f" {tag}   matrices={len(rows)}   configured r={rows[0]['r_cfg']}")
    print("=" * 76)
    print(f"{'metric':<12} {'mean':>9} {'median':>9} {'p05':>9} {'p95':>9}")
    for k in ("stable", "pr", "erank", "n90", "noise", "noise_mc", "ratio"):
        v = np.array([r[k] for r in rows])
        print(f"{k:<12} {v.mean():>9.3f} {np.median(v):>9.3f} "
              f"{np.percentile(v,5):>9.3f} {np.percentile(v,95):>9.3f}")
    print("-" * 76)
    print(f" stable rank 是同形状高斯基线的 {agg['ratio']:.3f} 倍")
    return agg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter")
    ap.add_argument("--tag")
    ap.add_argument("--batch", nargs="*", default=None)
    ap.add_argument("--max-layers", type=int, default=0)
    a = ap.parse_args()

    jobs = []
    if a.batch:
        for item in a.batch:
            t, p = item.split(":", 1)
            jobs.append((t, p))
    elif a.adapter:
        jobs.append((a.tag or os.path.basename(a.adapter.rstrip("/")), a.adapter))
    else:
        print("need --adapter or --batch"); return 2

    os.makedirs(OUTDIR, exist_ok=True)
    summary = {}
    for tag, path in jobs:
        if not os.path.exists(os.path.join(path, "adapter_model.safetensors")):
            print(f"skip {tag}: {path} 不存在"); continue
        rows = analyse(path, a.max_layers)
        if not rows:
            print(f"skip {tag}: 无矩阵"); continue
        summary[tag] = dict(adapter=path, n_matrices=len(rows),
                            configured_rank=rows[0]["r_cfg"],
                            aggregate=report(tag, rows), per_layer=rows)
        json.dump(summary[tag], open(os.path.join(OUTDIR, f"{tag}.json"), "w"),
                  indent=2, ensure_ascii=False)
        print()

    if summary:
        print("=" * 80)
        print(f"{'tag':<20} {'stable':>8} {'PR':>8} {'eRank':>8} {'n90':>6} {'noise':>8} {'ratio':>7}")
        print("-" * 80)
        for tag, d in summary.items():
            g = d["aggregate"]
            print(f"{tag:<20} {g['stable']:>8.2f} {g['pr']:>8.2f} {g['erank']:>8.2f} "
                  f"{g['n90']:>6.2f} {g['noise']:>8.2f} {g['ratio']:>7.3f}")
        json.dump({k: v["aggregate"] for k, v in summary.items()},
                  open(os.path.join(OUTDIR, "_summary.json"), "w"),
                  indent=2, ensure_ascii=False)
        print(f"\n saved -> {OUTDIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
