# 参考文献真实性核验报告

> 核验日期：2026-11-08
> 核验方式：联网检索 dblp / ACL Anthology / arXiv 官方页 / PMLR / IOS Press / ScienceDirect / Google Scholar
> 范围：正文实际引用的 **40 条**（文献池 72 条中未引用的 32 条不计入）

---

## 一、总结论

**40 条全部真实存在，无一条编造。** 但发现 **7 处必须修正的元数据硬错误**，其中 1 处错在正文的指标名上。全部已修正。

| 类别 | 条数 |
|---|---|
| 真实存在、元数据正确 | 19 |
| 真实存在、元数据有误（已修） | 21 |
| 不存在 / 编造 | **0** |

---

## 二、必须修正的硬错误（7 处，已全部修正）

| # | 原编号 | 错误内容 | 修正为 | 严重度 |
|---|---|---|---|---|
| 1 | **A5 PIXIU** | 正文两处写 GPT-4 的 **macro-F1 0.78** | PIXIU 对 FPB 报的是 **weighted F1**；GPT-4 的 accuracy 实为 0.76 | 🔴 正文错误，审稿人会核 |
| 2 | **E4 Shuttleworth** | NeurIPS **2024 spotlight** | **NeurIPS 2025 Poster**（官方虚拟会场页标注） | 🔴 年份+类型双错 |
| 3 | **C6 LoRA-XS** | ICLR 2025 | **ECAI 2025**, FAIA 413:3194–3201, DOI 10.3233/FAIA251185 | 🔴 会议完全错 |
| 4 | **F5 BeamLoRA** | arXiv (**2024**) | **ACL 2025 Long** (2025.acl-long.582), arXiv:2502.13604（2025-02） | 🔴 年份+出处 |
| 5 | **F6 TASO** | 标题 "…for **LoRA**" | "…for **Parameter-Efficient Model Adaptation**"；EMNLP 2025 Main | 🔴 标题实质性错误 |
| 6 | **B8 Pasch** | 单作者 Pasch；JFDS **2025** | **Pasch & Ehnes**；JFDS **Winter 2026**, 8(1):48–60 | 🟠 漏作者+年份 |
| 7 | **I4 FinSA-MoE** | ESWA **2026**, 334(**D**) | ESWA **2027**, 334:134711（"(D)" 分册无从证实，已删） | 🟠 年份+期号 |

### 标题类修正（4 处）

| 原编号 | 原写法 | 正式标题 |
|---|---|---|
| A5 | PIXIU: A LLM… (FinMA) | PIXIU: A **Large** Language Model…（"(FinMA)" 不是标题成分） |
| A6 | Evaluating **LLMs** on… | Evaluating **Large Language Models** on… |
| F3 | **PARA:** Post-Optimization… | Post-Optimization…（PARA 是方法名，非标题前缀） |
| F4 | LoRA-Squeeze: Post-Tuning… | LoRA-Squeeze: **Simple and Effective** Post-Tuning… |
| F8 | SeLoRA: Spectral Reparameterisation… | **Revisiting LoRA through the Lens of Parameter Redundancy: Spectral Encoding Helps**（Findings ACL 2025, pp.2701–2718） |
| I1 | Designing green AI models for finance | 补副标题 **: a novel approach for sustainable and responsible adoption** |

### 补全类（6 处）

| 原编号 | 补全内容 |
|---|---|
| A3 FLANG | pp.2322–2335, DOI 10.18653/v1/2022.emnlp-main.148 |
| C3 DoRA | PMLR 235:32100–32121（录用类型 Oral，非 spotlight） |
| F2 SVD-LLM V2 | DOI 10.18653/v1/2025.naacl-long.217 |
| H2 Fei | pp.14014–14031, DOI 10.18653/v1/2023.acl-long.783 |
| B3 Kirtac | 62(**Part B**):105227 |
| B5 FinGPT | arXiv:2306.06031（原只写 "arXiv (2023)"） |

---

## 三、存疑但已按保守方式处理

| 原编号 | 问题 | 处理 |
|---|---|---|
| **E5 MoRA** | AMiner 标 ICLR 2025，OpenReview 有投稿记录，但 dblp 仅收录 CoRR、arXiv comments 仍为 "Work in Progress" | **按 arXiv 引**（最稳） |
| **B6 FinLoRA** | PDF 有 AAAI-2025 版权页，但 workshop 名称/页码查不到 | **只引 arXiv:2412.11378**，不写 AAAI-25 Workshop |
| **E7 noise baseline** | 作者信息待核 | 未进正文（备用） |
| **K1 Diffract** | 作者未核实 | 未进正文（备用） |

---

## 四、四篇 2026 年 arXiv 论文——全部为真

这类"未来文献"最容易是编造的，逐一在 arxiv.org 官方 abs 页确认：

| 编号 | arXiv | 标题 | 状态 |
|---|---|---|---|
| **F4** | 2602.10993 | LoRA-Squeeze: Simple and Effective… | ✅ 存在，2026-02-11，Comments: Preprint |
| **E2** | 2603.03995 | Spectral Surgery… | ✅ 存在，2026-03-04，Tian, Chen, Han, Liao |
| **F3** | 2604.27796 | Post-Optimization Adaptive Rank Allocation for LoRA | ✅ 存在，2026-04-30，Kumaravelu et al. |
| **E1** | 2608.15351 | Spectral Rank Certification… | ✅ 存在，2026-08-15，Comments 明确 "KDD 2026 Workshop TensorKDD" |

---

## 五、关键论断的原文核对（防"引错内容"）

| 论断 | 核对结果 |
|---|---|
| FinBERT FPB 全集 Acc 0.86 / F1 0.84；100% 子集 0.97 / 0.95 | ✅ Araci 原文 Table 2 完全吻合（macro F1） |
| PIXIU: FinMA-7B 0.86 / 30B 0.88 / GPT-4 0.78 | ✅ 数值对，但**是 weighted F1 不是 macro-F1**；GPT-4 Acc 实为 0.76 |
| FPB 分布 neutral 59.4% / positive 28.1% / negative 12.4% | ✅ Vamvourellis & Mehta Table 1（N=4,845）确认 |
| Biderman: 全量微调扰动秩比 LoRA 高 10–100× | ✅ 原文三处均有，**但仅 continued pretraining 设定**，已在正文加限定 |
| Biderman 提出 energy-rank k₀.₉ | ⚠️ 原文用"解释 90% 方差所需秩"，未用该术语；学界通行归因，可保留 |
| Shuttleworth 提出 "intruder dimensions" | ✅ 确为本文原创概念 |
| LoRA-XS 只训练 r×r 矩阵 | ✅ W' = W + U_rΣ_r R V_rᵀ，A/B 冻结 |
| Zhao et al. 提出 contextual calibration | ✅ 空输入（content-free）估标签先验，机制一致 |
| Green AI 公开征召"经济与环境影响的基准"且自认未实证 | ✅ RQ4 原文即此问，作者自述框架"概念性、未经实证" |
| D'Amico 57 模型对比、微调平均 +15.1 F1 | ✅ IP&M 2026, 63(8):104910 确认 |
| FPB 4,840 句 / 16 标注者 / 4 档一致性 / 二分 1,966 句 | ✅ Malo et al. JASIST 2014 + HF dataset card 双确认 |
| FiQA-SA 原始发布 1,173 条 | ✅ 权威来源一致；**但我方实际分布为 1,213 条**，正文已注明差异 |

---

## 六、文献池未引用的 32 条

A4, B4, B7, C5, D4, E6, E7, F7, F9, G1, G2, G3, G4, H4, H5, H7, I2, I3, J3, J4, J5, K1–K5, K7–K12

**处置**：不进 References，保留在文献池作 rebuttal 弹药。其中 G 组（GPTQ/AWQ/LLM-Pruner/Wanda）与 C5（AdaLoRA）如在审稿意见中被要求对照，可直接补引。

---

## 七、仍需你确认的一项

**FiQA-SA 条数**：原始公开集为 **1,173** 条，我们数据管线跑出 **1,213** 条（20% held-out = 243，与实验一致）。正文已写成"1,213 labelled items in the distribution we obtained — the original release contains 1,173"，两边都交代了。

如需更稳，请到服务器执行一次：
```bash
wc -l /root/autodl-tmp/FinMLLM/data/unified/fiqa_sa.jsonl
```
若结果不是 1,213，告诉我实际值，我再回改。
