#!/usr/bin/env bash
# ============================================================
# FinMLLM / run_pending_checks.sh
# 开机一条命令跑完两项挂起验证（ERRATA E-26）：
#   FiQA 跨域迁移的三个数  —— 需要 GPU
#   Table A2 的能量丢弃诊断 —— 纯 CPU
#
# 用法 / Usage:
#   bash scripts/run_pending_checks.sh              # 前台，看进度
#   bash scripts/run_pending_checks.sh --bg         # 后台，合盖安全（推荐）
#   bash scripts/run_pending_checks.sh fiqa         # 只跑 FiQA
#   bash scripts/run_pending_checks.sh energy       # 只跑能量诊断
#   bash scripts/run_pending_checks.sh --bg all     # 后台跑全部
#
# 后台跑完怎么看结果：
#   tail -f logs/pending_checks_*.log
#
# 作者 / Author: Raymond Xiaohu Fan
# ============================================================
set -uo pipefail

# ---- 0. 定位项目根 ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# 自己的绝对路径 —— 后台重启时 $0 是相对路径，cd 之后就找不到了（踩过）
SELF="$SCRIPT_DIR/$(basename "${BASH_SOURCE[0]}")"
# 复现包里没有 ckpts/ 和 data/（12 GB，在主管项目里），所以要自动找到带数据的根。
# The repro package does not ship ckpts/ or data/, so locate the real project root.
if [ -z "${PROJ:-}" ]; then
  for cand in "$(cd "$SCRIPT_DIR/.." && pwd)" /root/autodl-tmp/FinMLLM; do
    if [ -d "$cand/ckpts_sft3" ] && [ -d "$cand/data/unified" ]; then
      PROJ="$cand"; break
    fi
  done
  PROJ="${PROJ:-$(cd "$SCRIPT_DIR/.." && pwd)}"
fi
export PROJ
cd "$PROJ" || { echo "❌ 进不去 $PROJ"; exit 1; }

# ---- 1. 解析参数 ----
BG=0; WHAT="all"
for a in "$@"; do
  case "$a" in
    --bg) BG=1 ;;
    fiqa|energy|all) WHAT="$a" ;;
    *) echo "未知参数: $a"; exit 2 ;;
  esac
done

# ---- 2. 后台模式：把自己重新拉起来 ----
mkdir -p logs
if [ "$BG" = "1" ] && [ "${_PENDING_BG:-0}" != "1" ]; then
  TS=$(date +%Y%m%d_%H%M%S)
  LOG="$PROJ/logs/pending_checks_${TS}.log"
  mkdir -p "$PROJ/logs"
  echo "🚀 后台启动"
  echo "   日志：$LOG"
  _PENDING_BG=1 nohup bash "$SELF" "$WHAT" > "$LOG" 2>&1 &
  echo "   PID=$!"
  echo "   跟进度：tail -f $LOG"
  exit 0
fi

# ---- 3. 找 python ----
PY=""
for c in "${PYTHON:-}" /root/miniconda3/bin/python /usr/bin/python3 "$(command -v python3 2>/dev/null)"; do
  [ -n "$c" ] && [ -x "$c" ] && PY="$c" && break
done
if [ -z "$PY" ]; then echo "❌ 找不到 python3"; exit 1; fi
echo "======================================================================"
echo " FinMLLM 挂起验证 / pending checks"
echo " 时间：$(date '+%F %T')"
echo " 项目：$PROJ"
echo " Python：$PY"
echo " 任务：$WHAT"
echo "======================================================================"

# ---- 4. 自检 ----
echo
echo "[0] 环境自检"
DF=$(df -m . | awk 'NR==2{print $4}')
echo "     磁盘剩余 ${DF} MB （需要 >2000 MB）"
if [ -d "$PROJ/ckpts_sft3" ]; then
  echo "     数据/ckpt：✅ $PROJ"
else
  echo "     ⚠️  $PROJ 下没有 ckpts_sft3/，请手动指定：PROJ=/root/autodl-tmp/FinMLLM bash $0"
fi
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader 2>/dev/null | sed 's/^/     GPU: /' || echo "     GPU: 无设备（无卡模式）"
  HASGPU=1
else
  echo "     GPU: 无 nvidia-smi（无卡模式）"
  HASGPU=0
fi

FAILED=0
SKIPPED=0

# 依赖自检：缺什么直接说，别等到 traceback 才知道
"$PY" - <<'PYEOF' 2>/dev/null || echo "     ⚠️  依赖自检失败"
import importlib, sys
need = ["numpy", "scipy", "safetensors", "torch", "transformers", "peft", "bitsandbytes"]
miss = []
for m in need:
    try:
        mod = importlib.import_module(m)
        v = getattr(mod, "__version__", "?")
        print(f"     {m:<16} {v}")
    except Exception:
        miss.append(m)
        print(f"     {m:<16} ❌ 缺失")
if miss:
    print(f"     ⚠️  缺 {', '.join(miss)}，跑 pip install -r requirements.txt")
    sys.exit(0)
PYEOF

# ---- 5. FiQA 迁移复核（需要 GPU）----
if [ "$WHAT" = "all" ] || [ "$WHAT" = "fiqa" ]; then
  echo
  echo "######################################################################"
  echo "# [1/2] FiQA 跨域迁移复核（期望 base=0.2428 / r16=0.6749 / r1=0.6543）"
  echo "######################################################################"
  if [ "$HASGPU" != "1" ]; then
    SKIPPED=$((SKIPPED+1))
    echo "   ⏭  跳过：没有 GPU。bitsandbytes 4-bit 需要 CUDA。"
    echo "      开卡后单独跑：bash scripts/run_pending_checks.sh fiqa"
  elif ! "$PY" -c "import torch" 2>/dev/null; then
    SKIPPED=$((SKIPPED+1))
    echo "   ⏭  跳过：这个 python 没装 torch（$PY）"
  else
    "$PY" "$SCRIPT_DIR/verify_fiqa_transfer.py"
    RC=$?
    if [ $RC -ne 0 ]; then
      echo "   ⚠️ FiQA 复核返回 $RC"
      FAILED=$((FAILED+1))
    fi
  fi
fi

# ---- 6. 能量丢弃诊断（纯 CPU，限制线程避免抢核）----
if [ "$WHAT" = "all" ] || [ "$WHAT" = "energy" ]; then
  echo
  echo "######################################################################"
  echo "# [2/2] Table A2 能量丢弃诊断（期望 E_drop=0.4306 / σ比=0.5199 / gap=1.95）"
  echo "######################################################################"
  # OMP_NUM_THREADS=1：不然 BLAS 会开满核，把机器压到 load 28（我踩过）
  if ! "$PY" -c "import numpy, safetensors" 2>/dev/null; then
    SKIPPED=$((SKIPPED+1))
    echo "   ⏭  跳过：缺 numpy 或 safetensors（$PY）"
    echo "      装一下：$PY -m pip install numpy safetensors"
  else
    OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
      "$PY" "$SCRIPT_DIR/check_energy_drop.py" ckpts_sft/fpb_r16 1
    RC=$?
    [ $RC -ne 0 ] && { echo "   ⚠️ 能量诊断返回 $RC"; FAILED=$((FAILED+1)); }
  fi
fi

# ---- 7. 汇总 ----
echo
echo "======================================================================"
if [ "$FAILED" = "0" ] && [ "$SKIPPED" -gt 0 ]; then
  echo " ⏭  有 $SKIPPED 项被跳过，实际没有执行任何检查。"
  echo "    开卡后重跑：bash scripts/run_pending_checks.sh --bg"
elif [ "$FAILED" = "0" ]; then
  echo " ✅ 本次任务全部跑完，没有异常退出。"
  echo "    把上面的对照表贴回对话，我把结论写进 ERRATA 并把 E-26 关掉。"
else
  echo " ⚠️  有 $FAILED 项异常（见上方 ⚠️ / ❌ 行）。"
fi
echo " 结束时间：$(date '+%F %T')"
echo "======================================================================"
exit 0
