#!/usr/bin/env python3
# ============================================================
# FinMLLM / e0_spectral.py
# E0 — the make-or-break test: is the Delta-W spectrum of financial domains
# genuinely more concentrated than a general-domain adapter?
# E0 —— 生死判据：金融域的 Delta-W 谱能量，是否真的比通用域更集中？
#
# Author : Raymond Xiaohu Fan
# Note   : If H0 dies here, we pivot to Fork D without regret. / 如果 H0 在这里挂了，就干脆转 Fork D，不恋战。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/e0_spectral.py --ckpt_dir ckpts
#   python scripts/e0_spectral.py --ckpt_dir ckpts --baseline_dir ckpts/general_qlora_s42
# ============================================================
import os, sys, json, glob, argparse, itertools
import numpy as np
from scipy.fftpack import dct
from scipy.stats import wilcoxon

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)

K_LIST = [5, 10, 20, 30]
N_BANDS = 10


# ---------- spectrum helpers ----------
def dct2(x):
    return dct(dct(x.T, norm="ortho").T, norm="ortho")


def energy_concentration(W, k_percent):
    """Fraction of total DCT energy held by the top k% coefficients.
    前 k% 系数占总能量的比例。"""
    C = dct2(W)
    e = np.sort((C ** 2).ravel())[::-1]
    total = e.sum()
    if total <= 0:
        return 0.0
    k = max(1, int(len(e) * k_percent / 100))
    return float(e[:k].sum() / total)


def spectral_entropy(W):
    C = dct2(W)
    p = (C ** 2).ravel()
    p = p / p.sum() if p.sum() > 0 else p
    p = p[p > 0]
    return float(-(p * np.log(p)).sum())


def band_profile(W, n_bands=N_BANDS):
    """Radial band energy distribution (Gamma_D).
    径向频带能量分布（Gamma_D），10 带。"""
    C = dct2(W)
    E = C ** 2
    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    r = np.sqrt((yy / max(h - 1, 1)) ** 2 + (xx / max(w - 1, 1)) ** 2)
    r = r / r.max()
    edges = np.linspace(0, 1, n_bands + 1)
    p = np.array([E[(r >= edges[i]) & (r <= edges[i + 1] + 1e-12)].sum() for i in range(n_bands)])
    return p / p.sum() if p.sum() > 0 else p


def low_freq_ratio(W, thr=0.3):
    C = dct2(W); E = C ** 2
    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    r = np.sqrt((yy / max(h - 1, 1)) ** 2 + (xx / max(w - 1, 1)) ** 2); r /= r.max()
    return float(E[r <= thr].sum() / max(E.sum(), 1e-12))


# ---------- adapter loading ----------
def load_deltas(adapter_dir, max_layers=32):
    """Return list of Delta-W = B@A*scaling, one per adapted layer.
    返回每层 Delta-W = B@A*scaling 的列表。"""
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files:
        return [], None
    sd = load_file(files[0])
    scale = 1.0
    cfg_path = os.path.join(adapter_dir, "adapter_config.json")
    if os.path.exists(cfg_path):
        cfg = json.load(open(cfg_path))
        r = cfg.get("r") or cfg.get("lora_r") or 16
        alpha = cfg.get("lora_alpha") or 32
        scale = alpha / r
    keys = [k for k in sd if "lora_A" in k]
    ws = []
    for k in sorted(keys)[:max_layers]:
        kb = k.replace("lora_A", "lora_B")
        if kb not in sd:
            continue
        A = sd[k].float().cpu().numpy()
        B = sd[kb].float().cpu().numpy()
        W = (B @ A) * scale
        if W.size < 64:
            continue
        ws.append(W)
    return ws, scale


def summarize(ws):
    """Per-layer metrics -> arrays. / 每层指标 -> 数组。"""
    out = {f"EC{k}": [] for k in K_LIST}
    out["H"] = []; out["low"] = []
    out["profile"] = []
    for W in ws:
        for k in K_LIST:
            out[f"EC{k}"].append(energy_concentration(W, k))
        out["H"].append(spectral_entropy(W))
        out["low"].append(low_freq_ratio(W))
        out["profile"].append(band_profile(W))
    return out


def holm(pvals, names):
    """Holm-Bonferroni correction, dependency-free.
    无依赖的 Holm 校正。"""
    order = np.argsort(pvals)
    m = len(pvals)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * pvals[idx]
        running = max(running, val)
        adj[idx] = min(1.0, running)
    return {names[i]: float(adj[i]) for i in range(m)}


def kl(p, q, eps=1e-12):
    p = np.asarray(p) + eps; q = np.asarray(q) + eps
    p = p / p.sum(); q = q / q.sum()
    return float(np.sum(p * np.log(p / q)))


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_dir", default=os.path.join(ROOT, "ckpts"))
    ap.add_argument("--baseline_dir", default=None,
                    help="general-domain adapter for comparison / 通用域对照 adapter")
    args = ap.parse_args()

    print("=" * 78)
    print(" E0 · SPECTRAL IDENTITY TEST / 谱身份检验")
    print(f" ckpt_dir = {args.ckpt_dir}")
    print("=" * 78)

    # discover domain adapters / 发现各业务线 adapter
    found = {}
    for d in sorted(glob.glob(os.path.join(args.ckpt_dir, "*_qlora*"))):
        dom = os.path.basename(d).split("_qlora")[0]
        ws, scale = load_deltas(d)
        if ws:
            found[dom] = ws
            print(f"  ✅ {dom:<12} {len(ws)} layers  (scale={scale})")
        else:
            print(f"  ⚠️  {dom:<12} no lora weights found")

    if not found:
        print("\n❌ 没有任何 adapter。先跑 train_domain.py。")
        return 2

    # per-domain summary / 逐域汇总
    print("\n" + "-" * 78)
    print(f"{'domain':<14}{'layers':>7}" + "".join(f"{'EC'+str(k):>8}" for k in K_LIST)
          + f"{'H':>9}{'low':>8}")
    print("-" * 78)
    table1 = {}
    for dom, ws in found.items():
        s = summarize(ws)
        table1[dom] = {k: (float(np.mean(v)) if isinstance(v, list) and v and not isinstance(v[0], list) else v)
                       for k, v in s.items()}
        row = f"{dom:<14}{len(ws):>7}"
        for k in K_LIST:
            row += f"{np.mean(s['EC'+str(k)]):>8.3f}"
        row += f"{np.mean(s['H']):>9.2f}{np.mean(s['low']):>8.3f}"
        print(row)

    # baseline comparison / 与通用域对照
    stats_out = {}
    if args.baseline_dir and os.path.isdir(args.baseline_dir):
        bws, _ = load_deltas(args.baseline_dir)
        if bws:
            bs = summarize(bws)
            print("\n" + "-" * 78)
            print(" H0 test: financial vs general / 金融域 vs 通用域")
            print("-" * 78)
            pvals, names = [], []
            for dom, ws in found.items():
                s = summarize(ws)
                for k in K_LIST:
                    a = np.array(s[f"EC{k}"]); b = np.array(bs[f"EC{k}"])
                    n = min(len(a), len(b))
                    if n < 5:
                        continue
                    try:
                        stat, p = wilcoxon(a[:n], b[:n], alternative="greater")
                    except Exception:
                        continue
                    pvals.append(p); names.append(f"{dom}:EC{k}")
                    print(f"  {dom:<12} EC{k:<3} fin={a[:n].mean():.3f} gen={b[:n].mean():.3f} "
                          f"p={p:.4g}")
            if pvals:
                adj = holm(pvals, names)
                sig = [n for n in names if adj[n] < 0.05]
                print(f"\n  Holm-adjusted significant: {len(sig)}/{len(names)} -> {sig}")
                stats_out = {"holm": adj, "significant": sig}
                print("\n  🎯 H0 成立（至少 2 个 k 显著）" if len(sig) >= 2
                      else "\n  ⚠️ H0 未获支持 → 按 02 文档转 Fork D")
        else:
            print("\n  ⚠️ baseline adapter 无 lora 权重，跳过对比")
    else:
        print("\n  ℹ️  未提供 --baseline_dir，仅做域间对比（不做 H0 检验）")

    # cross-domain KL matrix / 域间 KL 矩阵
    print("\n" + "-" * 78)
    print(" Gamma_D KL matrix / 谱轮廓 KL 矩阵")
    profs = {d: np.mean([band_profile(w) for w in ws], axis=0) for d, ws in found.items()}
    names = list(profs)
    print("           " + "".join(f"{n[:10]:>12}" for n in names))
    M = np.zeros((len(names), len(names)))
    for i, n in enumerate(names):
        for j, m in enumerate(names):
            M[i, j] = kl(profs[n], profs[m])
        print(f"{n:<11}" + "".join(f"{M[i,j]:>12.4f}" for j in range(len(names))))
    off = [M[i, j] for i, j in itertools.permutations(range(len(names)), 2)]
    print(f"\n  off-diagonal KL>0: {sum(1 for x in off if x > 1e-6)}/{len(off)}")

    # persist / 落盘
    out = {
        "table1": table1,
        "profiles": {k: v.tolist() for k, v in profs.items()},
        "kl_matrix": M.tolist(),
        "domains": names,
        "stats": stats_out,
    }
    p = os.path.join(REP, "e0_spectral.json")
    json.dump(out, open(p, "w"), indent=2, ensure_ascii=False)
    print(f"\n💾 saved -> {p}")
    print("=" * 78)


if __name__ == "__main__":
    main()
