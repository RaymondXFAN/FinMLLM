# scripts 索引 —— 哪个脚本出哪张表

> 规则：**带 ⭐ 的是论文数字的直接来源**。其余是辅助、部署或早期探索。
> 想复现论文某张表，只认 ⭐ 那几个，别用同名的历史版本。

---

## A. 数据准备 / Data

| 脚本 | 作用 |
|---|---|
| `fetch_raw.py` | 拉原始语料（走 HF mirror），产出 `data/raw/` |
| `prep_data.py` | 原始 → 统一 `data/unified/*.jsonl`（`{"id","text","label","source","split"}`） |
| `prep_raw.py` | 早期版预处理，历史保留 |
| `build_v2_corpus.py` | v2 语料（业务线 CPT 用），论文主实验不依赖 |
| `fetch_edgar_sec.py` / `fetch_fineval.py` / `fetch_general_corpus.py` / `fetch_v2_corpus.py` | 各来源抓取（SEC EDGAR / FinEval / 通用语料），服务于业务线 CPT |
| `check_data.py` | 下载体检：哪些好了、哪些坏了、行数对不对 |
| `supp/fix_fiqa.py` | ⚠️ **FiQA 必跑**：label 列是股票代码，要按取值判定 |

## B. 训练 / Training

| 脚本 | 作用 |
|---|---|
| ⭐ `rv_train_sft.py` | **论文所有 adapter 的训练脚本**。`--seed` 与 `--split-seed` 分离，split 固定 42 |
| `train_sft.py` | 上游母版，`rv_` 是它 patch 出来的；直接用它出数有 79% 泄漏风险（ERRATA E-01） |
| `make_rv_train_patch.py` | 生成 `rv_train_sft.py` 的 patch 工具，改 `train_sft.py` 后重跑它 |
| `train_domain.py` | 业务线 CPT adapter 训练（Table A1 的 10 个 adapter） |

## C. 评测 / Evaluation

| 脚本 | 作用 |
|---|---|
| ⭐ `rv_eval_preds.py` | **论文所有 acc / McNemar 的来源**。产出带逐样本 `preds` 的 json |
| ⭐ `eval_cloze.py` | 评测内核（cloze + null-context 校准，`split="test"`）。被 `rv_eval_preds.py` import |
| ~~`eval_adapter.py`~~ | ⛔ 已弃用（不按 split 过滤，从 100% 随机抽），见 `_deprecated/` |

## D. 压缩与变体 / Compression & variants

| 脚本 | 作用 |
|---|---|
| ⭐ `rv_lowrank.py` | **论文所有压缩 adapter 的来源**。QR-core + r×r SVD，一个 adapter **23 秒** |
| `make_lowrank_adapter.py` | 稠密 SVD 版，数学等价但慢 30 倍（11 分钟）。仅历史对照 |
| ⭐ `rv_make_variants.py` | mask 40/60/80%、random-direction 5 抽样 |
| ⭐ `rv_para_baseline.py` | PARA 全局能量阈值基线，5 档 q |

## E. 谱分析 / Spectral diagnostics

| 脚本 | 作用 |
|---|---|
| ⭐ `spectral_table3.py` | **Table 3 的唯一权威实现**。含 `k_eff` 封顶、`d_side=max(dW.shape)`、解析高斯基线 |
| `analyze_adapter_rank.py` | 另一套指标（n50/n90/n99、top-1 share），用于逐层分布分析，**不能与 Table 3 混比** |
| `e0_spectral.py` / `e0b_spectral.py` / `e0c_kscan.py` / `e0d_seed_attribution.py` / `e0e_register_vs_domain.py` | 早期 E0 系列探索（谱结构门槛、k 扫描、种子归因、语域 vs 领域），**非论文直接依赖** |
| ~~`rv_spectral_table3.py`~~ | ⛔ 旧版，高斯基线写死 13.55（错），见 `_deprecated/` |

## F. 汇总统计 / Aggregation

| 脚本 | 作用 |
|---|---|
| ⭐ `rv_summarize.py` | McNemar + TOST，生成配对检验汇总 |
| `supp/s4_summarize.py` / `supp/sigtest.py` | 补充实验的汇总与显著性 |
| `supp/s1_rank_metrics.py` | 全项目 adapter 谱审计 |
| `supp/s2_make_variants.py` | 能量轴 / mask / 随机方向变体（supp 版） |
| `rv_status.py` | 跑批进度估算（还剩几个、大约多久） |

## G. 跑批编排 / Orchestration

| 脚本 | 作用 |
|---|---|
| `rv_overnight.sh` | 夜间串行跑批（**串行是硬要求**，并行会 CPU 超订卡死） |
| `rv_e1_fulltest.sh` | E1 全量测试集重跑 |
| `rv_eval_supp.sh` | 补充实验批量评测 |
| `rv_fiqa_pipeline.sh` | FiQA 全链路（修数据 → 训练 → 截断 → 评测） |
| `rv_monitor.sh` / `supp/status_supp.sh` / `supp/check_progress.sh` | 进度看板 |
| `supp/night_run.sh` / `supp/run_supp.sh` / `supp/s3_gpu_queue.sh` | 补充实验编排（含显存闸门） |

## H. 部署与环境 / Deploy

| 脚本 | 作用 |
|---|---|
| `bootstrap.sh` | 建目录、软链、基础环境 |
| `bootstrap_new_machine.sh` | 新机一键部署（含全部踩坑经验，推荐） |
| `deploy_remote.sh` / `deploy_local.sh` | 幂等部署（保护已有数据） |
| `download_data.sh` | 数据集下载（hf-mirror） |
| `migrate_data.sh` | 把别处已下载的数据迁到数据盘（只复制不移动） |
| `run_bg.sh` | **后台启动器**（nohup + 时间戳目录，合盖安全） |
| `status.sh` | 状态看板（`--watch` 实时） |
| `lib_probe.py` / `lib_probe.sh` | 环境与库探针（trace/step + 栈） |
| `run_gates.sh` + `gates/g0–g5.py` | 6 个闸门：环境 / 算子 / 数据 / 训练 / 性能 / 迁移 |

## I. 论文与图表生产线 / Manuscript

| 脚本 | 作用 |
|---|---|
| `make_docx.py` | 长文版 Word（`--mode review` 出内审版：双倍行距+行号） |
| `make_docx_frl.py` | FRL 短版 Word（单栏 12pt，2 表 1 图） |
| `make_frl_frontmatter.py` | Cover Letter + 独立 Highlights 文件 |
| `make_figures.py` | 长文版 Fig 1–5（莫兰迪配色，300 DPI） |
| `make_fig_frl.py` | FRL 版唯一图（ratio vs 压缩代价） |
| `renumber_refs.py` | 占位符 → 数字编号（按首次出现） |
| `build_references.py` | Springer Basic 参考文献表 |
| `clean_manuscript.py` | 剥离内部备忘、中文标题改英文 |
| `consistency_check.py` | 引用 / 图表 / 数字 / 术语交叉核查 |

---

## 一句话版本

复现论文 = `rv_train_sft.py` → `rv_lowrank.py` → `rv_eval_preds.py` → `rv_summarize.py` → `spectral_table3.py`，
然后用 `verify/verify_all.py` 对一遍。**五个脚本，一条链。**
