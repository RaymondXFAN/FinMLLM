#!/usr/bin/env bash
# 采样 GPU/CPU 占用，每 5 秒一行，直到 STOP 文件出现
OUT="$1"; : > "$OUT"
while [ ! -f /tmp/rv_stop ]; do
  GPU=$(nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader,nounits | tr -d ' ')
  CPU=$(top -bn1 | grep -E "^%Cpu" | awk '{print $2"us+"$4"sy"}')
  LOAD=$(cut -d' ' -f1-3 /proc/loadavg)
  echo "$(date '+%H:%M:%S') GPU=$GPU CPU=$CPU LOAD=$LOAD" >> "$OUT"
  sleep 5
done
