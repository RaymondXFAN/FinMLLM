#!/usr/bin/env python3
# ============================================================
# FinMLLM / lib_probe.py
# Observability helpers for Python: every step leaves a breadcrumb with
# timestamp, duration, memory and exception traceback.
# Python 侧可观测性：每一步都留下时间戳、耗时、显存与异常栈。
#
# Author : Raymond Xiaohu Fan
# Note   : Debugging is twice as hard as writing code; log accordingly. / 调试比写代码难一倍，所以日志要写够。
# Updated: 2026-10-19
#
# Usage / 用法:
#   from lib_probe import trace, step, probe
#
#   @trace
#   def train_one_seed(seed): ...
#
#   with step("load-dataset", n=1000):
#       ds = load(...)
# ============================================================
import os, sys, json, time, functools, traceback, contextlib, threading

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
LOG_DIR = os.path.join(PROJ, "outputs", "logs")
os.makedirs(LOG_DIR, exist_ok=True)
RUN_TAG = os.environ.get("PROBE_TAG", time.strftime("%Y%m%d_%H%M%S"))
LOG_PATH = os.path.join(LOG_DIR, f"probe_py_{RUN_TAG}.log")
JSONL_PATH = os.path.join(LOG_DIR, f"probe_py_{RUN_TAG}.jsonl")
_lock = threading.Lock()

def _emit(kind, payload):
    payload = {"ts": time.strftime("%F %T"), "kind": kind, "pid": os.getpid(),
               "thread": threading.current_thread().name, **payload}
    line = json.dumps(payload, ensure_ascii=False)
    with _lock:
        with open(JSONL_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        human = f"[{payload['ts']}] {kind.upper():<6} {payload.get('name','')}"
        if payload.get("dur") is not None:
            human += f"  dur={payload['dur']:.2f}s"
        if payload.get("note"):
            human += f"  {payload['note']}"
        print(human, flush=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(human + "\n")

def _vram():
    try:
        import torch
        if torch.cuda.is_available():
            return round(torch.cuda.max_memory_allocated() / 1024**3, 2)
    except Exception:
        pass
    return None

def probe(msg, **kw):
    """Free-form breadcrumb / 任意面包屑."""
    _emit("probe", {"name": msg, **kw})

@contextlib.contextmanager
def step(name, **kw):
    """Timed, traced block. Exceptions are logged with full traceback.
    带计时与追踪的代码块，异常会带完整栈记录。"""
    t0 = time.time()
    _emit("start", {"name": name, "vram_gb": _vram(), **kw})
    try:
        yield
        _emit("done", {"name": name, "dur": time.time() - t0, "vram_gb": _vram()})
    except Exception as e:
        _emit("error", {"name": name, "dur": time.time() - t0,
                        "note": f"{type(e).__name__}: {e}",
                        "traceback": traceback.format_exc()[-2000:]})
        raise

def trace(fn):
    """Decorator: log entry, exit, duration and exceptions.
    装饰器：记录进入、退出、耗时与异常。"""
    @functools.wraps(fn)
    def wrapper(*a, **k):
        t0 = time.time()
        _emit("start", {"name": fn.__qualname__, "vram_gb": _vram(),
                        "args": str(a)[:200], "kwargs": str(k)[:200]})
        try:
            r = fn(*a, **k)
            _emit("done", {"name": fn.__qualname__, "dur": time.time() - t0, "vram_gb": _vram()})
            return r
        except Exception as e:
            _emit("error", {"name": fn.__qualname__, "dur": time.time() - t0,
                            "note": f"{type(e).__name__}: {e}",
                            "traceback": traceback.format_exc()[-2000:]})
            raise
    return wrapper

def install_excepthook():
    """Make uncaught exceptions leave a forensic trail.
    让未捕获异常也留下现场。"""
    def _hook(etype, value, tb):
        _emit("uncaught", {"name": etype.__name__,
                           "note": str(value)[:300],
                           "traceback": "".join(traceback.format_exception(etype, value, tb))[-4000:]})
        sys.__excepthook__(etype, value, tb)
    sys.excepthook = _hook

install_excepthook()

if __name__ == "__main__":
    with step("self-test"):
        time.sleep(0.1)
    probe("lib_probe ready", log=LOG_PATH)
    print(f"log -> {LOG_PATH}")
