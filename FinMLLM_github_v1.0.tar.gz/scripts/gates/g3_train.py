#!/usr/bin/env python3
# ============================================================
# FinMLLM / g3_train.py
# G3 short training gate: 20 steps to catch the four historical bugs.
# G3 短训练 gate：20 步抓四类历史 bug。
#
# Author : Raymond Xiaohu Fan
# Note   : We lost a week to the save bug once. Never again. / 那个保存 bug 坑过我们一周，绝不再犯。
# Updated: 2026-10-19
# ============================================================

"""G3 · 单步训练 gate（需 GPU）。

只跑 20 step，专抓四类致命 bug：
  1) loss 是否有限 / 是否下降
  2) lora_B 是否全 0（历史 bug：保存的是训练前权重）
  3) save_pretrained -> 重载 后参数是否一致
  4) 是否有全 mask 样本（TRL 历史坑）
用法：python scripts/gates/g3_train.py
"""
import os, sys, tempfile, torch
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
MODEL = os.environ.get("BASE_MODEL", "Qwen/Qwen2.5-7B")
STEPS = int(os.environ.get("G3_STEPS", "20"))

def main():
    if not torch.cuda.is_available():
        print("❌ 无 GPU。请先开卡（或本 gate 跳过）。")
        return 5
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

    print("=" * 70); print(f"G3 · 单步训练 gate | model={MODEL} | steps={STEPS}"); print("=" * 70)

    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                             bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
    tok = AutoTokenizer.from_pretrained(MODEL, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(MODEL, quantization_config=bnb,
                                                 device_map={"": 0}, trust_remote_code=True)
    model = prepare_model_for_kbit_training(model)
    lora_cfg = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias="none",
                          task_type="CAUSAL_LM",
                          target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"])
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    # Synthetic samples: no dependency on real data, this gate only exercises the pipeline
    # 合成样本（不依赖真实数据，专测管线）
    texts = [
        "### Instruction:\nClassify the sentiment of the following financial sentence.\n"
        "### Sentence:\nThe bank reported a sharp decline in net interest income amid rising provisions.\n"
        "### Response:\nnegative<|endoftext|>"
    ] * 64
    enc = tok(texts, return_tensors="pt", padding=True, truncation=True, max_length=512).to("cuda")
    labels = enc["input_ids"].clone()
    labels[enc["attention_mask"] == 0] = -100

    # Check 4: are all labels masked out? (the classic TRL pitfall)
    # 检查 4：是否全 mask
    valid_ratio = (labels != -100).float().mean().item()
    print(f"{'✅' if valid_ratio > 0.02 else '❌'} 有效标签比例 {valid_ratio:.2%}（>2% 才算正常）")

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=2e-4)
    losses = []
    model.train()
    bs = 4
    for step in range(STEPS):
        idx = (step * bs) % len(texts)
        batch = {k: v[idx:idx+bs] for k, v in enc.items()}
        out = model(**batch, labels=labels[idx:idx+bs])
        loss = out.loss
        loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
        losses.append(loss.item())
        if step % 5 == 0:
            print(f"  step {step:02d}  loss={loss.item():.4f}  "
                  f"vram={torch.cuda.max_memory_allocated()/1024**3:.2f}GB")

    finite = all(np.isfinite(losses))
    print(f"{'✅' if finite else '❌'} loss 全部有限  first={losses[0]:.3f} last={losses[-1]:.3f}")
    trend = losses[-1] < losses[0]
    print(f"{'✅' if trend else '⚠️ '} loss 是否下降  {losses[0]:.3f} -> {losses[-1]:.3f}")

    # Check 2: is lora_B actually non-zero? (this exact bug cost us a week)
    # 检查 2：lora_B 是否非零
    lora_b_norms = []
    for n, p in model.named_parameters():
        if "lora_B" in n:
            lora_b_norms.append(p.detach().float().norm().item())
    nonzero = sum(1 for x in lora_b_norms if x > 1e-8)
    print(f"{'✅' if nonzero == len(lora_b_norms) and len(lora_b_norms)>0 else '❌'} "
          f"lora_B 非零层 {nonzero}/{len(lora_b_norms)}  "
          f"(min_norm={min(lora_b_norms) if lora_b_norms else 0:.2e})")

    # Check 3: save-and-reload consistency (use trainer.save_model, not the outer model)
    # 检查 3：保存-重载一致性（用 trainer.save_model 的正确方式）
    # Compare what is IN MEMORY against what actually landed ON DISK.
    # Keys must come from get_peft_model_state_dict(), otherwise the sets never intersect
    # and the check silently passes with max|Δ|=-1 (exactly the trap we fell into).
    # 用 get_peft_model_state_dict 取干净 key，直接对比"内存里的"和"磁盘上的"，
    # 否则 key 集合不相交，检查会静默假通过（正是我们踩过的坑）。
    with tempfile.TemporaryDirectory() as tmp:
        model.save_pretrained(tmp)
        from safetensors.torch import load_file
        from peft import get_peft_model_state_dict
        mem = {k: v.detach().float().cpu() for k, v in get_peft_model_state_dict(model).items()}
        fpath = os.path.join(tmp, "adapter_model.safetensors")
        saved = {k: v.float().cpu() for k, v in load_file(fpath).items()} if os.path.exists(fpath) else {}
        common = sorted(set(mem) & set(saved))
        if not common:
            maxdiff = float("inf")
            print("❌ 保存-重载一致性  无法比较（key 不匹配）")
            print(f"   mem  keys: {list(mem)[:2]}")
            print(f"   file keys: {list(saved)[:2]}")
        else:
            diffs = [torch.norm(mem[k] - saved[k]).item() for k in common]
            maxdiff = max(diffs)
            print(f"{'✅' if maxdiff < 1e-6 else '❌'} 保存-重载一致性  "
                  f"max|Δ|={maxdiff:.2e}  ({len(common)} tensors compared)")
            # Extra guard: the saved lora_B must not be all zeros.
            # 额外保险：磁盘上的 lora_B 也不能是全零。
            bnorm = [v.norm().item() for k, v in saved.items() if "lora_B" in k]
            if bnorm:
                nz = sum(1 for x in bnorm if x > 1e-8)
                print(f"{'✅' if nz == len(bnorm) else '❌'} 磁盘 lora_B 非零 {nz}/{len(bnorm)}")

    all_ok = (finite
              and (nonzero == len(lora_b_norms) and len(lora_b_norms) > 0)
              and valid_ratio > 0.02
              and maxdiff < 1e-6)   # save-and-reload must actually be verified
    print("-" * 70)
    print("🎉 G3 PASS" if all_ok else "⚠️ G3 FAIL — 先修再上 overnight")
    return 0 if all_ok else 6

if __name__ == "__main__":
    raise SystemExit(main())
