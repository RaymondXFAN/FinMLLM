#!/usr/bin/env python3
# ============================================================
# FinMLLM / check_energy_drop.py
# 复算 Table A2：1/16 截断丢了多少谱能量、最大被丢 σ/σ1、截断点谱间隙。
# Recompute Table A2: energy discarded at the 1/16 cut, max dropped sigma/sigma1, gap.
#
# 为什么不用 dW = B@A 直接 SVD：11008×2048 的稠密 SVD 要跑几分钟，
# 252 个矩阵能跑到天荒地老（这就是 ERRATA E-04 那个坑）。
# 用 QR 把 B、A 各自压到 r×r 核上，奇异值完全等价，快几百倍。
#
# Author: Raymond Xiaohu Fan
# Usage: python3 check_energy_drop.py <adapter_dir> [rank]
# ============================================================
import sys, os, glob, math
import numpy as np
from safetensors.numpy import load_file

def core_singular_values(A, B):
    """dW = B@A 的非零奇异值，绕开大矩阵。
       Non-zero singular values of B@A without forming it."""
    # A: [r, in] -> A^T: [in, r]
    Qa, Ra = np.linalg.qr(A.T.astype(np.float64))   # Ra: [r, r]
    Qb, Rb = np.linalg.qr(B.astype(np.float64))     # Rb: [out, r]
    s = np.linalg.svd(Rb @ Ra.T, compute_uv=False)  # r 个奇异值
    return np.sort(s)[::-1]

def main():
    PROJ = os.environ.get("PROJ", ".")
    d = sys.argv[1] if len(sys.argv) > 1 else "ckpts_sft/fpb_r16"
    if not os.path.isabs(d) and not os.path.isdir(d):
        d = os.path.join(PROJ, d)      # 包内跑时用 PROJ 兜底
    K = int(sys.argv[2]) if len(sys.argv) > 2 else 1     # 截断目标秩
    W = {}
    for f in sorted(glob.glob(os.path.join(d, "*.safetensors"))):
        W.update(load_file(f))
    pairs = {}
    for k in W:
        if "lora_A" in k:
            pairs.setdefault(k.replace("lora_A", ""), {})["A"] = W[k]
        elif "lora_B" in k:
            pairs.setdefault(k.replace("lora_B", ""), {})["B"] = W[k]
    pairs = {k: v for k, v in pairs.items() if "A" in v and "B" in v}
    print(f"adapter: {d}")
    print(f"layers : {len(pairs)}")

    Ed, Rd, Gd = [], [], []
    total = len(pairs)
    for idx, (k, v) in enumerate(pairs.items(), 1):
        # 每 50 层报一次进度 —— 不然看着像卡死（我自己就怀疑过）
        # Print progress every 50 layers; silence looks like a hang.
        if idx % 50 == 0 or idx == total:
            print(f"  ... {idx}/{total} 层", flush=True)
        s = core_singular_values(v["A"], v["B"])
        e = s ** 2
        tot = e.sum()
        kept = e[:K].sum()
        Ed.append(1.0 - kept / tot)          # 丢弃能量占比
        if len(s) > K and s[0] > 0:
            Rd.append(s[K] / s[0])           # 最大被丢 σ / σ1
        if len(s) > K and s[K] > 0:
            Gd.append(s[K - 1] / s[K])       # 截断点谱间隙 σ_k / σ_{k+1}
    Ed, Rd, Gd = np.array(Ed), np.array(Rd), np.array(Gd)
    print()
    print(f"E_drop (1/{len(pairs[list(pairs)[0]]['A'])} cut)   mean={Ed.mean():.4f}  median={np.median(Ed):.4f}")
    print(f"max dropped sigma/sigma1  mean={Rd.mean():.4f}  max={Rd.max():.4f}")
    print(f"spectral gap at cut       median={np.median(Gd):.4f}  mean={Gd.mean():.4f}")
    print()
    print("论文 Table A2 声称：E_drop=0.4306 (43.1%) / max sigma ratio=0.5199 / gap=1.95")
    ok = abs(Ed.mean() - 0.4306) < 0.02
    print(f"→ E_drop 判定: {'✅ 一致' if ok else '❌ 不一致，差 %.4f' % (Ed.mean()-0.4306)}")

if __name__ == "__main__":
    main()
