#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_status.py
# 看进度 + 按实测速度外推完成时间。
# Progress report with ETA extrapolated from actual per-run timings.
#
# 不用固定的"每个 run 多少分钟"去算——7B 的 r16 和 r64 差一倍，
# binary 和 ternary 又差三倍。这里读日志里的真实时间戳来推。
#
# No fixed per-run estimate: r64 costs twice r16, ternary three times binary.
# Timings are read off the log's own timestamps.
#
# Author : Raymond Xiaohu Fan
# Usage: python scripts/rv_status.py
# ============================================================
import os, re, glob, json, subprocess, sys
from datetime import datetime, timedelta

ROOT = "/root/autodl-tmp/FinMLLM"
LOG = os.path.join(ROOT, "logs", "overnight.log")

# 7B 队列的规格（和 rv_overnight.sh 保持一致）
PLAN_7B = [("bin", 2, 16, 42), ("tri", 3, 16, 42), ("bin", 2, 64, 42),
           ("tri", 3, 64, 42), ("bin", 2, 16, 123), ("tri", 3, 16, 123)]

# 冒烟实测：7B r16 约 2.0 s/step。步数按任务估算。
STEP = {"bin": 590, "tri": 1452}
SEC_PER_STEP = {16: 2.0, 64: 2.6}          # r64 略慢
LOAD_SEC = 60                               # 模型加载 + 保存


def parse_log():
    """返回 [(时间, 行)]"""
    if not os.path.exists(LOG):
        return []
    out = []
    for line in open(LOG, encoding="utf-8", errors="ignore"):
        m = re.match(r"\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\]\s*(.*)", line)
        if m:
            out.append((datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"), m.group(2)))
    return out


def main():
    now = datetime.now()
    ev = parse_log()

    print("=" * 74)
    print(f" FinMLLM 夜间队列状态   现在 {now.strftime('%H:%M:%S')}")
    print("=" * 74)

    if not ev:
        print(" ❌ 日志不存在或还没有带时间戳的行")
        print(f"    {LOG}")
        return 2

    # ---- 当前阶段 ----
    stage = "(未开始)"
    for t, msg in ev:
        if msg.startswith("===") and "PART" not in msg:
            stage = msg.strip("= ")
    print(f"\n 当前阶段: {stage}")
    print(f" 启动时间: {ev[0][0].strftime('%H:%M:%S')}   已运行 {(now-ev[0][0]).total_seconds()/3600:.2f} 小时")

    # ---- 阶段完成情况 ----
    done_stage = [m for t, m in ev if m.startswith("=== ALL DONE")]
    if done_stage:
        print("\n 🎉 全部完成")
        fails = re.search(r"failures=(\d+)", done_stage[-1])
        if fails:
            print(f"    失败 {fails.group(1)} 个")

    # ---- PARA ----
    para = glob.glob(os.path.join(ROOT, "outputs/reports/rv_para/*.json"))
    print(f"\n [1/3] PARA 基线      {len(para):>2}/10 个")

    # ---- FiQA ----
    fiqa = [d for d in glob.glob(os.path.join(ROOT, "ckpts_rv/fiqa_*"))
            if os.path.exists(os.path.join(d, "adapter_model.safetensors"))]
    print(f" [2/3] FiQA adapter   {len(fiqa):>2}/2 个")

    # ---- 7B ----
    print(f"\n [3/3] Qwen2.5-7B")
    done = {}
    for task, cls, rk, sd in PLAN_7B:
        d = os.path.join(ROOT, f"ckpts_rv/7b_c{cls}_r{rk}_s{sd}")
        ok = os.path.exists(os.path.join(d, "adapter_model.safetensors"))
        if ok:
            sz = os.path.getsize(os.path.join(d, "adapter_model.safetensors")) / 1024**2
            done[(task, rk, sd)] = sz
            print(f"   ✅ {task} r{rk:<2} s{sd:<5} {sz:>6.1f} MB")
        else:
            print(f"   ⏳ {task} r{rk:<2} s{sd:<5} 未完成")

    # ---- 实测速度（从日志里找最后两个 ok 的时间差）----
    oks = [(t, m) for t, m in ev if m.strip() == "ok"]
    print(f"\n 日志里已记录成功 run: {len(oks)} 个")

    # ---- ETA ----
    remaining = []
    for task, cls, rk, sd in PLAN_7B:
        if (task, rk, sd) not in done:
            secs = STEP[task] * SEC_PER_STEP.get(rk, 2.2) + LOAD_SEC
            remaining.append((task, rk, sd, secs))

    if remaining:
        total_sec = sum(x[3] for x in remaining)
        print(f"\n 剩余 7B: {len(remaining)} 个")
        for task, rk, sd, secs in remaining:
            print(f"   · {task} r{rk:<2} s{sd:<5}  约 {secs/60:>5.1f} 分钟")
        eta = now + timedelta(seconds=total_sec)
        print(f"\n 预计全部结束: {eta.strftime('%H:%M')}  "
              f"（还要 {total_sec/3600:.2f} 小时）")
    else:
        print("\n 7B 已全部完成")
        eta = now

    # ---- 关机建议 ----
    print("\n" + "-" * 74)
    if remaining:
        safe = eta + timedelta(minutes=15)
        print(f" 建议关机时间: {safe.strftime('%H:%M')} 之后（留 15 分钟缓冲）")
        print(f" 一句话: 现在别关，等到 {eta.strftime('%H:%M')} 再回来看。")
    else:
        print(" 可以关机了（确认没有别的任务在跑）。")

    # ---- GPU / CPU ----
    try:
        g = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
                            "--format=csv,noheader"], capture_output=True, text=True).stdout.strip()
        print(f"\n GPU: {g}")
        load = open("/proc/loadavg").read().split()[:3]
        print(f" LOAD: {' '.join(load)}   (nproc={os.cpu_count()})")
    except Exception:
        pass

    # ---- 最近 5 条 ----
    print("\n 最近日志:")
    for t, m in ev[-5:]:
        print(f"   {t.strftime('%H:%M:%S')}  {m[:60]}")

    print("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())
