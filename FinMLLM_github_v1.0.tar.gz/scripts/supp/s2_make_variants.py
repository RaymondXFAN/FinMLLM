#!/usr/bin/env python3
# ============================================================
# FinMLLM / supp / s2_make_variants.py
# Build every adapter variant the paper needs, without a single GPU second.
# 一次都不碰 GPU，就把论文需要的所有 adapter 变体造出来。
#
# Variants / 变体:
#   energy   truncate to the k singular triplets that hold X% energy
#            按"保留 X% 能量"选 k（回应 Spectral Rank Certification 说的
#            "95% 能量不是有效秩的可靠代理" —— 我们把它实测出来）
#   rank     truncate to a fixed rank r/k  (baseline, already have some)
#            固定秩截断（已有 r/2 … r/16）
#   randdir  truncate to the same k but pick DIRECTIONS AT RANDOM
#            同样 k 但随机挑方向 —— 用来证明"按能量排序"本身有价值
#            (Eckart-Young: SVD truncation is optimal for a given rank)
#   mask     zero out the smallest |x|% of LoRA *parameters* (SeLoRA-style)
#            把 LoRA 参数里幅值最小的 x% 置零（复现 SeLoRA）
#            -> accuracy may survive, but NOT ONE BYTE IS SAVED.
#            -> 精度可能不掉，但一个字节都没省下来。这就是我们的反杀点。
#
# Author : Raymond Xiaohu Fan
# Note   : SeLoRA showed sparse masking survives. It never showed it saves disk.
#          SeLoRA 证明了稀疏剪枝不掉点，但从没证明它省硬盘。
# Updated: 2026-10-25
#
# Usage / 用法:
#   python scripts/supp/s2_make_variants.py --src ckpts_sft/fpb_r16 --kinds energy,mask,randdir
#   python scripts/supp/s2_make_variants.py --src ckpts_sft/fpb_r16 --kinds energy --energy 99,95,90,80,70,60
# ============================================================
import os, sys, json, glob, argparse, shutil, math
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from supp_common import PROJ, REP, probe, load_lora_pairs, lora_scale, singular_values, dump_json

OUT_ROOT = os.path.join(PROJ, "ckpts_supp")


def _svd_full(A, B, scale):
    """U, s, Vt of Delta-W = scale * B @ A, computed on the thin core.
    Delta-W = scale * B @ A 的 SVD，在瘦核上算。"""
    Qa, Ra = np.linalg.qr(A.T)
    Qb, Rb = np.linalg.qr(B)
    Uc, s, Vct = np.linalg.svd(Rb @ Ra.T, full_matrices=False)
    # map back:  B@A = Qb Rb Ra^T Qa^T  ->  U = Qb Uc, Vt = Vct Qa^T
    U = Qb @ Uc                 # (out, r)
    Vt = Vct @ Qa.T             # (r, in)
    return U, s * scale, Vt


def _write(adapter_dir, src_sd, cfg, new_sd, new_r, out_dir, tag):
    """Persist a rewritten adapter + its honest on-disk size.
    写出重写后的 adapter，并记录它诚实的磁盘体积。"""
    os.makedirs(out_dir, exist_ok=True)
    from safetensors.torch import save_file
    # safetensors refuses non-contiguous tensors. Fancy-indexed SVD slices
    # (U[:, idx]) hand back strided views, so pack everything here in ONE place
    # rather than remembering .contiguous() in every builder.
    # safetensors 拒绝非连续张量。花式索引的 SVD 切片 (U[:, idx]) 是跨步视图，
    # 统一在这里打包一次 —— 别指望每个构造函数都记得加 .contiguous()。
    packed = {}
    for k, v in new_sd.items():
        try:
            packed[k] = v if v.is_contiguous() else v.contiguous()
        except AttributeError:
            packed[k] = v
    save_file(packed, os.path.join(out_dir, "adapter_model.safetensors"))
    cfg2 = dict(cfg)
    cfg2["r"] = new_r
    cfg2["lora_alpha"] = new_r          # alpha=r -> scale=1, weights carry the scale
    json.dump(cfg2, open(os.path.join(out_dir, "adapter_config.json"), "w"), indent=2)
    for extra in ("tokenizer_config.json", "tokenizer.json", "special_tokens_map.json"):
        p = os.path.join(adapter_dir, extra)
        if os.path.exists(p):
            shutil.copy(p, os.path.join(out_dir, extra))
    sz = os.path.getsize(os.path.join(out_dir, "adapter_model.safetensors"))
    return sz


_TAG_OVERRIDE = None


def _tag_of(src):
    """Derive a UNIQUE tag from the source path.

    从源路径推一个唯一的 tag。
    ckpts_sft/fpb_r16  and  ckpts_sft3/fpb_r16  share the same basename, so a
    basename-only tag makes the two tasks write into the SAME directory: the
    second run either overwrites the first or is silently skipped as "existing".
    That is exactly what happened on 2026-10-25. Always include the parent.
    这两个路径的 basename 一样，只用 basename 会让两个任务写进同一个目录 ——
    第二次要么覆盖第一次，要么被当成"已存在"静默跳过。10-25 就是这么翻车的。
    永远把父目录带上。
    """
    if _TAG_OVERRIDE:
        return _TAG_OVERRIDE
    p = os.path.normpath(src)
    base = os.path.basename(p)
    parent = os.path.basename(os.path.dirname(p))
    for junk in ("ckpts_", "ckpts"):
        parent = parent.replace(junk, "")
    parent = parent.strip("_")
    return f"{parent}_{base}" if parent else base


def build_energy(src, sd, pairs, cfg, scale0, r0, energies, stamp, skip_existing=False):
    """Keep the k most energetic singular triplets, with ONE GLOBAL k.

    A LoRA adapter_config.json can only declare a single r, so every layer must
    come out the same rank. Letting each matrix pick its own k_i produces
    mismatched tensor shapes and peft refuses to load the result — that is why
    every energy variant silently failed on 2026-10-25.
    adapter_config.json 只能声明一个 r，所以每一层必须同秩。让每条矩阵各自
    挑 k_i 会导致形状不齐、peft 加载失败 —— 10-25 的 energy 变体全军覆没就是这个。

    So: compute k_i per matrix, take the MAX as the global k, then rebuild every
    matrix at that k. The realised energy retention is therefore >= the target,
    and we record the ACTUAL mean retention in the manifest.
    做法：先逐矩阵算 k_i，取最大值作为全局 k，再统一重建。因此实际能量保留
    >= 目标值，并把真实保留率写进 manifest。
    """
    import torch
    tag = _tag_of(src)
    made = []

    if skip_existing and all(
        os.path.exists(os.path.join(OUT_ROOT, f"energy_e{int(e)}_{tag}_{stamp}", "adapter_model.safetensors"))
        for e in energies):
        probe("  all energy variants exist, skip")
        return made

    # Precompute every SVD once and reuse across energy levels.
    # 每档能量复用同一批 SVD，别算六遍。
    probe(f"  precomputing {len(pairs)} SVDs ...")
    svds = []
    for kA, A, B in pairs:
        U, s, Vt = _svd_full(A, B, scale0)
        svds.append((kA, U, s, Vt))
    probe("  SVD precompute done")

    for e in energies:
        out = os.path.join(OUT_ROOT, f"energy_e{int(e)}_{tag}_{stamp}")
        if skip_existing and os.path.exists(os.path.join(out, "adapter_model.safetensors")):
            probe(f"  energy e={e}% exists, skip")
            continue

        # pass 1: k_i for each matrix, then a single global k
        ks = []
        for _, U, s, Vt in svds:
            en = s ** 2
            cum = np.cumsum(en) / (en.sum() + 1e-30)
            ks.append(max(1, min(int(np.searchsorted(cum, e / 100.0) + 1), len(s))))
        k_global = max(ks)

        new_sd = {k: v for k, v in sd.items() if "lora_A" not in k and "lora_B" not in k}
        kept, retained = 0, []
        for kA, U, s, Vt in svds:
            kB = kA.replace("lora_A", "lora_B")
            k = min(k_global, len(s))
            Bn = U[:, :k] * np.sqrt(s[:k])
            An = np.sqrt(s[:k])[:, None] * Vt[:k]
            new_sd[kA] = torch.from_numpy(np.ascontiguousarray(An, dtype=np.float32))
            new_sd[kB] = torch.from_numpy(np.ascontiguousarray(Bn, dtype=np.float32))
            en = s ** 2
            retained.append(float(en[:k].sum() / (en.sum() + 1e-30)))
            kept += 1

        sz = _write(src, sd, cfg, new_sd, k_global, out, tag)
        cr = (r0 / k_global) if k_global else float("nan")
        probe(f"  energy e={e}%  r={r0}->{k_global} (all layers)  CR={cr:.1f}x  "
              f"actual_energy={np.mean(retained)*100:.1f}%  size={sz/1024**2:.1f}MB")
        made.append({"kind": "energy", "energy_pct": e, "rank": k_global,
                     "compression_x": cr, "size_mb": sz / 1024 ** 2, "dir": out,
                     "actual_energy_mean": float(np.mean(retained)),
                     "n_matrices": kept})
    return made


def build_randdir(src, sd, pairs, cfg, scale0, r0, ks, stamp, skip_existing=False):
    """Same rank as SVD truncation, but the retained directions are RANDOM.
    与 SVD 截断同秩，但保留的方向是随机的 —— 用来隔离"能量排序"的价值。"""
    import torch
    tag = _tag_of(src)
    rng = np.random.default_rng(20261025)
    made = []
    for k in ks:
        k = max(1, min(k, r0))
        new_sd = {x: v for x, v in sd.items() if "lora_A" not in x and "lora_B" not in x}
        for kA, A, B in pairs:
            kB = kA.replace("lora_A", "lora_B")
            U, s, Vt = _svd_full(A, B, scale0)
            idx = np.sort(rng.choice(len(s), size=k, replace=False))
            Bn = U[:, idx] * np.sqrt(s[idx])
            An = np.sqrt(s[idx])[:, None] * Vt[idx]
            new_sd[kA] = torch.from_numpy(np.ascontiguousarray(An, dtype=np.float32))
            new_sd[kB] = torch.from_numpy(np.ascontiguousarray(Bn, dtype=np.float32))
        out = os.path.join(OUT_ROOT, f"randdir_r{k}_{tag}_{stamp}")
        if skip_existing and os.path.exists(os.path.join(out, "adapter_model.safetensors")):
            probe(f"  randdir r={k} exists, skip")
            continue
        sz = _write(src, sd, cfg, new_sd, k, out, tag)
        probe(f"  randdir r={k}  size={sz/1024**2:.1f}MB -> {out}")
        made.append({"kind": "randdir", "rank": k, "compression_x": r0 / k,
                     "size_mb": sz / 1024 ** 2, "dir": out, "n_matrices": len(pairs)})
    return made


def build_mask(src, sd, pairs, cfg, scale0, r0, pcts, stamp, skip_existing=False):
    """Zero the smallest-magnitude p% of LoRA *parameters*. Shape never changes.
    把幅值最小的 p% LoRA 参数置零。形状不变 —— 所以体积一分都不省。"""
    import torch
    tag = _tag_of(src)
    orig_bytes = sum(v.numel() * v.element_size() for v in sd.values())
    made = []
    for p in pcts:
        new_sd = dict(sd)          # shallow copy: we replace selected tensors below
        nnz, total = 0, 0
        for kA, A, B in pairs:
            kB = kA.replace("lora_A", "lora_B")
            for key, T in ((kA, A), (kB, B)):
                t = torch.from_numpy(np.ascontiguousarray(T))
                flat = t.abs().flatten()
                n_zero = int(round(flat.numel() * p / 100.0))
                if n_zero > 0:
                    thr = torch.kthvalue(flat, max(1, n_zero)).values
                    t = torch.where(t.abs() <= thr, torch.zeros_like(t), t)
                new_sd[key] = t
                total += t.numel()
                nnz += int(torch.count_nonzero(t).item())
        out = os.path.join(OUT_ROOT, f"mask{int(p)}_{tag}_{stamp}")
        if skip_existing and os.path.exists(os.path.join(out, "adapter_model.safetensors")):
            probe(f"  mask {p}% exists, skip")
            continue
        sz = _write(src, sd, cfg, new_sd, r0, out, tag)   # rank unchanged / 秩不变
        # honest sparse-storage estimate: 2-byte value + 4-byte index per non-zero
        # 诚实的稀疏存储估算：每个非零 2 字节值 + 4 字节索引
        sparse_bytes = nnz * 6
        probe(f"  mask {p}%  dense={sz/1024**2:.1f}MB (unchanged)  "
              f"if stored sparse: {sparse_bytes/1024**2:.1f}MB "
              f"({sparse_bytes/ (sz or 1):.2f}x of dense)")
        made.append({"kind": "mask", "mask_pct": p, "rank": r0, "compression_x": 1.0,
                     "size_mb": sz / 1024 ** 2,
                     "nnz": nnz, "total_params": total,
                     "sparsity": 1.0 - nnz / max(total, 1),
                     "sparse_est_mb": sparse_bytes / 1024 ** 2,
                     "sparse_vs_dense_ratio": sparse_bytes / max(sz, 1),
                     "dir": out, "n_matrices": len(pairs)})
    return made


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--kinds", default="energy",
                    help="comma list of energy,randdir,mask / 逗号分隔")
    ap.add_argument("--energy", default="99,95,90,80,70,60")
    ap.add_argument("--ranks", default="", help="for randdir, e.g. 8,4,2,1")
    ap.add_argument("--mask-pcts", default="40,60,80")
    ap.add_argument("--stamp", default=os.environ.get("STAMP", "20261025"))
    ap.add_argument("--tag", default=None,
                    help="force the variant tag / 强制指定变体目录后缀")
    ap.add_argument("--skip-existing", action="store_true",
                    help="skip variant dirs that already exist / 跳过已存在的变体目录")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    probe("=" * 78)
    probe(f"BUILD VARIANTS  src={args.src}  kinds={args.kinds}  stamp={args.stamp}")
    probe("=" * 78)

    from safetensors.torch import load_file
    files = glob.glob(os.path.join(args.src, "*.safetensors"))
    if not files:
        probe("no safetensors found", "FATAL")
        return 2
    sd = load_file(files[0])
    cfg, pairs = load_lora_pairs(args.src)
    scale0, r0 = lora_scale(cfg)
    probe(f"r0={r0} scale0={scale0:.3f} matrices={len(pairs)}")

    global _TAG_OVERRIDE
    _TAG_OVERRIDE = args.tag
    tag = _tag_of(args.src)
    probe(f"variant tag = {tag}")
    kinds = [k.strip() for k in args.kinds.split(",") if k.strip()]
    made = []

    if "energy" in kinds:
        es = [float(x) for x in args.energy.split(",") if x.strip()]
        probe(f"-- energy variants: {es}")
        made += build_energy(args.src, sd, pairs, cfg, scale0, r0, es, args.stamp, args.skip_existing)
    if "randdir" in kinds:
        ks = [int(x) for x in args.ranks.split(",") if x.strip()] or [8, 4, 2, 1]
        probe(f"-- random-direction variants at ranks {ks}")
        made += build_randdir(args.src, sd, pairs, cfg, scale0, r0, ks, args.stamp, args.skip_existing)
    if "mask" in kinds:
        ps = [float(x) for x in args.mask_pcts.split(",") if x.strip()]
        probe(f"-- parameter-mask variants at {ps}%")
        made += build_mask(args.src, sd, pairs, cfg, scale0, r0, ps, args.stamp, args.skip_existing)

    out = args.out or os.path.join(REP, f"variants_{tag}_{args.stamp}.json")
    dump_json({"src": args.src, "rank_cfg": r0, "stamp": args.stamp, "variants": made}, out)

    print()
    print("=" * 92)
    print(f"{'kind':<10}{'param':>8}{'rank':>6}{'CR':>7}{'size_MB':>10}{'notes':>28}")
    print("-" * 92)
    for v in made:
        note = ""
        if v["kind"] == "energy":
            note = f"keeps {v['energy_pct']:.0f}% energy"
        elif v["kind"] == "mask":
            note = f"sparsity {v['sparsity']*100:.0f}%, sparse_est {v['sparse_est_mb']:.1f}MB"
        elif v["kind"] == "randdir":
            note = "random directions"
        p = v.get("energy_pct") or v.get("mask_pct") or v.get("rank")
        print(f"{v['kind']:<10}{p:>8}{v['rank']:>6}{v['compression_x']:>7.1f}"
              f"{v['size_mb']:>10.1f}{note:>28}")
    print("-" * 92)
    probe(f"BUILD DONE  {len(made)} variants", "OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
