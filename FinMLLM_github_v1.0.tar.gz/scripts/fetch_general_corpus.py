#!/usr/bin/env python3
# ============================================================
# FinMLLM / fetch_general_corpus.py
# Get a genuinely NON-financial corpus (wikitext-2) to build an honest
# "general domain" control adapter.
# 下载真正"非金融"的通用语料（wikitext-2），用于训练诚实的通用域对照。
#
# Author : Raymond Xiaohu Fan
# Note   : Comparing finance to financial news is not a control, it is a mirror.
#          拿金融新闻当"通用"对照，那不是对照，那是照镜子。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/fetch_general_corpus.py
# ============================================================
import os, json, urllib.request

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
OUT = os.path.join(ROOT, "data", "unified")
RAW = os.path.join(ROOT, "data", "raw", "general")
os.makedirs(OUT, exist_ok=True); os.makedirs(RAW, exist_ok=True)

# Multiple mirrors: pytorch examples, then a HuggingFace raw copy.
# 多个镜像：先试 pytorch 官方示例，再试 HF raw 副本。
URLS = [
    "https://raw.githubusercontent.com/pytorch/examples/main/word_language_model/data/wikitext-2/train.txt",
    "https://raw.githubusercontent.com/pytorch/examples/master/word_language_model/data/wikitext-2/train.txt",
]
DEST = os.path.join(RAW, "wikitext2_train.txt")


def download():
    if os.path.exists(DEST) and os.path.getsize(DEST) > 1_000_000:
        print(f"  ✅ already present: {DEST} ({os.path.getsize(DEST)/1024**2:.1f} MB)")
        return True
    for u in URLS:
        try:
            print(f"  → {u}")
            urllib.request.urlretrieve(u, DEST)
            sz = os.path.getsize(DEST)
            if sz > 1_000_000:
                print(f"  ✅ downloaded {sz/1024**2:.1f} MB")
                return True
        except Exception as e:
            print(f"  ❌ {type(e).__name__}: {e}")
    return False


def chunk_to_jsonl():
    if not os.path.exists(DEST):
        return 0
    text = open(DEST, encoding="utf-8", errors="ignore").read()
    # wikitext uses blank lines between articles; keep paragraph-level chunks.
    # wikitext 用空行分隔文章，这里按段落切块。
    paras = [p.strip() for p in text.split("\n\n") if len(p.strip()) > 300]
    rows = []
    for p in paras:
        for i in range(0, max(1, len(p) - 200), 1300):
            piece = p[i:i + 1500].strip()
            if len(piece) < 300:
                continue
            rows.append({"id": f"gen-{len(rows)}", "text": piece,
                         "domain": "general_real", "source": "wikitext2", "split": "train"})
    out = os.path.join(OUT, "general_real.jsonl")
    with open(out, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  ✅ {len(rows)} chunks -> {out}")
    return len(rows)


if __name__ == "__main__":
    print("=" * 66)
    print(" GENERAL CORPUS / 通用语料（wikitext-2）")
    print("=" * 66)
    ok = download()
    n = chunk_to_jsonl() if ok else 0
    if n:
        print("\nNext / 下一步:")
        print("  python scripts/train_domain.py --domain general_real \\")
        print("    --data_file data/unified/general_real.jsonl --limit 4000")
    else:
        print("\n❌ 下载失败。手动放一份文本到 data/raw/general/wikitext2_train.txt 后重跑。")
