#!/usr/bin/env python3
# FinMLLM / rv_summarize.py
# 读 rv_full/ 下的逐样本预测，配对算 McNemar + TOST 等效性。
# Paired McNemar + TOST equivalence on per-item predictions.
# Author: Raymond Xiaohu Fan
import os, sys, json, glob, argparse
from collections import defaultdict

def mcnemar_exact(b, c):
    from scipy.stats import binomtest
    n = b + c
    return 1.0 if n == 0 else float(binomtest(min(b, c), n, 0.5, alternative="two-sided").pvalue)

def tost(b, c, n, margin=1.0):
    import math
    from scipy.stats import norm
    if n == 0: return None
    diff = (b - c) / n * 100.0
    se = math.sqrt(max((b + c) / (n * n) * 10000.0, 1e-12))
    lo, hi = diff - norm.ppf(0.95) * se, diff + norm.ppf(0.95) * se
    p1 = 1 - norm.cdf((margin - diff) / se)
    p2 = norm.cdf((-margin - diff) / se)
    return dict(diff=diff, lo=lo, hi=hi, eq=(p1 < 0.05 and p2 < 0.05), p=max(p1, p2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="outputs/reports/rv_full")
    ap.add_argument("--margin", type=float, default=1.0)
    a = ap.parse_args()

    runs = {}
    for f in sorted(glob.glob(os.path.join(a.dir, "*.json"))):
        if os.path.basename(f).startswith("_"): continue
        d = json.load(open(f, encoding="utf-8"))
        if "preds" not in d:
            print(f"skip (no preds): {os.path.basename(f)}"); continue
        runs[os.path.basename(f)[:-5]] = d
    if not runs:
        print("no runs"); return 2

    print("="*92); print(f" loaded {len(runs)} runs"); print("="*92)

    groups = defaultdict(dict)
    for tag, d in runs.items():
        p = tag.split("_")
        task = p[0]
        seed = next((x[1:] for x in p if x.startswith("s") and x[1:].isdigit()), "42")
        rank = next((x[1:] for x in p if x.startswith("r") and x[1:].isdigit()), None)
        if rank is None: continue
        groups[(task, seed)][int(rank)] = d

    print(f"\n{'task':<5} {'seed':<6} {'rank':<5} {'n':<7} {'acc':<9}")
    print("-"*92)
    for (task, seed), ranks in sorted(groups.items()):
        for rk in sorted(ranks, reverse=True):
            d = ranks[rk]
            print(f"{task:<5} {seed:<6} {rk:<5} {d['n']:<7} {d['accuracy']:.4f}")

    print("\n"+"="*92)
    print(f" paired McNemar vs largest rank | equivalence margin +/-{a.margin}pp")
    print("="*92)
    print(f"{'task':<5} {'seed':<6} {'pair':<14} {'n':<7} {'b':<5} {'c':<5} {'delta':<9} {'p':<10} {'equiv'}")
    print("-"*92)
    rows = []
    for (task, seed), ranks in sorted(groups.items()):
        if len(ranks) < 2: continue
        base_r = max(ranks)
        bm = {p["i"]: p for p in ranks[base_r]["preds"]}
        for rk in sorted(ranks, reverse=True):
            if rk == base_r: continue
            cm = {p["i"]: p for p in ranks[rk]["preds"]}
            if set(bm) != set(cm):
                print(f"!! {task} s{seed} r{base_r} vs r{rk}: index mismatch"); continue
            b = sum(1 for i in bm if bm[i]["ok"] == 0 and cm[i]["ok"] == 1)
            c = sum(1 for i in bm if bm[i]["ok"] == 1 and cm[i]["ok"] == 0)
            n = len(bm)
            p = mcnemar_exact(b, c); t = tost(b, c, n, a.margin)
            d = (b - c) / n * 100.0 if n else 0.0
            star = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else "n.s."
            print(f"{task:<5} {seed:<6} r{base_r}->r{rk:<7} {n:<7} {b:<5} {c:<5} "
                  f"{d:+8.2f}  {p:<10.4f} {star:<4} {'YES' if t and t['eq'] else 'no'}")
            rows.append(dict(task=task, seed=seed, base_rank=base_r, rank=rk, n=n, b=b, c=c,
                             delta_pp=d, p=p, tost_p=t["p"] if t else None,
                             equivalent=bool(t and t["eq"])))

    out = os.path.join(a.dir, "_summary.json")
    json.dump(rows, open(out, "w"), indent=2, ensure_ascii=False)
    print(f"\n saved -> {out}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
