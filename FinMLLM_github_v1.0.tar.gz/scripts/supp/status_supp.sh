#!/usr/bin/env bash
# ============================================================
# FinMLLM / supp / status_supp.sh
# One screen that tells you whether to go to bed or to panic.
# 一屏看完，决定是去睡觉还是去救火。
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-10-25
# Usage / 用法:  bash scripts/supp/status_supp.sh
# ============================================================
set -uo pipefail
PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
cd "$PROJ" 2>/dev/null || { echo "FATAL: $PROJ"; exit 1; }
LOGD="outputs/logs/supp"

line() { printf '%s\n' "------------------------------------------------------------"; }
head1() { echo; printf '\033[1;36m== %s ==\033[0m\n' "$*"; }

echo "============================================================"
echo " FinMLLM SUPPLEMENTARY SUITE — STATUS   $(date '+%F %T')"
echo "============================================================"

head1 "1. GPU"
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu,temperature.gpu \
             --format=csv,noheader
  echo
  echo " processes on GPU / 占卡进程:"
  nvidia-smi --query-compute-apps=pid,used_memory,process_name --format=csv,noheader 2>/dev/null \
    | sed 's/^/   /' || echo "   (none)"
else
  echo " nvidia-smi not available"
fi

head1 "2. RUNNING PROCESSES"
P=$(pgrep -fa "run_supp|s3_gpu_queue|train_sft|eval_cloze|s1_rank_metrics|s2_make_variants|s4_summarize" 2>/dev/null | grep -v pgrep || true)
if [ -z "$P" ]; then echo " (nothing running)"; else echo "$P" | sed 's/^/   /'; fi

head1 "3. STAGE PROGRESS (log tails)"
for f in run_supp_*.log cpu_line.log cpu_rank_metrics.log cpu_variants_bin.log \
         cpu_variants_tri.log gpu_queue.log summarize.log; do
  F=$(ls -t $LOGD/$f 2>/dev/null | head -1)
  [ -z "${F:-}" ] && continue
  echo " · $(basename "$F")   ($(date -r "$F" '+%H:%M:%S'))"
  tail -n 4 "$F" | sed 's/^/     /'
  line
done

head1 "4. JOB RESULTS (per-job logs)"
if ls $LOGD/r64_*.log $LOGD/eval_*.log >/dev/null 2>&1; then
  printf "   %-46s %s\n" "JOB" "RESULT"
  for f in $LOGD/r64_*.log $LOGD/eval_*.log; do
    b=$(basename "$f" .log)
    if grep -q "EXIT  rc=0" "$f" 2>/dev/null || grep -q "EXIT rc=0" "$f" 2>/dev/null; then r="✅ done"
    elif grep -q "EXIT" "$f" 2>/dev/null; then r="❌ FAILED"
    else r="⏳ running/pending"; fi
    printf "   %-46s %s\n" "$b" "$r"
  done
else
  echo "   (no per-job logs yet)"
fi

head1 "5. ARTEFACTS"
printf "   %-34s %s\n" "adapters in ckpts_supp/" "$(ls -d ckpts_supp/*/ 2>/dev/null | wc -l)"
printf "   %-34s %s\n" "rank-metric reports"      "$(ls outputs/reports/supp_rank_metrics_*.json 2>/dev/null | wc -l)"
printf "   %-34s %s\n" "variant manifests"         "$(ls outputs/reports/variants_*.json 2>/dev/null | wc -l)"
printf "   %-34s %s\n" "eval jsons"                "$(ls outputs/reports/eval_*.json 2>/dev/null | wc -l)"
printf "   %-34s %s\n" "summary dirs"              "$(ls -d outputs/supp_*/ 2>/dev/null | wc -l)"
LAST=$(ls -dt outputs/supp_*/ 2>/dev/null | head -1)
[ -n "${LAST:-}" ] && echo "   latest summary: $LAST"

head1 "6. ERRORS (if any)"
ERR=$(grep -l -E "Traceback|CUDA out of memory|FATAL|EXIT  rc=[1-9]" $LOGD/*.log 2>/dev/null || true)
if [ -z "$ERR" ]; then echo " ✅ no errors detected"; else
  for f in $ERR; do
    echo " ❌ $(basename "$f")"
    grep -E "Traceback|Error|out of memory|FATAL" "$f" | tail -3 | sed 's/^/      /'
  done
fi

echo
echo "============================================================"
echo " tail -f $PROJ/$LOGD/run_supp_*.log   # follow the master log"
echo "============================================================"
