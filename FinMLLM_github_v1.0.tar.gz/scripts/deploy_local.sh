#!/usr/bin/env bash
# ============================================================
# FinMLLM / deploy_local.sh
# Local Mac side: download, verify, unpack, upload to the GPU box.
# 本地 Mac 端：下载、校验、解压、上传到 GPU 服务器。
#
# Author : Raymond Xiaohu Fan
# Note   : One command from laptop to GPU box — that's the dream. / 一条命令从笔记本到 GPU 机器，这才叫舒服。
# Updated: 2026-10-19
# ============================================================

# ============================================================
# 在【本地 Mac】执行：下载 ima 包 -> 解压校验 -> 上传服务器
# 用法：
#   bash deploy_local.sh "<ima下载地址>" <host> <端口>
# 例：
#   bash deploy_local.sh "https://ima.qq.com/short_url?id=xxx" connect.cqa1.seetacloud.com 43864
# ============================================================
set -euo pipefail

URL="${1:?用法: bash deploy_local.sh <下载地址> <host> <端口>}"
HOST="${2:?缺少服务器 host}"
PORT="${3:?缺少 SSH 端口}"

WORK="$HOME/FinMLLM_deploy"
PKG="FinMLLM_v1.3.tar.gz"

echo "=== [1/5] 准备本地目录 ==="
if [ -d "$WORK" ]; then
  BAK="${WORK}.bak.$(date +%Y%m%d_%H%M%S)"
  mv "$WORK" "$BAK"
  echo "⚠️ 已存在旧目录，已备份到：$BAK"
fi
mkdir -p "$WORK"
cd "$WORK"

echo "=== [2/5] 下载 ==="
curl -fL --retry 3 -o "$PKG" "$URL"
ls -lh "$PKG"

echo "=== [3/5] 完整性校验（先列目录，坏包会在这里报错） ==="
tar -tzf "$PKG" | head -30
COUNT=$(tar -tzf "$PKG" | wc -l | tr -d ' ')
echo "包内条目数：$COUNT（预期 > 20）"
[ "$COUNT" -gt 20 ] || { echo "❌ 包不完整，停止"; exit 1; }

echo "=== [4/5] 本地解压 ==="
tar -xzf "$PKG"
ls -la "$WORK/FinMLLM" | head -20

echo "=== [5/5] 上传到服务器 ==="
scp -P "$PORT" -r "$WORK/FinMLLM" "root@${HOST}:/root/autodl-tmp/"
scp -P "$PORT" "$WORK/$PKG" "root@${HOST}:/root/autodl-tmp/"

echo ""
echo "🎉 本地部署完成！"
echo "下一步（登录服务器执行）："
echo "  ssh -p $PORT root@$HOST"
echo "  cd /root/autodl-tmp/FinMLLM && bash scripts/deploy_remote.sh && bash scripts/init_forks.sh"
