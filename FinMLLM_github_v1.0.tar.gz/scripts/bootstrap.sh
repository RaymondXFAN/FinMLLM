#!/usr/bin/env bash
# ============================================================
# FinMLLM / bootstrap.sh
# Bootstrap the project layout, shared symlinks and env file.
# 建立项目目录、共享软链与环境变量文件。
#
# Author : Raymond Xiaohu Fan
# Note   : Set it up once, set it up right. / 一次搭好，后面省心。
# Updated: 2026-10-19
# ============================================================

# FinMLLM 无卡模式 bootstrap：建目录 + 软链共享旧资产 + 环境自检
# 用法： bash scripts/bootstrap.sh
set -euo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
OLD_CODE="${OLD_CODE:-/root/FinMeshingLLM/MeshingLLM/code}"
HF_HOME_DIR="${HF_HOME_DIR:-/root/autodl-tmp/hf_home}"

echo "=== [1/5] 检查磁盘与路径 ==="
df -h /root/autodl-tmp 2>/dev/null | tail -1 || echo "⚠️ 未发现 /root/autodl-tmp，请确认数据盘挂载"
mkdir -p "$PROJ"/{code,data,ckpts,outputs/{tables,figs,logs},shared,scripts/gates,configs}
echo "✅ 项目根目录：$PROJ"

echo "=== [2/5] 软链共享旧资产（只读，不复制） ==="
if [ -d "$HF_HOME_DIR" ]; then
  ln -sfn "$HF_HOME_DIR" "$PROJ/shared/hf_home"
  echo "✅ HF_HOME -> $HF_HOME_DIR"
else
  echo "⚠️ 未找到 $HF_HOME_DIR（模型缓存），稍后由下载脚本创建"
  mkdir -p "$PROJ/shared/hf_home"
fi

# 复用旧 FinEval（若存在）
for cand in "/root/FinMeshingLLM/MeshingLLM/data/FinEval" \
            "/root/autodl-tmp/MeshingLLM/data/FinEval" \
            "$HF_HOME_DIR/hub/datasets--SUFE-AIFLM-Lab--FinEval"; do
  if [ -d "$cand" ]; then
    ln -sfn "$cand" "$PROJ/shared/FinEval"
    echo "✅ FinEval -> $cand"
    break
  fi
done

echo "=== [3/5] 复用旧代码内核（复制，因为要改） ==="
if [ -f "$OLD_CODE/meshing.py" ]; then
  mkdir -p "$PROJ/code/legacy"
  cp -n "$OLD_CODE/meshing.py" "$PROJ/code/legacy/meshing_v1.py" || true
  echo "✅ 已复制 legacy/meshing_v1.py（会议版内核，作为对照基准）"
else
  echo "⚠️ 未找到旧 meshing.py（$OLD_CODE），跳过；后续需手动放置"
fi

echo "=== [4/5] 环境检查 ==="
python - <<'PY'
import sys, importlib, os
print("Python:", sys.version.split()[0])
need = ["torch","transformers","peft","datasets","accelerate","bitsandbytes","scipy","numpy","pandas","sklearn","yaml"]
for m in need:
    try:
        mod = importlib.import_module(m)
        print(f"  ✅ {m:<14}{getattr(mod,'__version__','?')}")
    except Exception as e:
        print(f"  ❌ {m:<14}MISSING ({type(e).__name__})")
try:
    import torch
    print("CUDA available:", torch.cuda.is_available(),
          "| device_count:", torch.cuda.device_count())
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0),
              "| VRAM(GB):", round(torch.cuda.get_device_properties(0).total_memory/1024**3,1))
except Exception:
    pass
PY

echo "=== [5/5] 环境变量建议（写入 ~/.bashrc_FinMLLM，手动 source） ==="
cat > "$PROJ/setup_env.sh" <<EOF
export PROJ=$PROJ
export HF_HOME=$PROJ/shared/hf_home
export HF_ENDPOINT=https://hf-mirror.com
export TRANSFORMERS_CACHE=\$HF_HOME/hub
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
EOF
echo "✅ 已生成 $PROJ/setup_env.sh  →  执行: source $PROJ/setup_env.sh"
echo ""
if [ -f scripts/init_forks.sh ]; then bash scripts/init_forks.sh; fi
echo ""
echo "🎉 bootstrap 完成。下一步：bash scripts/download_data.sh"
