# docs

| File | Contents |
|---|---|
| `ERRATA.md` | 25 documented defects. Each entry gives the symptom, the root cause, the fix and the lesson. Start here to see where this pipeline can break. |
| `RESULTS_SUMMARY.md` | Complete experimental record: every condition, every seed, every control, including results that did not make it into the paper. |
| `LITERATURE_VERIFICATION.md` | Verification log for the cited literature: 40 references checked against publisher records, with the seven metadata errors found and corrected. |

Manuscripts and figures are intentionally **not** part of this repository.
Build scripts that generate them live in `scripts/manuscript/`.
