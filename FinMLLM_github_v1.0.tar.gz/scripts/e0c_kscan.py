#!/usr/bin/env python3
# ============================================================
# FinMLLM / e0c_kscan.py
# E0c — sweep the retention ratio k to find the scale where (if anywhere)
# a domain-specific spectral direction exists. Fast by design.
# E0c —— 扫描保留比例 k，找出（若存在）域特异谱方向所在的尺度。为速度而设计。
#
# Author : Raymond Xiaohu Fan
# Note   : If a signal only shows at k=0.1%, that is still a signal worth reporting.
#          信号只在 k=0.1% 出现也算信号，值得写进论文。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/e0c_kscan.py --ckpt_dir ckpts --layers 16 --size 512
# ============================================================
import os, sys, json, glob, argparse, itertools
import numpy as np
from scipy.fftpack import dct

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)


def dct2(x):
    return dct(dct(x.T, norm="ortho").T, norm="ortho")


def load_deltas(adapter_dir, max_layers=16, size=512):
    """Load Delta-W, center-crop to `size` for speed. / 读取并中心裁切加速。"""
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files:
        return []
    sd = load_file(files[0])
    keys = [k for k in sd if "lora_A" in k]
    out = []
    for k in sorted(keys)[:max_layers]:
        kb = k.replace("lora_A", "lora_B")
        if kb not in sd:
            continue
        A = sd[k].float().cpu().numpy(); B = sd[kb].float().cpu().numpy()
        W = B @ A
        h, w = W.shape
        sh, sw = min(h, size), min(w, size)
        i0, j0 = (h - sh) // 2, (w - sw) // 2
        out.append(W[i0:i0 + sh, j0:j0 + sw])
    return out


def topk_coords(W, k_pct):
    C = dct2(W)
    E = C ** 2
    flat = E.ravel()
    k = max(1, int(flat.size * k_pct / 100.0))
    idx = np.argpartition(flat, -k)[-k:]
    return set(idx.tolist())


def jac(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0


def jmatrix(coords):
    n = len(coords)
    J = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        for j in range(i + 1, n):
            v = jac(coords[i], coords[j])
            J[i, j] = J[j, i] = v
    return J


def intra_mean(J, groups):
    vals = []
    for idx in groups:
        if len(idx) < 2:
            continue
        sub = J[np.ix_(idx, idx)]
        iu = np.triu_indices(len(idx), 1)
        vals.append(sub[iu].mean())
    return float(np.mean(vals)) if vals else 0.0


def inter_mean(J, groups):
    vals = []
    for a, b in itertools.combinations(range(len(groups)), 2):
        sub = J[np.ix_(groups[a], groups[b])]
        vals.append(sub.mean())
    return float(np.mean(vals)) if vals else 0.0


def perm_p(J, groups, observed, n_perm=500, seed=0):
    rng = np.random.RandomState(seed)
    n = J.shape[0]
    labels = np.zeros(n, dtype=np.int32)
    pos = 0
    for gi, idx in enumerate(groups):
        labels[pos:pos + len(idx)] = gi
        pos += len(idx)

    def mi(lab):
        vals = []
        for gi in range(len(groups)):
            sel = np.where(lab == gi)[0]
            if len(sel) < 2:
                continue
            sub = J[np.ix_(sel, sel)]
            iu = np.triu_indices(len(sel), 1)
            vals.append(sub[iu].mean())
        return float(np.mean(vals)) if vals else 0.0

    cnt = 0
    for _ in range(n_perm):
        rng.shuffle(labels)
        if mi(labels) >= observed:
            cnt += 1
    return cnt / n_perm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_dir", default=os.path.join(ROOT, "ckpts"))
    ap.add_argument("--layers", type=int, default=16)
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--ks", default="0.1,0.5,1,2,5,10")
    ap.add_argument("--perm", type=int, default=500)
    args = ap.parse_args()

    ks = [float(x) for x in args.ks.split(",")]
    print("=" * 88)
    print(" E0c · k-SCAN FOR DOMAIN SPECTRAL IDENTITY / 域谱身份的 k 扫描")
    print(f" layers={args.layers}  matrix={args.size}x{args.size}  perm={args.perm}")
    print("=" * 88)

    domains = {}
    for d in sorted(glob.glob(os.path.join(args.ckpt_dir, "*_qlora*"))):
        name = os.path.basename(d).split("_qlora")[0]
        ws = load_deltas(d, args.layers, args.size)
        if ws:
            domains[name] = ws
            print(f"  ✅ {name:<16}{len(ws)} layers")
    if len(domains) < 2:
        print("❌ 至少需要 2 个 adapter")
        return 2

    names = list(domains)
    print(f"\n{'k%':>6}{'J_intra':>10}{'J_inter':>10}{'delta':>10}{'perm_p':>9}  verdict")
    print("-" * 88)

    rows = []
    for k in ks:
        coords = {n: [topk_coords(W, k) for W in ws] for n, ws in domains.items()}
        flat, groups, pos = [], [], 0
        for n in names:
            m = len(coords[n])
            groups.append(list(range(pos, pos + m)))
            flat.extend(coords[n]); pos += m
        J = jmatrix(flat)
        ji = intra_mean(J, groups)
        je = inter_mean(J, groups)
        p = perm_p(J, groups, ji, args.perm)
        delta = ji - je
        verdict = "🎯 有信号" if (delta > 0.01 and p < 0.05) else "无"
        print(f"{k:>6.1f}{ji:>10.4f}{je:>10.4f}{delta:>+10.4f}{p:>9.3f}  {verdict}")
        rows.append({"k": k, "J_intra": ji, "J_inter": je, "delta": delta, "p": p})

    best = max(rows, key=lambda r: r["delta"])
    print("-" * 88)
    print(f"最佳 k = {best['k']}%   delta = {best['delta']:+.4f}   p = {best['p']:.3f}")

    signal = any(r["delta"] > 0.01 and r["p"] < 0.05 for r in rows)
    print("\n" + "=" * 88)
    if signal:
        print(" 🎯 至少在某个尺度上存在域谱身份 → 值得继续（Fork A/B）")
        print("    下一步：在该 k 上做完整 E0b（含随机低秩对照）并写入论文")
    else:
        print(" ⚠️  全部 k 均无域谱身份")
        print("    → 这已是第三次独立测量，建议认定 H0 不成立，转 Fork D")
        print("    → Fork D 选题：'低秩约束下频域指标无法刻画领域特性' 的方法学否定性发现")
    print("=" * 88)

    path = os.path.join(REP, "e0c_kscan.json")
    json.dump({"layers": args.layers, "size": args.size, "rows": rows, "signal": bool(signal)},
              open(path, "w"), indent=2, ensure_ascii=False)
    print(f"💾 saved -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
