#!/usr/bin/env python3
# ============================================================
# FinMLLM / fetch_edgar_sec.py
# Pull 10-K filings straight from the official SEC EDGAR API for a curated
# list of banks, insurers and brokerages. Public data, no HuggingFace needed.
# 直接从 SEC EDGAR 官方 API 抓 10-K，覆盖银行 / 保险 / 证券三类机构。
# 全部是公开数据，不依赖 HuggingFace。
#
# Author : Raymond Xiaohu Fan
# Note   : The SEC asks for a real email in the User-Agent. Be a good citizen.
#          SEC 要求 User-Agent 里带真实邮箱，做个守规矩的爬虫。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/fetch_edgar_sec.py --email you@example.com --years 3
#   python scripts/fetch_edgar_sec.py --email you@example.com --only insurance
# ============================================================
import os, sys, json, re, html, time, argparse, pathlib
import urllib.request

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
OUT = os.path.join(ROOT, "data", "raw", "edgar_sec")

# Curated, hand-checked tickers. / 手工挑选、已核对的 ticker。
TICKERS = {
    "bank":       ["JPM", "BAC", "WFC", "C", "USB"],
    "insurance":  ["AIG", "MET", "PRU", "ALL", "PGR"],
    "securities": ["GS", "MS", "SCHW", "BLK", "COF"],
}

UA_TMPL = "FinMLLM academic research {email}"


def http_get(url, ua, binary=False, retries=3, timeout=60):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept-Encoding": "gzip, deflate"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    import gzip
                    data = gzip.decompress(data)
                return data if binary else data.decode("utf-8", errors="ignore")
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(1.5 * (i + 1))


def strip_html(raw):
    """Crude but dependency-free HTML -> text.
    不依赖第三方库的 HTML 转文本（够用就行）。"""
    raw = re.sub(r"<script.*?</script>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<style.*?</style>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    raw = re.sub(r"[ \t\xa0]+", " ", raw)
    raw = re.sub(r"\n\s*\n+", "\n", raw)
    return raw.strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--email", required=True, help="your email for the SEC User-Agent / SEC 要求填邮箱")
    ap.add_argument("--years", type=int, default=3, help="how many recent 10-K per company / 每家取几份")
    ap.add_argument("--only", default=None, choices=list(TICKERS), help="only one business line / 只抓一类")
    args = ap.parse_args()

    ua = UA_TMPL.format(email=args.email)
    print("=" * 70)
    print(f" SEC EDGAR 10-K fetcher | UA={ua}")
    print(f" out={OUT}  years={args.years}")
    print("=" * 70)

    # 1) ticker -> CIK
    print("[1/3] loading ticker->CIK map ...")
    tickers_raw = json.loads(http_get("https://www.sec.gov/files/company_tickers.json", ua))
    t2cik = {v["ticker"].upper(): int(v["cik_str"]) for v in tickers_raw.values()}
    print(f"      {len(t2cik)} tickers indexed")

    targets = {k: v for k, v in TICKERS.items() if (args.only is None or k == args.only)}
    total = 0
    for domain, tickers in targets.items():
        print(f"\n[2/3] {domain}")
        for t in tickers:
            cik = t2cik.get(t)
            if not cik:
                print(f"  ⚠️  {t}: CIK not found")
                continue
            dest = pathlib.Path(OUT) / t
            dest.mkdir(parents=True, exist_ok=True)
            try:
                sub = json.loads(http_get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", ua))
            except Exception as e:
                print(f"  ❌ {t}: submissions failed ({type(e).__name__})")
                continue
            recent = sub.get("filings", {}).get("recent", {})
            forms = recent.get("form", [])
            accs = recent.get("accessionNumber", [])
            docs = recent.get("primaryDocument", [])
            dates = recent.get("filingDate", [])
            picked = [(a, d, dt) for f, a, d, dt in zip(forms, accs, docs, dates) if f == "10-K"][: args.years]
            print(f"  {t} (CIK {cik}): {len(picked)} 10-K to fetch")
            for acc, doc, dt in picked:
                out_file = dest / f"{dt}_10-K.md"
                if out_file.exists() and out_file.stat().st_size > 1000:
                    print(f"     ⏭️  {out_file.name} exists")
                    continue
                url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}/{doc}"
                try:
                    raw = http_get(url, ua, timeout=120)
                    txt = strip_html(raw)
                    out_file.write_text(txt, encoding="utf-8")
                    print(f"     ✅ {out_file.name}  {len(txt)/1024:.0f} KB")
                    total += 1
                except Exception as e:
                    print(f"     ❌ {out_file.name}: {type(e).__name__}")
                time.sleep(0.2)   # be polite to the SEC / 对 SEC 客气点

    print(f"\n[3/3] done. {total} new filings -> {OUT}")
    print("Next / 下一步: python scripts/prep_raw.py   (it will pick up edgar_sec automatically)")


if __name__ == "__main__":
    main()
