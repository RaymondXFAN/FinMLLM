#!/usr/bin/env python3
# ============================================================
# FinMLLM / verify_fiqa_transfer.py
# 复核论文 §4.6 的跨域迁移三个数（ERRATA E-26 第 ① 项）。
# Re-derive the three cross-domain transfer numbers in §4.6.
#
# 为什么这三个数要单独复核：
#   论文写：零样本 0.2428 → +FPB r16 = 0.6749 → +FPB r1 = 0.6543（Δ=+2.06pp, p=0.2668）
#   我在服务器 outputs/reports/ 下 grep 了全部 json，一个都找不到 ——
#   这是早期实验，结果没落盘。也就是说：论文里有三个数字是"孤证"，没有原始文件。
#   这个脚本就是把它们重新跑出来，让它们有据可查。
#
# 三个条件（串行，都评 fiqa_sa 的 test 划分，n=243）：
#   A. 基座 + 校准，不挂 adapter           → 期望 0.2428
#   B. 挂 FPB 三分类 r=16 adapter          → 期望 0.6749
#   C. 挂 FPB 三分类 r=1（16× 截断）       → 期望 0.6543
#
# Author: Raymond Xiaohu Fan
# Usage:
#   python3 scripts/verify_fiqa_transfer.py
#   python3 scripts/verify_fiqa_transfer.py --skip-base     # 跳过 A，只补 B/C
# ============================================================
import os, sys, json, subprocess, argparse, time

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
PY = sys.executable
OUTD = os.path.join(PROJ, "outputs", "reports", "fiqa_transfer")

# 论文声称值 / claimed values in §4.6
CLAIM = {"base": 0.2428, "r16": 0.6749, "r1": 0.6543}
TOL = 5e-4          # 4 位小数，容忍末位抖动
TOL_LOOSE = 5e-3    # 打印用

CONDS = [
    ("base", None,                 "基座零样本 + 校准"),
    ("r16",  "ckpts_sft3/fpb_r16", "FPB 三分类 r=16"),
    ("r1",   "ckpts_sft3/fpb_r1",  "FPB 三分类 r=1（16×）"),
]


def run_one(tag, adapter, desc):
    out = os.path.join(OUTD, f"transfer_{tag}.json")
    cmd = [PY, os.path.join(PROJ, "scripts", "rv_eval_preds.py"),
           "--dataset", "fiqa_sa", "--classes", "3", "--split", "test",
           "--holdout", "0.2", "--out", out]
    if adapter:
        cmd += ["--adapter", adapter]
    print("\n" + "=" * 74)
    print(f" [{tag}] {desc}")
    print(f"        adapter = {adapter or '(none, base only)'}")
    print("=" * 74, flush=True)
    t0 = time.time()
    r = subprocess.run(cmd, cwd=PROJ)
    dt = time.time() - t0
    if r.returncode != 0 or not os.path.exists(out):
        print(f"  ❌ 失败 (rc={r.returncode})")
        return None
    d = json.load(open(out, encoding="utf-8"))
    print(f"  ✅ acc={d['accuracy']:.4f}  n={d['n']}  用时 {dt/60:.1f} 分钟")
    return d


def mcnemar(a, b):
    """a、b 两个带 preds 的结果做配对检验；返回 (b_win, c_win, delta_pp, p)。"""
    import math
    okA = {p["i"]: p["ok"] for p in a["preds"]}
    okB = {p["i"]: p["ok"] for p in b["preds"]}
    n = a["n"]
    nb = sum(1 for i in okA if okA[i] == 1 and okB[i] == 0)   # A 对 B 错
    nc = sum(1 for i in okA if okA[i] == 0 and okB[i] == 1)   # A 错 B 对
    N = nb + nc
    k = min(nb, nc)
    p = 1.0 if N == 0 else min(1.0, 2 * sum(math.comb(N, j) for j in range(k + 1)) / 2 ** N)
    return nb, nc, (b["accuracy"] - a["accuracy"]) * 100, p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-base", action="store_true")
    args = ap.parse_args()
    os.makedirs(OUTD, exist_ok=True)

    # ---- 0. 环境预检 ----
    print("=" * 74)
    print(" FiQA 跨域迁移复核 / cross-domain transfer verification")
    print("=" * 74)
    for p in ("ckpts_sft3/fpb_r16", "ckpts_sft3/fpb_r1",
              "data/unified/fiqa_sa.jsonl"):
        full = os.path.join(PROJ, p)
        print(f"  {'✅' if os.path.exists(full) else '❌ 缺失'} {p}")
        if not os.path.exists(full):
            print(f"\n❌ 缺 {p}，先确认 PROJ={PROJ} 是否正确。")
            return 2
    try:
        import torch
        print(f"  torch {torch.__version__}  cuda_available={torch.cuda.is_available()}")
        if not torch.cuda.is_available():
            print("  ⚠️  没有 GPU。bitsandbytes 4-bit 需要 CUDA，这个脚本跑不了。")
            print("      等开卡再跑，或换 --base 指向一个已量化好的 CPU 可用模型。")
            return 3
    except Exception as e:
        print(f"  ⚠️  torch 不可用: {e}")
        return 3

    # ---- 1. 逐条件跑 ----
    res = {}
    for tag, adapter, desc in CONDS:
        if args.skip_base and tag == "base":
            p = os.path.join(OUTD, "transfer_base.json")
            if os.path.exists(p):
                res[tag] = json.load(open(p, encoding="utf-8"))
                print(f"\n [base] 复用已有 {p}")
                continue
        res[tag] = run_one(tag, adapter, desc)

    # ---- 2. 与论文值比对 ----
    print("\n" + "=" * 74)
    print(" 与论文 §4.6 比对 / against the manuscript")
    print("=" * 74)
    print(f" {'条件':<10}{'论文':>10}{'实测':>10}{'差':>10}   判定")
    print("-" * 74)
    nfail = 0
    for tag, _, desc in CONDS:
        d = res.get(tag)
        if d is None:
            print(f" {tag:<10}{CLAIM[tag]:>10.4f}{'—':>10}{'—':>10}   ⚠️ 未完成")
            nfail += 1
            continue
        got = d["accuracy"]
        ok = abs(got - CLAIM[tag]) <= TOL
        if not ok:
            nfail += 1
        print(f" {tag:<10}{CLAIM[tag]:>10.4f}{got:>10.4f}{got-CLAIM[tag]:>+10.4f}   "
              f"{'✅ 一致' if ok else '❌ 不一致'}")

    # ---- 3. 配对检验：r16 vs r1（论文写 Δ=+2.06pp, p=0.2668）----
    if res.get("r16") and res.get("r1"):
        nb, nc, delta, p = mcnemar(res["r16"], res["r1"])
        print("\n" + "-" * 74)
        print(" 配对检验 r16 vs r1（论文写 Δ=+2.06 pp，p=0.2668，n.s.）")
        print(f"  实测：r16 对 r1 错 = {nb}，r16 错 r1 对 = {nc}，"
              f"Δ = {delta:+.2f} pp，McNemar p = {p:.4f}")
        ok_d = abs(abs(delta) - 2.06) < 0.15
        ok_p = abs(p - 0.2668) < 0.05 or (p > 0.05) == (0.2668 > 0.05)
        print(f"  Δ {'✅' if ok_d else '❌'}   p {'✅（同为不显著）' if ok_p else '❌'}")
    # 论文说 "+43.2 pp"，指 base → r16
    if res.get("base") and res.get("r16"):
        gain = (res["r16"]["accuracy"] - res["base"]["accuracy"]) * 100
        print(f"\n base → r16 提升 = {gain:+.2f} pp（论文写 +43.2 pp）"
              f"  {'✅' if abs(gain-43.2)<0.5 else '❌'}")

    # ---- 4. 测试项一致性：必须和已存档的 fiqa_s42_r16.json 是同一批 ----
    ref = os.path.join(PROJ, "outputs", "reports", "fiqa", "fiqa_s42_r16.json")
    if os.path.exists(ref) and res.get("r16"):
        a = json.load(open(ref, encoding="utf-8"))
        g_ref = [p["gold"] for p in a["preds"]]
        g_new = [p["gold"] for p in res["r16"]["preds"]]
        same = (g_ref == g_new)
        print(f"\n 测试项一致性（vs 已存档 fiqa_s42_r16.json）："
              f"{'✅ 同一批 243 项' if same else '❌ 不是同一批，划分变了'}")
        if not same:
            nfail += 1

    print("\n" + "=" * 74)
    if nfail == 0:
        print(" ✅ 全部通过 —— FiQA 迁移的三个数可追溯了，E-26 第 ① 项可以关掉。")
    else:
        print(f" ❌ {nfail} 项不一致 —— 把上面的表贴给我，我核对是论文错了还是复现条件不同。")
    print("=" * 74)
    print(f"\n 结果目录：{OUTD}")
    return 0 if nfail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
