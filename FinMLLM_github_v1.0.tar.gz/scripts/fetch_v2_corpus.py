#!/usr/bin/env python3
# ============================================================
# FinMLLM / fetch_v2_corpus.py
# V2 corpus: business lines that actually DIFFER in register, not just in topic.
# V1 used SEC 10-K for all lines — same template, same register, no heterogeneity.
# V2 语料：让业务线在"文体"上真正分化，而不仅是主题不同。
# V1 三条线全用 SEC 10-K —— 模板相同、文体相同，根本没有异构性。
#
# Author : Raymond Xiaohu Fan
# Note   : You cannot detect a difference between three copies of the same template.
#          三份同一个模板，你测不出差异，这不是方法的错。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/fetch_v2_corpus.py --probe     # only test availability
#   python scripts/fetch_v2_corpus.py --apply     # download + build jsonl
# ============================================================
import os, sys, json, argparse, glob, re, html, urllib.request

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
RAW = os.path.join(ROOT, "data", "raw_v2")
OUT = os.path.join(ROOT, "data", "unified_v2")
os.makedirs(RAW, exist_ok=True); os.makedirs(OUT, exist_ok=True)

# Each domain: list of candidate (kind, locator). First success wins.
# 每个域：候选源列表，第一个成功即用。
CANDIDATES = {
    "bank": [
        ("hf", "PolyAI/banking77"),
        ("hf", "mteb/banking77"),
    ],
    "securities": [
        ("hf", "FinGPT/fingpt-fiqa_qa"),
        ("hf", "pauri32/fiqa-2018"),
    ],
    "insurance": [
        ("hf", "hf4h/insurance_qa"),
        ("hf", "Chris1/insuranceQA"),
        ("hf", "clips/insurance_qa"),
    ],
    "regulator": [
        ("url", "https://www.federalreserve.gov/newsevents/speech/2023speech.htm"),
        ("url", "https://www.sec.gov/news/pressreleases"),
    ],
}

UA = "FinMLLM academic research raymond@example.com"


def probe_hf(repo):
    url = f"https://hf-mirror.com/api/datasets/{repo}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200
    except Exception:
        return False


def probe_url(u):
    try:
        req = urllib.request.Request(u, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200
    except Exception:
        return False


def strip_html(raw):
    raw = re.sub(r"<script.*?</script>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<style.*?</style>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    raw = re.sub(r"[ \t\xa0]+", " ", raw)
    return re.sub(r"\n\s*\n+", "\n", raw).strip()


def chunk(text, size=1200, overlap=150):
    out = []
    for i in range(0, max(1, len(text) - overlap), size - overlap):
        p = text[i:i + size].strip()
        if len(p) >= 300:
            out.append(p)
    return out


def rows_from_hf(repo, domain):
    """Download parquet shards directly — never import `datasets`.
    The installed `datasets` is incompatible with huggingface_hub, so we bypass it.
    直接下 parquet 分片，绕开 datasets 与 huggingface_hub 的版本冲突。"""
    from huggingface_hub import list_repo_files, hf_hub_download
    import pyarrow.parquet as pq

    rows = []
    try:
        files = [f for f in list_repo_files(repo_id=repo, repo_type="dataset")
                 if f.endswith(".parquet")]
    except Exception as e:
        print(f"    list_repo_files failed: {type(e).__name__}: {str(e)[:120]}")
        return rows
    if not files:
        print(f"    {repo}: no parquet shards")
        return rows

    for rel in files[:8]:
        try:
            path = hf_hub_download(repo_id=repo, filename=rel, repo_type="dataset")
            df = pq.read_table(path).to_pandas()
        except Exception as e:
            print(f"    {rel}: {type(e).__name__}")
            continue

        cols = [c for c in df.columns
                if str(c).lower() in ("text", "sentence", "question", "utterance",
                                      "input", "context", "answer", "content", "title")]
        if not cols:
            print(f"    {rel}: no text-like column in {list(df.columns)[:8]}")
            continue

        for _, r in df.iterrows():
            parts = [str(r[c]) for c in cols if str(r[c]).strip() and str(r[c]) != "nan"]
            t = " ".join(parts).strip()
            if len(t) < 20:
                continue
            for c in chunk(t):
                rows.append({"id": f"{domain}-{len(rows)}", "text": c,
                             "domain": domain, "source": repo, "split": os.path.basename(rel)})
    return rows


def rows_from_url(u, domain):
    rows = []
    try:
        req = urllib.request.Request(u, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read().decode("utf-8", errors="ignore")
    except Exception as e:
        print(f"    fetch failed: {type(e).__name__}")
        return rows
    txt = strip_html(raw)
    for c in chunk(txt):
        rows.append({"id": f"{domain}-{len(rows)}", "text": c,
                     "domain": domain, "source": u, "split": "train"})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--apply", action="store_true")
    args = ap.parse_args()

    print("=" * 78)
    print(" V2 CORPUS — heterogeneous registers / 异构文体语料")
    print("=" * 78)

    avail = {}
    for dom, cands in CANDIDATES.items():
        print(f"\n### {dom}")
        for kind, loc in cands:
            ok = probe_hf(loc) if kind == "hf" else probe_url(loc)
            print(f"  {'✅' if ok else '❌'} {kind}: {loc}")
            if ok and dom not in avail:
                avail[dom] = (kind, loc)

    if args.probe:
        print("\n(probe only / 仅探测)")
        return

    print("\n" + "=" * 78)
    print(" BUILDING / 构建")
    print("=" * 78)
    for dom, (kind, loc) in avail.items():
        print(f"\n### {dom} <- {loc}")
        rows = rows_from_url(loc, dom) if kind == "url" else rows_from_hf(loc, dom)
        if not rows:
            print("  ⚠️  empty, skipped")
            continue
        p = os.path.join(OUT, f"{dom}.jsonl")
        with open(p, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  ✅ {len(rows)} chunks -> {p}")

    missing = [d for d in CANDIDATES if d not in avail]
    if missing:
        print(f"\n⚠️  domains without any source: {missing}")
        print("   你可以手工放文本到 data/raw_v2/<domain>.txt 后重跑 --apply")


if __name__ == "__main__":
    main()
