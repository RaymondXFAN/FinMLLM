#!/usr/bin/env python3
# ============================================================
# FinMLLM / analyze_adapter_rank.py
# Why does 16x compression cost nothing? Because the effective rank of a
# fine-tuned adapter is far below its configured rank. This script proves it.
# 为什么 16 倍压缩不掉点？因为微调后 adapter 的"有效秩"远低于配置秩。
# 这个脚本用奇异值谱把这件事量化出来。
#
# Author : Raymond Xiaohu Fan
# Note   : "It works" is a measurement. "It works because..." is a paper.
#          "它有效"是测量，"它有效因为……"才是论文。
# Updated: 2026-10-24
#
# Usage / 用法:
#   python scripts/analyze_adapter_rank.py --adapter ckpts_sft/fpb_r16
#   python scripts/analyze_adapter_rank.py --adapter ckpts_sft3/fpb_r16 --tag tri
# ============================================================
import os, sys, json, glob, argparse
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--tag", default="bin")
    ap.add_argument("--max-layers", type=int, default=64)
    args = ap.parse_args()

    from safetensors.torch import load_file
    files = glob.glob(os.path.join(args.adapter, "*.safetensors"))
    if not files:
        print("❌ no safetensors")
        return 2
    sd = load_file(files[0])

    cfg_p = os.path.join(args.adapter, "adapter_config.json")
    r_cfg = 16
    scale = 1.0
    if os.path.exists(cfg_p):
        c = json.load(open(cfg_p))
        r_cfg = c.get("r") or c.get("lora_r") or 16
        scale = (c.get("lora_alpha") or 32) / r_cfg

    keys = sorted([k for k in sd if "lora_A" in k])[: args.max_layers]
    recs = []
    for kA in keys:
        kB = kA.replace("lora_A", "lora_B")
        if kB not in sd:
            continue
        A = sd[kA].float().cpu().numpy()
        B = sd[kB].float().cpu().numpy()
        W = (B @ A) * scale
        s = np.linalg.svd(W, compute_uv=False)
        e = s ** 2
        total = e.sum()
        if total <= 0:
            continue
        cum = np.cumsum(e) / total
        rec = {
            "layer": kA.split("layers.")[-1].split(".")[0] if "layers." in kA else kA[-40:],
            "rank_cfg": int(min(W.shape)),
            "s_max": float(s[0]),
            # how many singular values are needed for 50/90/99% energy
            # 达到 50/90/99% 能量分别需要几个奇异值
            "n50": int(np.searchsorted(cum, 0.50) + 1),
            "n90": int(np.searchsorted(cum, 0.90) + 1),
            "n99": int(np.searchsorted(cum, 0.99) + 1),
            "top1_share": float(e[0] / total),
        }
        recs.append(rec)

    if not recs:
        print("❌ no layers analysed")
        return 2

    n50 = [r["n50"] for r in recs]
    n90 = [r["n90"] for r in recs]
    n99 = [r["n99"] for r in recs]
    top1 = [r["top1_share"] for r in recs]

    print("=" * 76)
    print(f" EFFECTIVE RANK ANALYSIS / 有效秩分析   adapter={os.path.basename(args.adapter)}")
    print(f" configured rank = {r_cfg}   layers analysed = {len(recs)}")
    print("=" * 76)
    print(f"{'metric':<22}{'mean':>10}{'median':>10}{'p95':>10}{'max':>10}")
    print("-" * 76)
    for name, arr in [("n50 (50% energy)", n50), ("n90 (90% energy)", n90),
                      ("n99 (99% energy)", n99), ("top-1 energy share", top1)]:
        print(f"{name:<22}{np.mean(arr):>10.2f}{np.median(arr):>10.1f}"
              f"{np.percentile(arr,95):>10.1f}{np.max(arr):>10.1f}")

    print("\n结论 / Conclusion:")
    print(f"  配置秩 = {r_cfg}，但 90% 能量平均只需 {np.mean(n90):.1f} 个奇异值。")
    print(f"  → 有效秩 ≈ {np.mean(n90)/r_cfg*100:.0f}% 的配置秩，解释了为什么 16× 压缩零损失。")

    out = {"adapter": os.path.basename(args.adapter), "rank_cfg": r_cfg,
           "n_layers": len(recs), "n50_mean": float(np.mean(n50)),
           "n90_mean": float(np.mean(n90)), "n99_mean": float(np.mean(n99)),
           "top1_share_mean": float(np.mean(top1)), "per_layer": recs}
    p = os.path.join(REP, f"rank_analysis_{args.tag}.json")
    json.dump(out, open(p, "w"), indent=2, ensure_ascii=False)
    print(f"\n💾 saved -> {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
