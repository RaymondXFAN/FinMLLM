#!/usr/bin/env python3
# ============================================================
# FinMLLM / clean_manuscript.py
# 把工作稿整理成可以投出去的干净稿：去掉备忘、去掉中文标注、章节改英文编号。
# Turn the working draft into a submission-ready manuscript: strip the style
# memo, drop Chinese annotations, renumber sections in English.
#
# 我一直忘了删开头那段备忘，结果它混进了引用编号里——[13] 其实是举例。
# 教训：写作备忘和正文分文件放，别图省事塞一起。
# I forgot to delete the style memo at the top, and it ended up inside the
# citation numbering — that [13] was just an example. Lesson: keep memos out of
# the manuscript file.
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-11-08
# ============================================================
import os, re, sys

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
SRC = os.path.join(PROJ, "12_论文正文_v2_numbered.md")
DST = os.path.join(PROJ, "17_论文正文_SUBMISSION.md")
MEMO = os.path.join(PROJ, "16_写作风格备忘.md")

HEAD_MAP = {
    "## 一、Abstract（216 words，v2）": "# Abstract",
    "## 二、Introduction": "# 1 Introduction",
    "## 三、Related Work": "# 2 Related Work",
    "## 四、3 Data and method": "# 3 Data and Method",
    "## 五、4 Results": "# 4 Results",
    "## 六、5 Discussion": "# 5 Discussion",
    "## 七、6 Conclusion": "# 6 Conclusion",
}


def main():
    raw = open(SRC, encoding="utf-8").read()
    lines = raw.split("\n")

    # ---- 1. 切出备忘（"零、文体备忘" → "一、Abstract" 之间）----
    i0 = next(i for i, l in enumerate(lines) if l.startswith("## 零、文体备忘"))
    i1 = next(i for i, l in enumerate(lines) if l.startswith("## 一、Abstract"))
    memo_block = "\n".join(lines[i0:i1]).rstrip()
    open(MEMO, "w", encoding="utf-8").write(
        "# 写作风格备忘（不属于正文）\n\n> 从正文文件剥离，2026-11-08。写新段落时对照。\n\n" + memo_block + "\n")

    # ---- 2. 切出待确认清单 ----
    itail = next((i for i, l in enumerate(lines) if l.startswith("## 八、待你确认")), len(lines))
    tail_block = "\n".join(lines[itail:]).rstrip()

    body = lines[i1:itail]

    out = []
    for ln in body:
        s = ln.rstrip()
        # ¶ 段标 → 删除
        if re.match(r"^###\s*¶\d+", s):
            continue
        # 重复的 "### 6 Conclusion（311 words）"
        if re.match(r"^###\s*6\s*Conclusion", s):
            continue
        # 章节主标题
        if s in HEAD_MAP:
            out.append(HEAD_MAP[s]); continue
        # "### 2.1 Title（340 words）" → "## 2.1 Title"
        m = re.match(r"^###\s*(\d+\.\d+)\s+(.*?)\s*（\d+\s*words）\s*$", s)
        if m:
            out.append(f"## {m.group(1)} {m.group(2)}"); continue
        # "### 2.1 Title" 无字数
        m = re.match(r"^###\s*(\d+\.\d+)\s+(.*)$", s)
        if m:
            out.append(f"## {m.group(1)} {m.group(2)}"); continue
        # 其他中文残留标题（不该有了，但防一手）
        if s.startswith("#") and re.search(r"[\u4e00-\u9fff]", s):
            continue
        out.append(s)

    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"
    # 行首中文孤儿注释（如"（312 words）"）
    text = re.sub(r"（\d+\s*words）", "", text)
    open(DST, "w", encoding="utf-8").write(text)

    # ---- 报告 ----
    print("=" * 70)
    print(f"✅ 干净稿: {DST}")
    print(f"✅ 备忘归档: {MEMO}")
    print("=" * 70)
    heads = re.findall(r"^#+ .*$", text, flags=re.M)
    print("章节骨架:")
    for h in heads:
        print("  " + h)
    cn = re.findall(r"[\u4e00-\u9fff]", text)
    print(f"\n残留中文字符: {len(cn)}")
    if cn:
        for m in re.finditer(r".{0,25}[\u4e00-\u9fff]+.{0,25}", text):
            print("   …" + m.group(0) + "…")
    w = len(re.findall(r"[A-Za-z][A-Za-z0-9'\-]*", text))
    print(f"英文词数: {w}")

    if tail_block:
        tp = os.path.join(PROJ, "18_待确认事项.md")
        open(tp, "w", encoding="utf-8").write(tail_block + "\n")
        print(f"✅ 待确认清单: {tp}")


if __name__ == "__main__":
    main()
