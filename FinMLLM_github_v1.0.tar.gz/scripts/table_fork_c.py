#!/usr/bin/env python3
# ============================================================
# FinMLLM / table_fork_c.py
# Turn every eval_*.json into one compression-accuracy table (Markdown + CSV).
# 把所有 eval_*.json 汇总成一张"压缩-精度"表（Markdown + CSV）。
#
# Author : Raymond Xiaohu Fan
# Note   : The table is the paper. Everything else is commentary. / 表就是论文，其余都是注脚。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/table_fork_c.py
# ============================================================
import os, json, glob, csv, re

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
OUT = os.path.join(ROOT, "outputs", "tables")
os.makedirs(OUT, exist_ok=True)

rows = []
for f in sorted(glob.glob(os.path.join(REP, "eval_*.json"))):
    try:
        d = json.load(open(f))
    except Exception:
        continue
    m = re.search(r"eval_(.+?)_(fpb|fiqa_sa|tfns)_r(\d+)\.json", os.path.basename(f))
    if not m:
        continue
    domain, dataset, rank = m.group(1), m.group(2), int(m.group(3))
    rows.append({
        "domain": domain, "dataset": dataset, "rank": rank,
        "accuracy": round(d.get("accuracy", 0), 4),
        "macro_f1": round(d.get("macro_f1", 0), 4),
        "n": d.get("n", 0),
    })

if not rows:
    print("❌ 没有找到 eval_*.json，先跑 run_fork_c.sh")
    raise SystemExit(1)

rows.sort(key=lambda r: (r["dataset"], r["domain"], -r["rank"]))

print("=" * 78)
print(" FORK C · COMPRESSION–ACCURACY TABLE / 压缩-精度表")
print("=" * 78)
print(f"{'dataset':<10}{'domain':<14}{'rank':>6}{'CR':>7}{'accuracy':>11}{'macro-F1':>11}")
print("-" * 78)
for r in rows:
    cr = 16 / r["rank"]
    print(f"{r['dataset']:<10}{r['domain']:<14}{r['rank']:>6}{cr:>6.0f}x"
          f"{r['accuracy']:>11.4f}{r['macro_f1']:>11.4f}")

# relative retention per domain (rank16 as anchor)
print("\n精度保持率（以 r=16 为基准）/ Accuracy retention")
print("-" * 78)
for ds in sorted({r["dataset"] for r in rows}):
    for dom in sorted({r["domain"] for r in rows if r["dataset"] == ds}):
        base = next((r for r in rows if r["dataset"] == ds and r["domain"] == dom and r["rank"] == 16), None)
        if not base or not base["accuracy"]:
            continue
        line = f"  {ds:<8}{dom:<14}"
        for r in sorted([x for x in rows if x["dataset"] == ds and x["domain"] == dom],
                        key=lambda x: -x["rank"]):
            ret = r["accuracy"] / base["accuracy"] * 100
            line += f" r{r['rank']}={ret:.1f}%"
        print(line)

csv_path = os.path.join(OUT, "fork_c_compression_accuracy.csv")
with open(csv_path, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["dataset", "domain", "rank", "compression_ratio", "accuracy", "macro_f1", "n"])
    w.writeheader()
    for r in rows:
        w.writerow({**r, "compression_ratio": round(16 / r["rank"], 2)})
print(f"\n💾 saved -> {csv_path}")
