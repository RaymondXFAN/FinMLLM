#!/usr/bin/env bash
# ============================================================
# FinMLLM / supp / check_progress.sh
# Is it running, stalled, dead, or done? One command, four answers.
# 它到底在跑、卡住了、死了、还是跑完了？一条命令给四个答案。
#
# Author : Raymond Xiaohu Fan
# Note   : "Still running" and "hung forever" look identical in ps.
#          mtime is what tells them apart. / 看文件改动时间，别看进程表。
# Updated: 2026-10-25
#
# Usage / 用法:
#   bash scripts/supp/check_progress.sh
#   STALL_MIN=15 bash scripts/supp/check_progress.sh     # 15 min idle = stalled
# ============================================================
set -uo pipefail
PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
cd "$PROJ" 2>/dev/null || { echo "FATAL: $PROJ not found"; exit 1; }

STALL_MIN="${STALL_MIN:-20}"      # idle minutes before we call it stalled / 多久没动算卡住
H="============================================================"

echo "$H"
echo " FinMLLM PROGRESS CHECK   $(date '+%F %T')"
echo " project: $PROJ"
echo "$H"

# ------------------------------------------------------------
# 1. PROCESSES / 进程
# ------------------------------------------------------------
echo
echo "[1] PROCESSES"
P=$(pgrep -fa "train_sft|eval_cloze|train_domain|run_fork_c|final_exp|run_supp|s3_gpu_queue" 2>/dev/null | grep -v pgrep || true)
if [ -z "$P" ]; then
  echo "    (none) -> nothing is running / 没有任何相关进程在跑"
  NP=0
else
  echo "$P" | while IFS= read -r l; do
    pid=$(echo "$l" | awk '{print $1}')
    et=$(ps -o etime= -p "$pid" 2>/dev/null | tr -d ' ')
    echo "    pid=$pid  elapsed=${et:-?}  ${l:0:120}"
  done
  NP=$(echo "$P" | wc -l)
fi

# ------------------------------------------------------------
# 2. LOGS: which one is the live one, and is it still moving?
#    日志：哪个是活的，还在动吗
# ------------------------------------------------------------
echo
echo "[2] LOG ACTIVITY  (idle > ${STALL_MIN} min = STALLED)"
LOGS=$(ls -t outputs/logs/*.log outputs/*.log *.log 2>/dev/null | head -12)
if [ -z "$LOGS" ]; then
  echo "    no logs found / 没找到日志"
  STALLED=1
else
  now=$(date +%s)
  printf "    %-52s %10s %8s\n" "LOG" "SIZE" "IDLE"
  echo "    ------------------------------------------------------------------"
  for f in $LOGS; do
    mt=$(stat -c %Y "$f" 2>/dev/null || stat -f %m "$f" 2>/dev/null || echo "$now")
    idle=$(( (now - mt) / 60 ))
    sz=$(du -h "$f" 2>/dev/null | cut -f1)
    mark=""
    [ "$idle" -ge "$STALL_MIN" ] && mark="  <== STALLED"
    printf "    %-52s %10s %6sm%s\n" "$(basename "$f")" "$sz" "$idle" "$mark"
  done
  NEWEST=$(echo "$LOGS" | head -1)
  MT=$(stat -c %Y "$NEWEST" 2>/dev/null || echo "$now")
  IDLE_NEW=$(( (now - MT) / 60 ))
  if [ "$IDLE_NEW" -ge "$STALL_MIN" ]; then STALLED=1; else STALLED=0; fi
fi

# ------------------------------------------------------------
# 3. THE final_exp2 LOG, if it exists / 那个卡住的任务
# ------------------------------------------------------------
echo
echo "[3] final_exp2 / FiQA-multiseed LOG"
FE=$(find . -maxdepth 3 -name "final_exp2*" -type f 2>/dev/null | head -3)
if [ -z "$FE" ]; then
  echo "    ⚠️  no final_exp2* log found. Searching wider..."
  FE=$(find /root /root/autodl-tmp -maxdepth 4 -name "final_exp2*" -type f 2>/dev/null | head -3)
fi
if [ -z "$FE" ]; then
  echo "    ❌ final_exp2 log NOT FOUND anywhere. It never started, or was deleted."
  echo "       -> check shell history:  history | grep -i 'final_exp'"
else
  for f in $FE; do
    echo "    --- $f  ($(du -h "$f" | cut -f1), modified $(date -r "$f" '+%F %T')) ---"
    echo "    ... last 15 lines:"
    tail -n 15 "$f" | sed 's/^/      /'
    echo "    --- errors inside:"
    grep -nE "Traceback|CUDA out of memory|RuntimeError|Killed|Error:" "$f" 2>/dev/null | tail -8 | sed 's/^/      /' || echo "      (none)"
  done
fi

# ------------------------------------------------------------
# 4. GPU / 显卡
# ------------------------------------------------------------
echo
echo "[4] GPU"
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader | sed 's/^/    /'
  nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader 2>/dev/null | sed 's/^/    app: /'
else
  echo "    nvidia-smi unavailable"
fi

# ------------------------------------------------------------
# 5. RESULTS ALREADY ON DISK / 已经落地的结果
# ------------------------------------------------------------
echo
echo "[5] RESULTS ON DISK  (outputs/reports/)"
python3 - <<'PY'
import os, glob, json, time
pat = ["outputs/reports/*.json"]
files = []
for p in pat:
    files += glob.glob(p)
if not files:
    print("    (no json results yet)")
    raise SystemExit
files = sorted(set(files), key=lambda x: -os.path.getmtime(x))

def scrape(o, d=0):
    if d > 4 or o is None: return None
    if isinstance(o, dict):
        for k, v in o.items():
            kl = k.lower()
            if isinstance(v, (int, float)) and any(t in kl for t in ("acc","accuracy","f1","score")):
                if "cal" in kl or kl in ("acc","accuracy","f1","macro_f1"):
                    return float(v), k
        for v in o.values():
            r = scrape(v, d+1)
            if r: return r
    elif isinstance(o, list):
        for v in o:
            r = scrape(v, d+1)
            if r: return r
    return None

print(f"    {len(files)} json files")
print(f"    {'FILE':<46}{'AGE':>8}{'ACC':>10}  KEY")
print("    " + "-"*78)
for f in files[:40]:
    age = int((time.time()-os.path.getmtime(f))/60)
    try:
        r = scrape(json.load(open(f)))
    except Exception:
        r = None
    nm = os.path.basename(f)[:44]
    if r:
        print(f"    {nm:<46}{age:>6}m{r[0]:>10.4f}  {r[1]}")
    else:
        print(f"    {nm:<46}{age:>6}m{'-':>10}  (no acc field)")
PY

# ------------------------------------------------------------
# 6. VERDICT / 结论
# ------------------------------------------------------------
echo
echo "$H"
if [ "${NP:-0}" -gt 0 ] && [ "${STALLED:-0}" -eq 0 ]; then
  echo " 🟢 RUNNING — processes alive and the log is still moving."
  echo "    在跑，日志还在动。去看 [5] 已经出了几个结果，等它就行。"
elif [ "${NP:-0}" -gt 0 ] && [ "${STALLED:-0}" -eq 1 ]; then
  echo " 🟡 STALLED — process exists but the log has not changed for >= ${STALL_MIN} min."
  echo "    进程还在但日志不动了。可能：下载卡住 / 显存被抢 / 死锁。"
  echo "    建议： tail -f <最新log> 再看 5 分钟；确实不动就 kill 掉重跑。"
  echo "    kill:  pkill -f eval_cloze   (先确认 pid)"
elif [ "${NP:-0}" -eq 0 ] && [ -n "${FE:-}" ]; then
  echo " 🔴 DEAD — no process, but a log exists. It died mid-way."
  echo "    没有进程，但日志还在。跑到一半挂了。"
  echo "    先看 [3] 的 errors，再按 README 补跑。"
else
  echo " 🔵 IDLE — nothing running, no final_exp2 log. Either finished or never started."
  echo "    空闲。要么已经跑完，要么根本没启动。查 history 确认。"
fi
echo "$H"
