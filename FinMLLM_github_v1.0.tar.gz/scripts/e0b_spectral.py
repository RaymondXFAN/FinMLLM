#!/usr/bin/env python3
# ============================================================
# FinMLLM / e0b_spectral.py
# E0b — a fairer retest of H0. Four fixes over E0:
#   1) layer-wise metrics instead of a global average
#   2) spectral DIRECTION (which coefficients carry energy), not just how much
#   3) intra-domain vs inter-domain consistency (does a "domain identity" exist?)
#   4) random low-rank control (is real Delta-W structurally different from noise?)
# E0b —— 对 H0 的更公平复测，四个修正：
#   1) 逐层而非全局平均；2) 看谱"方向"而非只看能量多少；
#   3) 域内一致性 vs 域间一致性（是否存在"域身份"）；
#   4) 同秩随机矩阵对照（真实 ΔW 是否比噪声更有结构）。
#
# Author : Raymond Xiaohu Fan
# Note   : EC saturates under a rank-16 constraint. Direction does not.
#          秩 16 的约束会压平 EC，但压不平谱方向。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/e0b_spectral.py --ckpt_dir ckpts
#   python scripts/e0b_spectral.py --ckpt_dir ckpts --k 10 --perm 2000
# ============================================================
import os, sys, json, glob, argparse, itertools, random
import numpy as np
from scipy.fftpack import dct

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)
MAX_SIZE = 2048          # center-crop huge matrices for speed / 大矩阵中心裁切提速


def dct2(x):
    return dct(dct(x.T, norm="ortho").T, norm="ortho")


def load_deltas(adapter_dir, max_layers=64):
    """Load Delta-W per adapted layer. / 逐层读取 Delta-W。"""
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files:
        return [], None
    sd = load_file(files[0])
    cfg = os.path.join(adapter_dir, "adapter_config.json")
    scale, r = 1.0, 16
    if os.path.exists(cfg):
        c = json.load(open(cfg))
        r = c.get("r") or c.get("lora_r") or 16
        scale = (c.get("lora_alpha") or 32) / r
    keys = [k for k in sd if "lora_A" in k]
    out = []
    for k in sorted(keys)[:max_layers]:
        kb = k.replace("lora_A", "lora_B")
        if kb not in sd:
            continue
        A = sd[k].float().cpu().numpy()
        B = sd[kb].float().cpu().numpy()
        W = (B @ A) * scale
        if W.size < 256:
            continue
        out.append(W)
    return out, r


def crop(W, max_size=MAX_SIZE):
    h, w = W.shape
    if h <= max_size and w <= max_size:
        return W
    sh, sw = min(h, max_size), min(w, max_size)
    i0, j0 = (h - sh) // 2, (w - sw) // 2
    return W[i0:i0 + sh, j0:j0 + sw]


def layer_metrics(W, k_pct=10):
    """Return (EC, entropy, low_ratio, top-k coordinate set)."""
    W = crop(W)
    C = dct2(W)
    E = C ** 2
    flat = E.ravel()
    total = flat.sum()
    if total <= 0:
        return 0.0, 0.0, 0.0, set()

    k = max(1, int(flat.size * k_pct / 100))
    order = np.argpartition(flat, -k)[-k:]
    ec = float(flat[order].sum() / total)
    coords = set(order.tolist())

    p = flat / total
    p = p[p > 0]
    H = float(-(p * np.log(p)).sum())

    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    rr = np.sqrt((yy / max(h - 1, 1)) ** 2 + (xx / max(w - 1, 1)) ** 2)
    rr /= rr.max()
    low = float(E[rr <= 0.3].sum() / total)
    return ec, H, low, coords


def jaccard(a, b):
    if not a and not b:
        return 0.0
    return len(a & b) / len(a | b)


def random_lowrank_like(W, r):
    W = crop(W)
    h, w = W.shape
    A = np.random.randn(r, w) / np.sqrt(w)
    B = np.random.randn(h, r) / np.sqrt(r)
    return B @ A


def pairwise_jaccard(coords_list):
    """Precompute the full NxN Jaccard matrix once. O(N^2) set ops, done once.
    一次性预计算 NxN Jaccard 矩阵，避免置换时重复做集合运算。"""
    n = len(coords_list)
    J = np.zeros((n, n), dtype=np.float32)
    for i in range(n):
        si = coords_list[i]
        for j in range(i + 1, n):
            sj = coords_list[j]
            inter = len(si & sj)
            uni = len(si | sj)
            v = inter / uni if uni else 0.0
            J[i, j] = J[j, i] = v
    return J


def perm_test_matrix(J, group_sizes, observed, n_perm=1000, seed=0):
    """Permutation test on a precomputed Jaccard matrix — pure numpy lookups.
    在预计算矩阵上做置换检验，纯 numpy 查表，秒级完成。"""
    rng = np.random.RandomState(seed)
    n = J.shape[0]
    if n < 6:
        return float("nan")
    labels = np.zeros(n, dtype=np.int32)
    pos = 0
    for gi, m in enumerate(group_sizes):
        labels[pos:pos + m] = gi
        pos += m

    def mean_intra(lab):
        vals = []
        for gi in range(len(group_sizes)):
            idx = np.where(lab == gi)[0]
            if len(idx) < 2:
                continue
            sub = J[np.ix_(idx, idx)]
            iu = np.triu_indices(len(idx), 1)
            vals.append(sub[iu].mean())
        return float(np.mean(vals)) if vals else 0.0

    cnt = 0
    for _ in range(n_perm):
        rng.shuffle(labels)
        if mean_intra(labels) >= observed:
            cnt += 1
    return cnt / n_perm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_dir", default=os.path.join(ROOT, "ckpts"))
    ap.add_argument("--k", type=int, default=10, help="top-k%% coefficients")
    ap.add_argument("--perm", type=int, default=1000)
    args = ap.parse_args()

    print("=" * 84)
    print(" E0b · FAIR SPECTRAL RETEST / 谱身份公平复测")
    print(f" k={args.k}%   ckpt_dir={args.ckpt_dir}")
    print("=" * 84)

    domains = {}
    for d in sorted(glob.glob(os.path.join(args.ckpt_dir, "*_qlora*"))):
        name = os.path.basename(d).split("_qlora")[0]
        ws, r = load_deltas(d)
        if ws:
            domains[name] = {"ws": ws, "r": r or 16}
            print(f"  ✅ {name:<14}{len(ws):>3} layers  rank={r}")
        else:
            print(f"  ⚠️  {name:<14}no weights")

    if len(domains) < 2:
        print("\n❌ 至少需要 2 个 adapter。")
        return 2

    print("\n[1/4] 逐层谱指标（看 std，不只看 mean）")
    print("-" * 84)
    print(f"{'domain':<14}{'EC_mean':>10}{'EC_std':>9}{'H_mean':>9}{'low_mean':>10}")
    print("-" * 84)
    for name, pack in domains.items():
        ecs, Hs, lows, coords = [], [], [], []
        for W in pack["ws"]:
            ec, H, low, cs = layer_metrics(W, args.k)
            ecs.append(ec); Hs.append(H); lows.append(low); coords.append(cs)
        pack.update({"ec": ecs, "H": Hs, "low": lows, "coords": coords})
        print(f"{name:<14}{np.mean(ecs):>10.4f}{np.std(ecs):>9.4f}"
              f"{np.mean(Hs):>9.2f}{np.mean(lows):>10.4f}")

    print(f"\n[2/4] 谱方向一致性（top-{args.k}% 坐标的 Jaccard）")
    print("-" * 84)
    intra = {}
    for name, pack in domains.items():
        cs = pack["coords"]
        vals = [jaccard(a, b) for a, b in itertools.combinations(cs, 2)]
        intra[name] = float(np.mean(vals)) if vals else 0.0
        print(f"  域内 {name:<14}J_intra = {intra[name]:.4f}")

    inter_vals = []
    for a, b in itertools.combinations(domains, 2):
        vals = [jaccard(x, y) for x in domains[a]["coords"] for y in domains[b]["coords"]]
        inter_vals.extend(vals)
        print(f"  域间 {a:<12}× {b:<12}J_inter = {np.mean(vals):.4f}")
    inter_mean = float(np.mean(inter_vals)) if inter_vals else 0.0
    intra_mean = float(np.mean(list(intra.values())))

    print(f"\n  ➜ 平均 J_intra = {intra_mean:.4f}   J_inter = {inter_mean:.4f}   "
          f"差值 = {intra_mean - inter_mean:+.4f}")

    # Build one flat coords list + group sizes, then precompute J once.
    # 展平所有层坐标，预计算一次 Jaccard 矩阵，置换时只做查表。
    flat, sizes = [], []
    for name, pack in domains.items():
        flat.extend(pack["coords"])
        sizes.append(len(pack["coords"]))
    print(f"  预计算 {len(flat)}×{len(flat)} Jaccard 矩阵 ...")
    Jmat = pairwise_jaccard(flat)
    p_perm = perm_test_matrix(Jmat, sizes, intra_mean, n_perm=args.perm)
    print(f"  置换检验 p = {p_perm:.4f}  ({args.perm} 次置换)")

    print(f"\n[3/4] 随机低秩对照（同形状同秩）")
    print("-" * 84)
    for name, pack in domains.items():
        rnd_J, rnd_ec = [], []
        np.random.seed(42)
        # Reuse cached coords instead of recomputing DCT on W every time.
        # 复用已缓存的坐标，避免对同一矩阵重复做 DCT。
        for W, cs_real in zip(pack["ws"][:16], pack["coords"][:16]):
            R = random_lowrank_like(W, pack["r"])
            ec_r, _, _, cs_r = layer_metrics(R, args.k)
            rnd_ec.append(ec_r)
            rnd_J.append(jaccard(cs_real, cs_r))
        print(f"  {name:<14}J(real,random)={np.mean(rnd_J):.4f}   "
              f"EC_real={np.mean(pack['ec']):.4f}  EC_random={np.mean(rnd_ec):.4f}")

    print(f"\n[4/4] 判定")
    print("=" * 84)
    signal = (intra_mean > inter_mean + 0.02) and (p_perm < 0.05)
    print("  🎯 域谱身份存在 → H0（修正版）成立，走 Fork A / B" if signal
          else "  ⚠️  未检测到域谱身份 → 考虑转 Fork D（方法学否定性发现）")
    print("=" * 84)

    out = {
        "k": args.k,
        "per_domain": {n: {"EC_mean": float(np.mean(p["ec"])),
                           "EC_std": float(np.std(p["ec"])),
                           "H_mean": float(np.mean(p["H"])),
                           "low_mean": float(np.mean(p["low"])),
                           "J_intra": intra[n]} for n, p in domains.items()},
        "J_inter": inter_mean, "J_intra": intra_mean,
        "delta": intra_mean - inter_mean, "perm_p": p_perm, "signal": bool(signal),
    }
    path = os.path.join(REP, "e0b_spectral.json")
    json.dump(out, open(path, "w"), indent=2, ensure_ascii=False)
    print(f"💾 saved -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
