#!/usr/bin/env bash
# ============================================================
# FinMLLM / download_data.sh
# Download all datasets through hf-mirror; failures never abort the run.
# 通过 hf-mirror 下载全部数据集；单个失败不中断整体。
#
# Author : Raymond Xiaohu Fan
# Note   : Patience pays: 20GB over a mirror beats re-running an experiment. / 慢一点下载，总比重跑实验强。
# Updated: 2026-10-19
# ============================================================

# Download all datasets (works in no-GPU mode). Route through hf-mirror;
# a failed item is logged to failed.txt and never aborts the run.
# 下载全部数据集（无卡模式可跑）。走 hf-mirror，失败不中断，记录到 failed.txt
# Usage / 用法： bash scripts/download_data.sh
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
export HF_HOME="${HF_HOME:-$PROJ/shared/hf_home}"
DATA="$PROJ/data/raw"
FAILED="$DATA/failed.txt"
mkdir -p "$DATA"; : > "$FAILED"

python -m pip install -q --upgrade huggingface_hub datasets 2>/dev/null || true

try_dl () {
  local repo="$1"; local sub="$2"; local kind="${3:-dataset}"
  local t0=$SECONDS
  echo "---- [$(date '+%F %T')] 下载 $repo -> $DATA/$sub"
  if [ "$kind" = "model" ]; then
    huggingface-cli download "$repo" --local-dir "$DATA/$sub" --resume-download 2>/dev/null \
      || python -c "from huggingface_hub import snapshot_download as s; s(repo_id='$repo', local_dir='$DATA/$sub')" 2>/dev/null \
      || { echo "$(date '+%F %T')|$repo|model_download_failed" | tee -a "$FAILED"; return 1; }
  else
    python - "$repo" "$DATA/$sub" <<'PY' 2>>"$DATA/.dl_err.log" || { echo "$(date '+%F %T')|$repo|dataset_download_failed" | tee -a "$FAILED"; return 1; }
import sys
from datasets import load_dataset
repo, out = sys.argv[1], sys.argv[2]
ds = load_dataset(repo)
ds.save_to_disk(out)
print("OK", repo, {k: len(v) for k, v in ds.items()})
PY
  fi
  echo "✅ [$(date '+%F %T')] $repo done in $((SECONDS-t0))s"
}

echo "=== A. 情感三件套（E1 主任务） ==="
try_dl "takala/financial_phrasebank"               "fpb"          || true
try_dl "TheFinAI/fiqa-sentiment-classification"    "fiqa_sa"      || true
try_dl "zeroshot/twitter-financial-news-sentiment" "tfns"         || true

echo "=== B. 数值推理（E1 辅助） ==="
try_dl "dreamerdeo/finqa"                          "finqa"        || true

echo "=== C. PIXIU/FLARE 汇总台（可选） ==="
try_dl "TheFinAI/flare-sm-acl"                     "flare_sm_acl" || true

echo "=== D. EDGAR 10-K（业务线条线语料，体积较大） ==="
try_dl "astr010/sec-10k-markdown-compressed"       "edgar_10k"    || true

echo "=== E. 主基座模型（无卡也能下，约 15GB） ==="
if [ "${SKIP_MODEL:-0}" != "1" ]; then
  try_dl "Qwen/Qwen2.5-7B" "$HF_HOME/hub/Qwen2.5-7B" model || true
else
  echo "⏭️  跳过模型下载（SKIP_MODEL=1）"
fi

echo ""
echo "=== 下载汇总 ==="
du -sh "$DATA"/* 2>/dev/null | sort -h || true
if [ -s "$FAILED" ]; then
  echo "⚠️ 以下资源下载失败，需手动处理："; cat "$FAILED"
else
  echo "🎉 全部下载成功"
fi
