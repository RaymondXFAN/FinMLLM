#!/usr/bin/env python3
# ============================================================
# FinMLLM / build_v2_corpus.py
# V2 corpus builder using only paths we KNOW work on this machine:
#   bank       <- Banking77 CSV (GitHub)
#   securities <- local FiQA-SA CSVs (already on disk)
#   regulator  <- SEC press releases (HTML)
# Insurance has no reachable public source right now, so it is optional.
# V2 语料构建，只用本机验证可用的路径：
#   银行 <- Banking77 CSV（GitHub）；证券 <- 本地已有的 FiQA-SA CSV；
#   监管 <- SEC 新闻稿（HTML）。保险暂无可达公开源，设为可选。
#
# Author : Raymond Xiaohu Fan
# Note   : Three registers beat three copies of the same template.
#          三种文体，胜过三份同一个模板。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/build_v2_corpus.py
# ============================================================
import os, json, re, html, glob, csv, io, urllib.request

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
OUT = os.path.join(ROOT, "data", "unified_v2")
RAW = os.path.join(ROOT, "data", "raw_v2")
os.makedirs(OUT, exist_ok=True); os.makedirs(RAW, exist_ok=True)

UA = "Mozilla/5.0 (FinMLLM academic research)"


def get(url, binary=False, timeout=40):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
        return data if binary else data.decode("utf-8", errors="ignore")


def chunk(text, size=1200, overlap=150):
    out = []
    for i in range(0, max(1, len(text) - overlap), size - overlap):
        p = text[i:i + size].strip()
        if len(p) >= 120:
            out.append(p)
    return out


def pack_utterances(texts, target=1000):
    """Pack many short utterances into ~target-char blocks.
    短句拼接成长块：CPT 需要连续上下文，单条 30 字符的客服句学不到文体。
    """
    blocks, cur, cur_len = [], [], 0
    for t in texts:
        cur.append(t); cur_len += len(t) + 1
        if cur_len >= target:
            blocks.append(" ".join(cur)); cur, cur_len = [], 0
    if cur and cur_len > 200:
        blocks.append(" ".join(cur))
    return blocks


def dump(domain, rows):
    p = os.path.join(OUT, f"{domain}.jsonl")
    with open(p, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  ✅ {domain}: {len(rows)} chunks -> {p}")
    return len(rows)


# ---------- bank: Banking77 CSV (customer-service utterances) ----------
def build_bank():
    dest = os.path.join(RAW, "banking77_train.csv")
    if not os.path.exists(dest) or os.path.getsize(dest) < 10000:
        urls = [
            "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/master/banking_data/train.csv",
            "https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/master/banking_data/test.csv",
        ]
        ok = False
        for u in urls:
            try:
                raw = get(u)
                if len(raw) > 10000:
                    open(dest, "w", encoding="utf-8").write(raw)
                    print(f"  downloaded {os.path.basename(u)} ({len(raw)/1024:.0f} KB)")
                    ok = True
                    break
            except Exception as e:
                print(f"  ❌ {type(e).__name__}: {u}")
        if not ok:
            return 0
    texts = []
    with open(dest, encoding="utf-8", errors="ignore") as f:
        for r in csv.DictReader(f):
            t = (r.get("text") or r.get("utterance") or "").strip()
            if len(t) >= 10:
                texts.append(t)
    blocks = pack_utterances(texts, target=1000)
    rows = [{"id": f"bank-{i}", "text": b, "domain": "bank",
             "source": "banking77-packed", "split": "train"} for i, b in enumerate(blocks)]
    print(f"  {len(texts)} utterances -> {len(rows)} packed blocks")
    return dump("bank", rows)


# ---------- securities: FinQA financial-report narratives (long paragraphs) ----------
def build_securities():
    """Use FinQA's pre_text/post_text: genuine financial-report prose, not tweets.
    用 FinQA 的 pre_text/post_text —— 真正的财报叙述段，而不是推文短句。
    """
    files = glob.glob(os.path.join(ROOT, "data", "raw", "finqa_files", "*.json"))
    if not files:
        print("  ⚠️  no finqa json; run the FinQA download first")
        return 0
    blocks = []
    for f in files:
        try:
            data = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        for item in data:
            parts = []
            for key in ("pre_text", "post_text"):
                v = item.get(key)
                if isinstance(v, list):
                    parts.extend(str(x) for x in v)
                elif isinstance(v, str):
                    parts.append(v)
            txt = " ".join(parts).strip()
            if len(txt) >= 400:
                blocks.append(txt)
    rows = []
    for b in blocks:
        for c in chunk(b, size=1200, overlap=150):
            rows.append({"id": f"sec-{len(rows)}", "text": c, "domain": "securities",
                         "source": "finqa-narrative", "split": "train"})
    print(f"  {len(blocks)} report narratives -> {len(rows)} blocks")
    return dump("securities", rows)


# ---------- regulator: Federal Register API (structured, version-proof) ----------
def strip_html(raw):
    raw = re.sub(r"<script.*?</script>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<style.*?</style>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    raw = re.sub(r"[ \t\xa0]+", " ", raw)
    return re.sub(r"\n\s*\n+", "\n", raw).strip()


def build_regulator():
    """Federal Register API gives structured metadata + full-text URLs.
    Unlike scraping an index page, this does not break when the site is redesigned.
    Federal Register API 给结构化元数据和全文链接，不像爬索引页那样一改版就废。
    """
    api = ("https://www.federalregister.gov/api/v1/documents.json"
           "?conditions%5Bagencies%5D%5B%5D=securities-and-exchange-commission"
           "&per_page=100&order=newest"
           "&fields%5B%5D=title&fields%5B%5D=body_html_url&fields%5B%5D=publication_date")
    try:
        meta = json.loads(get(api))
    except Exception as e:
        print(f"  ❌ API failed: {type(e).__name__}")
        return 0

    docs = [r for r in meta.get("results", []) if r.get("body_html_url")]
    print(f"  API returned {len(docs)} documents with full text")

    rows = []
    for i, r in enumerate(docs):
        try:
            txt = strip_html(get(r["body_html_url"], timeout=40))
        except Exception:
            continue
        paras = [p for p in txt.split("\n") if len(p.strip()) >= 180]
        if not paras:
            continue
        body = "\n".join(paras)
        for c in chunk(body, size=1200, overlap=150):
            rows.append({"id": f"reg-{len(rows)}", "text": c, "domain": "regulator",
                         "source": r["body_html_url"], "split": "train"})
        if (i + 1) % 20 == 0:
            print(f"    {i+1}/{len(docs)} docs -> {len(rows)} chunks")
    if not rows:
        print("  ⚠️  regulator still empty")
        return 0
    return dump("regulator", rows)


if __name__ == "__main__":
    print("=" * 74)
    print(" V2 CORPUS BUILDER / 异构语料构建")
    print("=" * 74)
    total = 0
    for name, fn in [("bank", build_bank), ("securities", build_securities),
                     ("regulator", build_regulator)]:
        print(f"\n### {name}")
        try:
            total += fn()
        except Exception as e:
            print(f"  ❌ {type(e).__name__}: {e}")
    print("\n" + "-" * 74)
    print(f" total chunks: {total}")
    # Guard: reject domains that are too small or too short to train on.
    # 下限检查：太少的域直接标记为不可用。
    import glob as _g
    for f in sorted(_g.glob(os.path.join(OUT, "*.jsonl"))):
        lines = open(f, encoding="utf-8").read().strip().split("\n")
        lens = [len(json.loads(x).get("text", "")) for x in lines if x.strip()]
        avg = sum(lens) / len(lens) if lens else 0
        flag = "✅" if (len(lines) >= 150 and avg >= 400) else "⚠️ 数据不足/过短"
        print(f"  {os.path.basename(f):<22}{len(lines):>6} blocks  avg_len={avg:>7.0f}  {flag}")
    print(" 已有 / available:", sorted(os.path.basename(x) for x in glob.glob(os.path.join(OUT, "*.jsonl"))))
    print("\nNext / 下一步:")
    print("  export BASE_MODEL=/root/autodl-tmp/models/Qwen2.5-3B")
    print("  for d in bank securities regulator; do")
    print("    python scripts/train_domain.py --data_file data/unified_v2/$d.jsonl \\")
    print("      --limit 3000 --out ckpts_v2/${d}_qlora_s42")
    print("  done")
    print("  python scripts/e0c_kscan.py --ckpt_dir ckpts_v2")
