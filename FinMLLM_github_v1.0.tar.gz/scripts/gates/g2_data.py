#!/usr/bin/env python3
# ============================================================
# FinMLLM / g2_data.py
# G2 data pipeline self-check: loadability, labels, lengths, domain coverage.
# G2 数据管线自检：可加载性、标签、长度分布、业务线覆盖。
#
# Author : Raymond Xiaohu Fan
# Note   : Look at your data before you look at your loss. / 先看数据，再看 loss。
# Updated: 2026-10-19
# ============================================================

"""G2 · 数据管线自检（无卡可跑）。

检查：各数据集是否可加载、样本量、标签分布、文本长度、tokenize 后长度分布。
判定：至少 FPB 可用 + 四条业务线（或可替代的分域来源）样本数 > 0。
"""
import os, sys, json, glob
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
DATA = os.path.join(ROOT, "data")
ok_all = True

def note(ok, msg):
    global ok_all
    ok_all &= ok
    print(f"{'✅' if ok else '⚠️ '} {msg}")

def try_load_ds(path):
    try:
        from datasets import load_from_disk
        return load_from_disk(path)
    except Exception as e:
        return None

def describe(name, path):
    if not os.path.isdir(path):
        note(False, f"{name}: 目录不存在 -> {path}")
        return None
    ds = try_load_ds(path)
    if ds is None:
        note(False, f"{name}: 加载失败（可能不是 datasets 格式）")
        return None
    splits = list(ds.keys()) if hasattr(ds, "keys") else ["train"]
    total = 0
    detail = []
    for s in splits:
        d = ds[s]
        total += len(d)
        cols = d.column_names
        detail.append(f"{s}={len(d)}")
    note(total > 0, f"{name}: {total} 条 ({', '.join(detail)}) 字段={cols[:8]}")
    # 文本长度分布
    txt_col = next((c for c in ("text", "sentence", "question", "content", "mdna", "input") if c in cols), None)
    if txt_col:
        sample = ds[splits[0]].select(range(min(200, len(ds[splits[0]]))))
        lens = [len(str(t)) for t in sample[txt_col]]
        print(f"    ↳ 文本长度: mean={np.mean(lens):.0f} p95={np.percentile(lens,95):.0f} max={max(lens)}")
    return ds

if __name__ == "__main__":
    print("=" * 70)
    print("G2 · 数据管线自检（以 unified jsonl 为准 / unified jsonl is the source of truth）")
    print("=" * 70)

    # ---- 1) Unified training data / 统一后的训练数据 ----
    uni = os.path.join(DATA, "unified")
    required = {"fpb": 4000, "fiqa_sa": 900, "finqa": 7000, "tfns": 9000}
    print("\n[1/3] Unified jsonl / 统一数据")
    got = {}
    for name, floor in required.items():
        f = os.path.join(uni, f"{name}.jsonl")
        if not os.path.exists(f):
            note(False, f"{name}: missing {f}")
            got[name] = 0
            continue
        n = 0
        lens = []
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                n += 1
                if n <= 300:
                    try:
                        lens.append(len(json.loads(line).get("text", "")))
                    except Exception:
                        pass
        got[name] = n
        ok = n >= floor
        note(ok, f"{name}: {n} rows (floor {floor})" + (f"  len_mean={sum(lens)/len(lens):.0f}" if lens else ""))

    # ---- 2) Business lines / 业务线 ----
    print("\n[2/3] Business lines / 业务线")
    dom_dir = os.path.join(DATA, "domains")
    dom_counts = {}
    for d in ["bank", "insurance", "securities", "regulator"]:
        f = os.path.join(dom_dir, f"{d}.jsonl")
        n = sum(1 for _ in open(f, encoding="utf-8")) if os.path.exists(f) else 0
        dom_counts[d] = n
        if d == "regulator":
            print(f"ℹ️  regulator: {n} rows (optional for now / 暂为可选)")
        elif n == 0:
            # A single empty line is a warning, not a hard failure; the real
            # gate is "at least 2 of 3 non-empty" below.
            # 单个业务线为空只警告；真正的门槛是下面"3 中至少 2 个非空"。
            print(f"⚠️  {d}: 0 rows (will block later / 后续实验会受影响)")
        else:
            note(True, f"{d}: {n} rows")
    nonempty = sum(1 for d in ["bank", "insurance", "securities"] if dom_counts[d] > 0)
    note(nonempty >= 2, f"non-empty business lines / 非空业务线: {nonempty}/3")

    # ---- 3) Raw files (informational only) / 原始文件（仅提示） ----
    print("\n[3/3] Raw files (informational) / 原始文件（仅供参考）")
    raw = os.path.join(DATA, "raw")
    if os.path.isdir(raw):
        for d in sorted(os.listdir(raw)):
            p = os.path.join(raw, d)
            if os.path.isdir(p):
                nf = sum(len(fs) for _, _, fs in os.walk(p))
                sz = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(p) for f in fs) / 1024**2
                print(f"  · {d:<18}{nf:>5} files  {sz:>8.1f} MB")

    print("-" * 70)
    print("🎉 G2 PASS" if ok_all else "⚠️ G2 未全通过（见上方 ❌ 项）")
    raise SystemExit(0 if ok_all else 4)
