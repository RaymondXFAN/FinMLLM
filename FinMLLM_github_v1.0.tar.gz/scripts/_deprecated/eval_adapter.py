#!/usr/bin/env python3
# ============================================================
# FinMLLM / eval_adapter.py
# Evaluate any adapter on financial classification tasks. This is the
# accuracy half of the compression-accuracy-cost frontier.
# 在金融分类任务上评测任意 adapter —— 这是"压缩-精度-成本"前沿里的精度半边。
#
# Author : Raymond Xiaohu Fan
# Note   : No training needed. Just load, predict, count. / 不用训练，加载、预测、计数即可。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/eval_adapter.py --dataset fpb --adapter ckpts/bank_qlora_s42 --limit 300
#   python scripts/eval_adapter.py --dataset fiqa --adapter ckpts/insurance_qlora_s42 --limit 300
#   python scripts/eval_adapter.py --dataset fpb --base_only --limit 300   # baseline
# ============================================================
import os, sys, json, glob, argparse, time
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)

LABELS = ["negative", "neutral", "positive"]

PROMPT = ("Classify the sentiment of the following financial sentence.\n"
          "Sentence: {}\n"
          "Answer with exactly one word (negative, neutral, or positive):")


def load_rows(dataset, limit, seed=42):
    """Read unified jsonl and normalize labels to {negative,neutral,positive}.
    读取 unified jsonl，把标签统一到三分类。"""
    path = os.path.join(ROOT, "data", "unified", f"{dataset}.jsonl")
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            t = str(r.get("text", "")).strip()
            lab = str(r.get("label", "")).strip().lower()
            if not t or lab not in LABELS:
                continue
            rows.append((t, lab))
    if limit and len(rows) > limit:
        rng = np.random.RandomState(seed)
        idx = rng.choice(len(rows), limit, replace=False)
        rows = [rows[i] for i in idx]
    return rows


def build_model(base, adapter=None):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                             bnb_4bit_use_double_quant=True,
                             bnb_4bit_compute_dtype=torch.bfloat16)
    tok = AutoTokenizer.from_pretrained(base, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        base, quantization_config=bnb, device_map={"": 0}, trust_remote_code=True)
    if adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, adapter)
    model.eval()
    return tok, model


def predict(tok, model, text, max_new=5):
    import torch
    msg = PROMPT.format(text[:800])
    inputs = tok(msg, return_tensors="pt", truncation=True, max_length=1024).to(model.device)
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new, do_sample=False,
                             pad_token_id=tok.eos_token_id)
    gen = tok.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip().lower()
    for lab in LABELS:
        if lab in gen:
            return lab
    return "unknown"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="fpb", choices=["fpb", "fiqa_sa", "tfns"])
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--base_only", action="store_true")
    ap.add_argument("--base", default=os.environ.get("BASE_MODEL", "/root/autodl-tmp/models/Qwen2.5-3B"))
    ap.add_argument("--limit", type=int, default=300)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    rows = load_rows(args.dataset, args.limit)
    print("=" * 72)
    print(f" EVAL | dataset={args.dataset} | n={len(rows)}")
    print(f" adapter={'(base only)' if args.base_only else args.adapter}")
    print("=" * 72)
    if not rows:
        print("❌ 没有可用样本（检查 label 是否为 negative/neutral/positive）")
        return 2

    tok, model = build_model(args.base, None if args.base_only else args.adapter)

    conf = {a: {b: 0 for b in LABELS + ["unknown"]} for a in LABELS}
    t0 = time.time()
    for i, (text, gold) in enumerate(rows):
        pred = predict(tok, model, text)
        conf[gold][pred] = conf[gold].get(pred, 0) + 1
        if (i + 1) % 50 == 0:
            acc = sum(conf[a][a] for a in LABELS) / (i + 1)
            print(f"  {i+1}/{len(rows)}  running_acc={acc:.3f}  {time.time()-t0:.0f}s", flush=True)

    correct = sum(conf[a][a] for a in LABELS)
    acc = correct / len(rows)
    print("\n" + "-" * 72)
    print(f" accuracy = {acc:.4f}  ({correct}/{len(rows)})   dur={time.time()-t0:.0f}s")
    print(f"{'gold\\pred':<12}" + "".join(f"{b:>10}" for b in LABELS + ["unknown"]))
    for a in LABELS:
        print(f"{a:<12}" + "".join(f"{conf[a].get(b,0):>10}" for b in LABELS + ["unknown"]))

    # macro F1 / 宏平均 F1
    f1s = []
    for a in LABELS:
        tp = conf[a][a]
        fp = sum(conf[g][a] for g in LABELS if g != a)
        fn = sum(conf[a][p] for p in LABELS + ["unknown"] if p != a)
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * prec * rec / (prec + rec) if prec + rec else 0.0)
    print(f" macro-F1 = {np.mean(f1s):.4f}")

    out = {"dataset": args.dataset, "adapter": args.adapter, "base_only": args.base_only,
           "n": len(rows), "accuracy": acc, "macro_f1": float(np.mean(f1s)),
           "confusion": conf, "dur_sec": round(time.time() - t0, 1)}
    p = args.out or os.path.join(REP, f"eval_{args.dataset}_{os.path.basename(args.adapter or 'base')}.json")
    json.dump(out, open(p, "w"), indent=2, ensure_ascii=False)
    print(f"💾 saved -> {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
