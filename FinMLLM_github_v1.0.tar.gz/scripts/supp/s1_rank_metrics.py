#!/usr/bin/env python3
# ============================================================
# FinMLLM / supp / s1_rank_metrics.py
# CPU-only spectral audit of every LoRA adapter in the project.
# 纯 CPU 的全项目 LoRA adapter 谱审计 —— 不占 GPU，可与训练并行。
#
# What it answers / 它回答什么:
#   A1  three effective-rank metrics of different Rényi order per matrix
#       三种不同阶的有效秩度量（stable rank / PR / entropy-erank / 能量秩）
#   A2  Gaussian noise baseline of the SAME shape and parameterisation
#       同形状同参数化的高斯噪声基线（没有它，"有效秩低"不构成证据）
#   A3  subspace consistency between the full spectrum and r/2, r/4, ..., r/16
#       全谱 vs 各级截断的子空间一致性（回答"你是不是剪掉了 intruder dimension"）
#   A4  per-layer, per-module distribution of effective rank
#       逐层 / 逐模块的有效秩分布（对标 SVD-LLM V2 的层间非均匀秩分配）
#
# Author : Raymond Xiaohu Fan
# Note   : Random matrices are low-rank too. That is why we measure the baseline.
#          随机矩阵也低秩 —— 所以我们才必须量基线。
# Updated: 2026-10-25
#
# Usage / 用法:
#   python scripts/supp/s1_rank_metrics.py
#   python scripts/supp/s1_rank_metrics.py --include ckpts_sft --include ckpts_sft3
# ============================================================
import os, sys, json, argparse, time, re
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from supp_common import (PROJ, REP, probe, find_adapters, load_lora_pairs, lora_scale,
                         singular_values, rank_metrics, noise_baseline, subspace_diagnostics,
                         dump_json, gpu_snapshot)

_FLOAT_KEYS = ["stable_rank", "participation_ratio", "erank_entropy",
               "top1_share", "spectral_norm", "fro_norm"]
_INT_KEYS = ["n50", "n90", "n99", "n_sv"]
_TRUNC = [2, 4, 8, 16]   # truncate to r/k / 截断到 r/k


def layer_index(key):
    """'...layers.12.self_attn.q_proj.lora_A.weight' -> (12, 'q_proj')"""
    m = re.search(r"layers\.(\d+)\.", key)
    li = int(m.group(1)) if m else -1
    mod = "?"
    for cand in ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"):
        if cand in key:
            mod = cand
            break
    return li, mod


def short_name(path):
    rel = os.path.relpath(path, PROJ)
    return rel.replace(os.sep, "/")


def audit_one(adapter_dir, noise_cache, noise_draws):
    cfg, pairs = load_lora_pairs(adapter_dir)
    scale, r_cfg = lora_scale(cfg)
    if not pairs:
        return None
    probe(f"  {short_name(adapter_dir)}: r={r_cfg} scale={scale:.2f} matrices={len(pairs)}")

    recs = []
    trunc_acc = {k: [] for k in _TRUNC}
    for kA, A, B in pairs:
        s = singular_values(A, B, scale)
        m = rank_metrics(s)
        if not m:
            continue
        li, mod = layer_index(kA)
        recs.append({"layer": li, "module": mod, "key": kA[-56:], **m})

        # ---- A3: what exactly gets thrown away at each truncation ----
        for kdiv in _TRUNC:
            rk = max(1, r_cfg // kdiv)
            d = subspace_diagnostics(s, rk)
            if d:
                trunc_acc[kdiv].append(d)

    if not recs:
        return None

    agg = {}
    for key in _FLOAT_KEYS + _INT_KEYS:
        v = np.array([r[key] for r in recs], dtype=float)
        agg[key] = {"mean": float(v.mean()), "median": float(np.median(v)),
                    "p05": float(np.percentile(v, 5)), "p95": float(np.percentile(v, 95)),
                    "min": float(v.min()), "max": float(v.max())}

    # ---- A2: noise baseline (cached per shape) ----
    shapes = {}
    for kA, A, B in pairs:
        key = (B.shape[0], A.shape[1], A.shape[0])
        shapes[key] = shapes.get(key, 0) + 1
    noise = {}
    for key in shapes:
        if key not in noise_cache:
            noise_cache[key] = noise_baseline(key[0], key[1], key[2],
                                              n_draws=noise_draws, seed=hash(key) % 9999)
        noise[str(key)] = {**_cap(noise_cache[key]), "n_matrices": shapes[key]}

    # ratio vs the dominant shape's noise baseline / 相对主形状噪声基线的比值
    dom = str(max(shapes, key=shapes.get))
    ratio = {}
    if noise.get(dom):
        for key in _FLOAT_KEYS:
            if key in noise[dom] and noise[dom][key]["mean"] > 1e-12:
                ratio[key] = agg[key]["mean"] / noise[dom][key]["mean"]

    # ---- A4: per-layer profile ----
    layers = {}
    for rec in recs:
        li = rec["layer"]
        layers.setdefault(li, []).append(rec)
    prof = {}
    for li, rs in sorted(layers.items()):
        prof[str(li)] = {
            "n": len(rs),
            "stable_rank": float(np.mean([x["stable_rank"] for x in rs])),
            "participation_ratio": float(np.mean([x["participation_ratio"] for x in rs])),
            "erank_entropy": float(np.mean([x["erank_entropy"] for x in rs])),
            "n90": float(np.mean([x["n90"] for x in rs])),
        }
    mods = {}
    for rec in recs:
        mods.setdefault(rec["module"], []).append(rec)
    mod_prof = {m: {"n": len(rs),
                    "stable_rank": float(np.mean([x["stable_rank"] for x in rs])),
                    "n90": float(np.mean([x["n90"] for x in rs]))}
                for m, rs in mods.items()}

    trunc = {}
    for kdiv, v in trunc_acc.items():
        if not v:
            trunc[f"1/{kdiv}"] = {"n": 0}
            continue
        gaps = [x["spectral_gap"] for x in v if np.isfinite(x["spectral_gap"])]
        trunc[f"1/{kdiv}"] = {
            "n": len(v),
            "energy_dropped_mean": float(np.mean([x["energy_dropped"] for x in v])),
            "dropped_max_over_s1_mean": float(np.mean([x["dropped_max_over_s1"] for x in v])),
            "spectral_gap_median": float(np.median(gaps)) if gaps else None,
        }

    return {"name": short_name(adapter_dir), "path": adapter_dir,
            "rank_cfg": r_cfg, "scale": scale, "n_matrices": len(recs),
            "aggregate": agg, "noise_baseline": noise, "ratio_vs_noise": ratio,
            "truncation_consistency": trunc,
            "per_layer": prof, "per_module": mod_prof,
            "matrix_records": recs}


def _cap(d):
    """Keep the noise baseline JSON small. / 控制噪声基线体积。"""
    if not d:
        return {}
    return {k: {kk: vv for kk, vv in v.items() if kk in ("mean", "std", "p05", "p95")}
            for k, v in d.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--include", action="append", default=None,
                    help="only adapters under these sub-strings / 只分析路径含这些子串的 adapter")
    ap.add_argument("--noise-draws", type=int, default=20)
    ap.add_argument("--out", default=os.path.join(REP, "supp_rank_metrics.json"))
    ap.add_argument("--quick", action="store_true", help="first 3 layers only / 只跑前 3 层")
    args = ap.parse_args()

    probe("=" * 78)
    probe("A1-A4 CPU SPECTRAL AUDIT / 纯 CPU 谱审计   (GPU untouched / 不占 GPU)")
    probe("=" * 78)
    gpu_snapshot()

    all_adapters = find_adapters()
    if args.include:
        all_adapters = [a for a in all_adapters if any(s in a for s in args.include)]
    probe(f"found {len(all_adapters)} adapters under {PROJ}")
    for a in all_adapters:
        probe(f"   · {short_name(a)}")

    noise_cache, results, failed = {}, [], []
    for i, a in enumerate(all_adapters, 1):
        probe(f"[{i}/{len(all_adapters)}] auditing {short_name(a)}")
        t = time.time()
        try:
            r = audit_one(a, noise_cache, args.noise_draws)
            if r is None:
                failed.append({"adapter": short_name(a), "why": "no pairs"})
                continue
            if args.quick:
                r["matrix_records"] = r["matrix_records"][:21]
            results.append(r)
            probe(f"   done in {time.time()-t:.1f}s  stable_rank={r['aggregate']['stable_rank']['mean']:.2f}"
                  f"  n90={r['aggregate']['n90']['mean']:.2f}  ratio_noise="
                  f"{r['ratio_vs_noise'].get('stable_rank', float('nan')):.2f}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            failed.append({"adapter": short_name(a), "why": repr(e)})

    out = {"generated": time.strftime("%Y-%m-%d %H:%M:%S"), "proj": PROJ,
           "n_adapters": len(results), "adapters": results, "failed": failed}

    # ---------------- human-readable summary ----------------
    print()
    print("=" * 96)
    print(" TABLE A1/A2  Effective rank vs configured rank vs NOISE baseline")
    print(" 有效秩 vs 配置秩 vs 噪声基线（ratio<1 才说明真的比随机矩阵更低秩）")
    print("=" * 96)
    hdr = f"{'adapter':<38}{'r_cfg':>6}{'stable':>8}{'PR':>8}{'eRank':>8}{'n90':>6}{'noise':>8}{'ratio':>7}"
    print(hdr)
    print("-" * 96)
    for r in results:
        a = r["aggregate"]
        nz = r["noise_baseline"]
        noise_sr = float("nan")
        if nz:
            k0 = max(nz, key=lambda k: nz[k].get("n_matrices", 0))
            noise_sr = nz[k0].get("stable_rank", {}).get("mean", float("nan"))
        print(f"{r['name']:<38}{r['rank_cfg']:>6}{a['stable_rank']['mean']:>8.2f}"
              f"{a['participation_ratio']['mean']:>8.2f}{a['erank_entropy']['mean']:>8.2f}"
              f"{a['n90']['mean']:>6.2f}{noise_sr:>8.2f}"
              f"{r['ratio_vs_noise'].get('stable_rank', float('nan')):>7.2f}")
    print("-" * 96)
    print(" ratio = adapter stable_rank / same-shape Gaussian noise stable_rank")
    print(" ratio < 1  =>  genuinely lower-rank than chance, not an artefact of construction")
    print(" ratio < 1  =>  真的比随机更低秩，而不是构造使然")

    print()
    print("=" * 96)
    print(" TABLE A3  What gets thrown away under progressive truncation")
    print(" 逐级截断到底丢掉了什么（回答 intruder-dimension 质疑）")
    print("=" * 96)
    print(f"{'adapter':<34}{'cut':>6}{'E_drop':>9}{'max_drop/s1':>13}{'spectral_gap':>14}")
    print("-" * 96)
    for r in results:
        tc = r["truncation_consistency"]
        for kdiv in _TRUNC:
            d = tc.get(f"1/{kdiv}", {})
            if d.get("n", 0) == 0:
                continue
            gap = d.get("spectral_gap_median")
            gaptxt = f"{gap:>14.2f}" if gap is not None else f"{'-':>14}"
            print(f"{r['name']:<34}{'1/'+str(kdiv):>6}{d['energy_dropped_mean']:>9.4f}"
                  f"{d['dropped_max_over_s1_mean']:>13.4f}{gaptxt}")
    print("-" * 96)
    print(" E_drop       = fraction of spectral energy discarded / 被丢弃的能量占比")
    print(" max_drop/s1  = largest discarded sigma over sigma_1 / 被丢的最大奇异值相对 sigma_1")
    print("                 small (<<1) => pure tail, no intruder dimension was harmed")
    print("                 很小说明只是长尾，没有伤到任何 intruder dimension")
    print(" spectral_gap = sigma_{k-1}/sigma_k at the cut / 截断点谱间隙，越大越安全")

    dump_json(out, args.out)
    probe(f"DONE  adapters={len(results)}  failed={len(failed)}", "OK")
    if failed:
        for f in failed:
            probe(f"   FAILED {f['adapter']}: {f['why']}", "WARN")
    return 0


if __name__ == "__main__":
    sys.exit(main())
