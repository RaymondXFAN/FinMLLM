#!/usr/bin/env bash
# ============================================================
# FinMLLM / migrate_data.sh
# Migrate datasets already downloaded elsewhere into the project data disk.
# 把已下载到其他位置的数据集，迁移到数据盘的项目目录下。
#
# Why this exists / 为什么需要它：
#   AutoDL's system disk (/root) is small and shared with everything else.
#   Datasets belong on /root/autodl-tmp — no exceptions. — Raymond Xiaohu Fan
#   AutoDL 的系统盘很小，还和别的东西挤在一起。数据集必须放数据盘，
#   这条没有例外。—— Raymond Xiaohu Fan
#
# Usage / 用法：
#   bash scripts/migrate_data.sh            # dry-run first / 先空跑看看
#   bash scripts/migrate_data.sh --apply    # actually copy / 真复制
# ============================================================
set -uo pipefail

cd "$(dirname "$0")/.."
PROJ="$(pwd)"
RAW="$PROJ/data/raw"
APPLY=0
[ "${1:-}" = "--apply" ] && APPLY=1

echo "============================================================"
echo " FinMLLM data migration / 数据迁移"
echo " Target / 目标目录: $RAW"
echo " Mode   / 模式    : $([ $APPLY -eq 1 ] && echo 'APPLY 实际复制' || echo 'DRY-RUN 仅检查')"
echo "============================================================"
mkdir -p "$RAW"

# Candidate sources / 候选来源（旧项目、HF 缓存、家目录缓存）
CANDIDATES=(
  "/root/FinMeshingLLM/MeshingLLM/data"
  "/root/autodl-tmp/MeshingLLM/data"
  "/root/autodl-tmp/hf_home/hub"
  "$HOME/.cache/huggingface/hub"
  "/root/.cache/huggingface/hub"
)

# Dataset name patterns / 数据集名称特征
KEYS=(fpb fiqa tfns twitter-financial finqa edgar 10-k fineval pixiu flare)

echo ""
echo "[1/3] Scanning candidate locations / 扫描候选位置"
for src in "${CANDIDATES[@]}"; do
  [ -d "$src" ] || continue
  echo "  📂 $src"
  du -sh "$src" 2>/dev/null | sed 's/^/     /'
done

echo ""
echo "[2/3] Matching datasets / 匹配数据集"
FOUND=0
for src in "${CANDIDATES[@]}"; do
  [ -d "$src" ] || continue
  while IFS= read -r d; do
    base="$(basename "$d")"
    lower="$(echo "$base" | tr '[:upper:]' '[:lower:]')"
    for k in "${KEYS[@]}"; do
      if [[ "$lower" == *"$k"* ]]; then
        size=$(du -sh "$d" 2>/dev/null | cut -f1)
        echo "  ✅ $d  ($size)"
        if [ $APPLY -eq 1 ]; then
          # Copy, never move: the old project must stay intact.
          # 只复制不移动：旧项目必须保持原样。
          if [ -e "$RAW/$base" ]; then
            echo "     ⏭️  already exists, skip / 已存在，跳过"
          else
            cp -r "$d" "$RAW/$base" && echo "     ➜ copied to $RAW/$base"
          fi
        fi
        FOUND=$((FOUND+1))
        break
      fi
    done
  done < <(find "$src" -maxdepth 2 -type d 2>/dev/null)
done

echo ""
echo "[3/3] Result / 结果"
echo "  Matched entries / 命中条目: $FOUND"
if [ $APPLY -eq 0 ]; then
  echo "  ℹ️  Dry-run only. Re-run with --apply to copy."
  echo "  ℹ️  当前只是空跑。确认无误后加 --apply 再执行一次。"
else
  echo "  Current data dir / 当前数据目录："
  du -sh "$RAW"/* 2>/dev/null | sort -h || echo "  (empty)"
fi

echo ""
echo "Next / 下一步: python scripts/prep_data.py"
echo "Reminder / 提醒: never leave large datasets on the system disk. / 大文件永远别留在系统盘。"
