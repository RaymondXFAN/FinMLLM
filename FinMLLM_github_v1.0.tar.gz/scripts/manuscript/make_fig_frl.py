#!/usr/bin/env python3
# FinMLLM / make_fig_frl.py
# FRL 版唯一的图：有效秩比值预测压缩代价。
# The single figure for the short-letter version: does the ratio predict the cost?
# 三个点，一条趋势线。短篇论文只需要一张图，这张是最能打的。
# Three points, one trend. A short letter needs one figure, and this is the one.
# Author: Raymond Xiaohu Fan
import os, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = os.path.join(os.environ.get("PROJ", "/sandbox/workspace/FinMLLM"), "outputs", "figs")
os.makedirs(OUT, exist_ok=True)
M = dict(sage="#8FA68E", clay="#B08968", slate="#6B7280", grid="#E5E1DA", ink="#3D3B38")

plt.rcParams.update({
    "font.family": "serif", "font.size": 9.5,
    "axes.linewidth": 0.8, "axes.edgecolor": "#666",
    "xtick.major.width": 0.7, "ytick.major.width": 0.7,
})

fig, ax = plt.subplots(figsize=(4.4, 3.3))

pts = [("PhraseBank ternary", 0.133, +3.31, "o", M["sage"], (9, 7)),
       ("PhraseBank binary",  0.141, +0.25, "s", M["slate"], (11, -4)),
       ("FiQA-SA",            0.163, -1.23, "^", M["clay"], (-9, -13))]

xs, ys = [], []
for name, r, d, mk, c, off in pts:
    ax.scatter(r, d, s=46, marker=mk, color=c, edgecolor="white", linewidth=0.9, zorder=3)
    ax.annotate(name, (r, d), textcoords="offset points", xytext=off,
                fontsize=8.2, color=c, ha="left" if off[0] > 0 else "right")
    xs.append(r); ys.append(d)

# 趋势线
z = np.polyfit(xs, ys, 1)
xr = np.linspace(0.126, 0.172, 50)
ax.plot(xr, np.polyval(z, xr), ls="--", lw=1.0, color=M["ink"], alpha=0.55, zorder=2)

ax.axhline(0, color="#AAA", lw=0.7, ls=":", zorder=1)
ax.set_xlabel("Effective rank / Gaussian baseline", fontsize=9.2)
ax.set_ylabel("Accuracy change at 16× (pp)", fontsize=9.2)
ax.set_xlim(0.126, 0.172)
ax.set_ylim(-2.2, 4.2)
ax.grid(color=M["grid"], lw=0.6)
ax.set_axisbelow(True)

fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(OUT, f"frl_fig1_ratio_vs_cost.{ext}"), dpi=300,
                bbox_inches="tight")
print("✅ frl_fig1_ratio_vs_cost.png / .pdf")
