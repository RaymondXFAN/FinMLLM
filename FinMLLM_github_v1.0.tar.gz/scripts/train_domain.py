#!/usr/bin/env python3
# ============================================================
# FinMLLM / train_domain.py
# QLoRA continued-pretraining of one business line. This is what produces the
# Delta-W whose spectrum we then dissect in E0.
# 单业务线 QLoRA 继续预训练 —— 产出 E0 要解剖的 Delta-W。
#
# Author : Raymond Xiaohu Fan
# Note   : Train one line at a time, keep every seed separate. / 一条线一条线地训，每个种子各存各的。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/train_domain.py --domain bank --seed 42 --model Qwen/Qwen2.5-3B
#   python scripts/train_domain.py --domain insurance --seed 123 --epochs 3
# ============================================================
import os, sys, json, time, argparse, random
import numpy as np

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from lib_probe import step, probe, trace   # noqa: E402


def load_rows(domain, limit=None, data_file=None):
    # data_file lets you train a control adapter on ANY jsonl (e.g. a general-domain set).
    # data_file 允许你在任意 jsonl 上训练对照 adapter（例如通用域）。
    p = data_file or os.path.join(ROOT, "data", "domains", f"{domain}.jsonl")
    rows = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            t = str(r.get("text", "")).strip()
            if len(t) < 50:      # drop fragments / 丢掉碎样本
                continue
            rows.append(t)
    if limit and len(rows) > limit:
        rows = random.sample(rows, limit)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domain", default=None, choices=[None, "bank", "insurance", "securities", "general"],
                    help="business line, or 'general' for a control adapter / 业务线；general 表示对照")
    ap.add_argument("--data_file", default=None,
                    help="override the jsonl used for training / 指定训练用 jsonl")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--model", default=os.environ.get("BASE_MODEL", "Qwen/Qwen2.5-3B"))
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--limit", type=int, default=3000, help="max samples / 最大样本数")
    ap.add_argument("--max_len", type=int, default=1024)
    ap.add_argument("--bs", type=int, default=4)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    if not args.domain and not args.data_file:
        ap.error("either --domain or --data_file is required / 至少要给一个")
    tag = args.domain or os.path.splitext(os.path.basename(args.data_file))[0]

    random.seed(args.seed); np.random.seed(args.seed)
    import torch
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

    out = args.out or os.path.join(ROOT, "ckpts", f"{tag}_qlora_s{args.seed}")
    os.makedirs(out, exist_ok=True)

    with step("load-data", domain=args.domain):
        texts = load_rows(args.domain, args.limit, args.data_file)
        probe(f"loaded {len(texts)} samples for {tag}")
        assert texts, "no data — run prep_raw.py first"

    with step("load-model", model=args.model):
        tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                 bnb_4bit_use_double_quant=True,
                                 bnb_4bit_compute_dtype=torch.bfloat16)
        model = AutoModelForCausalLM.from_pretrained(
            args.model, quantization_config=bnb, device_map={"": 0}, trust_remote_code=True)
        model = prepare_model_for_kbit_training(model)
        model = get_peft_model(model, LoraConfig(
            r=16, lora_alpha=32, lora_dropout=0.05, bias="none", task_type="CAUSAL_LM",
            target_modules=["q_proj","k_proj","v_proj","o_proj","gate_proj","up_proj","down_proj"]))
        model.print_trainable_parameters()

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr)
    steps_per_epoch = max(1, len(texts) // args.bs)
    total_steps = steps_per_epoch * args.epochs
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(total_steps, 1))

    losses = []
    t_start = time.time()
    model.train()
    with step("train", domain=args.domain, seed=args.seed,
              samples=len(texts), steps=total_steps):
        for ep in range(args.epochs):
            random.shuffle(texts)
            for i in range(steps_per_epoch):
                batch = texts[i * args.bs:(i + 1) * args.bs]
                enc = tok(batch, return_tensors="pt", padding=True, truncation=True,
                          max_length=args.max_len).to("cuda")
                labels = enc["input_ids"].clone()
                labels[enc["attention_mask"] == 0] = -100
                out_ = model(**enc, labels=labels)
                loss = out_.loss
                loss.backward(); opt.step(); opt.zero_grad(set_to_none=True); sched.step()
                losses.append(float(loss.detach()))
                if (i + 1) % 20 == 0:
                    probe(f"ep{ep} step{i+1}/{steps_per_epoch} loss={np.mean(losses[-20:]):.4f} "
                          f"vram={torch.cuda.max_memory_allocated()/1024**3:.2f}GB")

    # Save with the CORRECT API — trainer-level saving was our historical bug.
    # 用正确的 API 保存 —— trainer 层保存是我们踩过的历史坑。
    with step("save-adapter", out=out):
        model.save_pretrained(out)
        tok.save_pretrained(out)

    meta = {
        "domain": tag, "seed": args.seed, "model": args.model,
        "samples": len(texts), "epochs": args.epochs, "steps": total_steps,
        "loss_first": losses[0] if losses else None,
        "loss_last": float(np.mean(losses[-50:])) if losses else None,
        "duration_sec": round(time.time() - t_start, 1),
        "peak_vram_gb": round(torch.cuda.max_memory_allocated() / 1024**3, 2) if torch.cuda.is_available() else None,
        "ts": time.strftime("%F %T"),
    }
    with open(os.path.join(out, "train_meta.json"), "w") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print(f"\n✅ adapter -> {out}")
    print(f"Next / 下一步: python scripts/e0_spectral.py --ckpt_dir {os.path.dirname(out)}")


if __name__ == "__main__":
    main()
