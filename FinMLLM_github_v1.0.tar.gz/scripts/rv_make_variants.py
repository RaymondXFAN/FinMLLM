#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_make_variants.py
# 从原始 adapter 现场生成 mask / randdir 变体，不依赖已删除的 ckpts_supp。
# Rebuild mask and random-direction variants from the source adapters.
#
# 为什么重写：
#   原来的 s2_make_variants.py 依赖 ckpts_supp 目录，那批中间产物已经被清掉。
#   这里直接对 ckpts_sft/fpb_r16 做后处理，逻辑与原来一致：
#     mask    : 把幅值最小的 p% LoRA 参数置零，形状不变（体积不省）
#     randdir : 保持同秩 k，但保留的方向随机挑（隔离"按能量排序"的价值）
#
# Why rewrite:
#   The old script read from ckpts_supp, which no longer exists. This one works
#   straight off ckpts_sft/fpb_r16. Same two operations, nothing else changed.
#
# Author : Raymond Xiaohu Fan
# Usage:
#   python scripts/rv_make_variants.py --src ckpts_sft/fpb_r16 --kind mask --pcts 40,60,80
#   python scripts/rv_make_variants.py --src ckpts_sft/fpb_r16 --kind randdir --ranks 8,4,2,1 --draws 5
# ============================================================
import os, sys, json, shutil, argparse
import numpy as np
import torch
from safetensors.torch import load_file, save_file


def _tag(src):
    return os.path.basename(src.rstrip("/"))


def _pairs(sd):
    """配对 lora_A / lora_B /| pair up A and B modules"""
    out = []
    for k in list(sd.keys()):
        if "lora_A" in k:
            kb = k.replace("lora_A", "lora_B")
            if kb in sd:
                out.append((k, kb))
    return out


def _write(src, sd_new, out_dir, extra_cfg=None):
    os.makedirs(out_dir, exist_ok=True)
    save_file({k: v.contiguous() for k, v in sd_new.items()},
              os.path.join(out_dir, "adapter_model.safetensors"))
    cfg = json.load(open(os.path.join(src, "adapter_config.json"), encoding="utf-8"))
    # 注意：绝对不能往 adapter_config.json 里加自定义键，
    # PEFT 的 LoraConfig 会做严格校验，多一个字段就 TypeError。
    # 变体信息单独写 rv_meta.json。
    if extra_cfg:
        json.dump(extra_cfg, open(os.path.join(out_dir, "rv_meta.json"), "w"),
                  indent=2, ensure_ascii=False)
    json.dump(cfg, open(os.path.join(out_dir, "adapter_config.json"), "w"),
              indent=2, ensure_ascii=False)
    for f in ("tokenizer_config.json", "special_tokens_map.json",
              "tokenizer.json", "vocab.json", "merges.txt"):
        p = os.path.join(src, f)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(out_dir, f))
    sz = os.path.getsize(os.path.join(out_dir, "adapter_model.safetensors")) / 1024**2
    return sz


def build_mask(src, sd, pcts, out_root):
    """把 |w| 最小的 p% 置零。形状不变，所以磁盘体积一分不省。"""
    made = []
    tag = _tag(src)
    for p in pcts:
        new = {k: v.clone() for k, v in sd.items()}
        total_zero = 0
        total = 0
        for ka, kb in _pairs(sd):
            for key in (ka, kb):
                w = new[key].float()
                flat = w.abs().flatten()
                k = int(flat.numel() * p / 100.0)
                if k <= 0:
                    continue
                thr = torch.kthvalue(flat, k).values
                new[key] = torch.where(w.abs() <= thr, torch.zeros_like(w), w).to(sd[key].dtype)
                total_zero += k
                total += flat.numel()
        out = os.path.join(out_root, f"mask_p{p}_{tag}")
        sz = _write(src, new, out, {"rv_variant": f"mask{p}"})
        real = total_zero / max(total, 1) * 100
        made.append(dict(kind="mask", pct=p, realised_pct=round(real, 2),
                         size_mb=round(sz, 1), dir=out))
        print(f"  mask p={p}%  实测零化={real:.2f}%  {sz:.1f}MB  -> {out}")
    return made


def build_randdir(src, sd, ranks, draws, out_root):
    """同秩 k，但保留的方向随机挑。每次抽样用不同种子。"""
    made = []
    tag = _tag(src)
    for k in ranks:
        for d in range(draws):
            rng = np.random.default_rng(20261025 + d * 977)
            new = {k2: v for k2, v in sd.items()
                   if "lora_A" not in k2 and "lora_B" not in k2}
            for ka, kb in _pairs(sd):
                A = sd[ka].float().numpy()          # [r, in]
                B = sd[kb].float().numpy()          # [out, r]
                r = A.shape[0]
                kk = min(k, r)
                # QR-core: 在 r×r 空间做 SVD，不重建稠密矩阵
                Qb, Rb = np.linalg.qr(B)
                Qa, Ra = np.linalg.qr(A.T)
                M = Rb @ Ra.T                        # [r,r]
                Um, S, Vmt = np.linalg.svd(M, full_matrices=False)
                idx = np.sort(rng.choice(len(S), size=kk, replace=False))
                Bn = (Qb @ Um[:, idx]) * np.sqrt(S[idx])
                An = np.sqrt(S[idx])[:, None] * (Vmt[idx] @ Qa.T)
                new[ka] = torch.from_numpy(np.ascontiguousarray(An, dtype=np.float32))
                new[kb] = torch.from_numpy(np.ascontiguousarray(Bn, dtype=np.float32))
            out = os.path.join(out_root, f"randdir_r{k}_d{d}_{tag}")
            sz = _write(src, new, out, {"rv_variant": f"randdir_r{k}_d{d}", "r": kk})
            made.append(dict(kind="randdir", rank=k, draw=d, size_mb=round(sz, 1), dir=out))
            print(f"  randdir r={k} draw={d}  {sz:.1f}MB  -> {out}")
    return made


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--kind", required=True, choices=["mask", "randdir"])
    ap.add_argument("--pcts", default="40,60,80")
    ap.add_argument("--ranks", default="8,4,2,1")
    ap.add_argument("--draws", type=int, default=5)
    ap.add_argument("--out-root", default="ckpts_supp")
    a = ap.parse_args()

    sd = load_file(os.path.join(a.src, "adapter_model.safetensors"))
    print(f"src={a.src}  张量 {len(sd)} 个  矩阵对 {len(_pairs(sd))} 组")

    os.makedirs(a.out_root, exist_ok=True)
    if a.kind == "mask":
        made = build_mask(a.src, sd, [int(x) for x in a.pcts.split(",")], a.out_root)
    else:
        made = build_randdir(a.src, sd, [int(x) for x in a.ranks.split(",")],
                             a.draws, a.out_root)

    mp = os.path.join(a.out_root, f"_manifest_{a.kind}_{_tag(a.src)}.json")
    json.dump(made, open(mp, "w"), indent=2)
    print(f"\n共 {len(made)} 个，清单 -> {mp}")


if __name__ == "__main__":
    sys.exit(main())
