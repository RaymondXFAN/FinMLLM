#!/usr/bin/env bash
# ============================================================
# FinMLLM / init_forks.sh
# Create the four fork workspaces (A/B/C/D) sharing one dataset.
# 创建四条 fork 工作区（A/B/C/D），共享同一份数据。
#
# Author : Raymond Xiaohu Fan
# Note   : Four forks, one truth: data stays shared. / 四条分支一个原则：数据共享。
# Updated: 2026-10-19
# ============================================================

# 初始化四条 fork 工作区（幂等：已存在不覆盖）
set -euo pipefail
cd "$(dirname "$0")/.."
PROJ="$(pwd)"

declare -A DESC
DESC[A_flagship]="Fork A 旗舰｜频谱经济学：测-传-省三位一体｜目标刊 Financial Innovation"
DESC[B_method]="Fork B 方法型｜Domain-Conditioned Spectral Budgeting｜目标刊 KBS/ESWA/IP&M"
DESC[C_economics]="Fork C 经济学型｜轻量化金融LLM可及性经济学｜目标刊 IRFA/PBFJ/FRL"
DESC[D_framework]="Fork D 保底｜金融LLM高效部署评估框架｜目标刊 FI Methodology/TFSC"

for f in A_flagship B_method C_economics D_framework; do
  D="forks/$f"
  mkdir -p "$D"/{configs,ckpts,drafts,outputs/{tables,figs,logs}}

  # 数据软链（不复制）
  if [ ! -e "$D/data" ]; then
    ln -s ../../data "$D/data"
  fi

  # 继承全局配置（不覆盖已有）
  if [ ! -f "$D/configs/exp_config.yaml" ] && [ -f configs/exp_config.yaml ]; then
    cp configs/exp_config.yaml "$D/configs/exp_config.yaml"
  fi

  # 写 fork 说明（不覆盖）
  if [ ! -f "$D/README.md" ]; then
    cat > "$D/README.md" <<EOF
# ${DESC[$f]}

- 数据：软链到 ../../data（只读，不要在此目录写数据）
- 配置：本目录 configs/ 覆盖全局 configs/
- 产出：outputs/{tables,figs,logs}
- 文稿：drafts/

## 状态
- [ ] 实验启动
- [ ] E0 谱诊断通过
- [ ] 主表完成
- [ ] 初稿
EOF
  fi
  echo "✅ $f 就绪"
done

echo ""
echo "目录树："
find forks -maxdepth 2 -type d | sort
echo ""
echo "提醒：四条 fork 共享 data/，各自独立 ckpts/ 与 outputs/"
