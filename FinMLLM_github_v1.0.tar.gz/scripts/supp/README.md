# 补充实验套件 · 使用说明

> 目的：在动笔写 Introduction 之前，把审稿人一定会问的三个问题用实验堵死。
> 设计原则：**CPU 线与 GPU 线同时压满，谁都不许空转。**

---

## 一、这套实验在回答什么

| 编号 | 实验 | 回答的质疑 | 机器 |
|---|---|---|---|
| **A1** | 三种不同阶的有效秩度量（stable rank / participation ratio / entropy eRank / n90） | "你只挑了一个对自己有利的度量" | CPU |
| **A2** | 同形状高斯噪声基线 | ⭐"随机矩阵也低秩，你凭什么说你的更低秩？" | CPU |
| **A3** | 逐级截断到底丢掉了什么（E_drop / max_drop÷σ₁ / 谱间隙） | ⭐"你可能剪掉了 intruder dimension"（Shuttleworth, NeurIPS'24） | CPU |
| **A4** | 逐层 / 逐模块有效秩分布 | "层间是否均匀？对标 SVD-LLM V2 的异构秩分配" | CPU |
| **S1** | **r=64 过参数化对照**（训练 rank 给 4 倍，再截到 1/16） | ⭐⭐"有效秩低可能只是 α/r 缩放让高秩没被优化到"（rsLoRA） | GPU |
| **S2** | 能量轴截断曲线（保留 99/95/90/80/70/60% 能量） | "95% 能量准则不可靠"（Spectral Rank Certification）——我们实测 | CPU 造 + GPU 评 |
| **S3** | 随机方向截断 vs 按能量排序截断 | "按能量排序真的有用吗？"（Eckart–Young 的实证版） | CPU 造 + GPU 评 |
| **S4** | **SeLoRA 式参数 mask 40/60/80%** | ⭐⭐⭐"稀疏剪 60% 也不掉点，你凭什么用低秩？" | CPU 造 + GPU 评 |

### S4 为什么是反杀点

SeLoRA（Findings of ACL 2025）证明：随机 mask 掉 60% 的 LoRA 参数，精度不掉。
这看起来在说"冗余是密度不是秩"，威胁我们的低秩路线。

**但它从来没有算过一个字节。**

参数级稀疏只是把矩阵里的数变成 0，**张量形状不变、文件大小不变**。要真省硬盘，得用稀疏存储格式 —— 而每个非零元素要存「2 字节值 + 4 字节索引」，稀疏到 60% 时反而**比稠密更大**。

S2 脚本会把这个账算出来（`sparse_est_mb` 和 `sparse_vs_dense_ratio` 两列）。
**结论会是：mask 保住了精度，却没保住任何字节；SVD 低秩是唯二能真正减小体积的路径之一。**

---

## 二、时间线与资源预算

按 Qwen2.5-3B + QLoRA、单卡 4090 24G、实测训练峰值 4.15 GB 估算：

```
t0 ────────────────────────────────────────────────────────────────
    │
    ├─ CPU 线（立即启动，不占显卡）          约 15 分钟
    │    ├ s1_rank_metrics     全项目 adapter 谱审计
    │    ├ s2 造变体 (bin)      能量/mask/随机方向
    │    └ s2 造变体 (tri)
    │
    └─ GPU 线（同时启动，3 路并行）          约 2.5 小时
         ├ P1  r=64 训练 ×3（bin_s42 / tri_s42 / bin_s123）   ~25 min
         ├ P2  r=64 训练 ×1（bin_s2024）                      ~25 min
         ├ P3  截断 4/8/16 + 评测 8 次                         ~25 min
         └ P4  评测全部变体 ~26 次                             ~55 min
```

**显存预算**：单训练 ~4.5 GB × 3 路 ≈ 14 GB，留 10 GB 余量。
脚本内置显存闸门（`MIN_FREE=6000`），显存不够会自动等，绝不 OOM。

想更保守：`PAR=2`（两路）。想更快：`PAR=4`（约 17 GB，仍安全）。

**总量预算**：`ckpts_supp/` 约 **3–5 GB**（4 个 r=64 adapter × 130M + 约 30 个变体）。
数据盘够，但记得别放系统盘。

---

## 三、一条命令启动（推荐后台）

```bash
# 1) 先确认环境
cd /root/autodl-tmp/FinMLLM
alias fin='cd /root/autodl-tmp/FinMLLM'     # 建议写进 ~/.bashrc
nvidia-smi

# 2) 后台启动（合盖、断 SSH 都不影响）
bash scripts/supp/run_supp.sh --bg

# 3) 它会打印一个 log 路径，跟住
tail -f outputs/logs/supp/run_supp_*.log

# 4) 随时看状态面板（一屏看完）
bash scripts/supp/status_supp.sh
```

### 启动行为

`run_supp.sh` 会先执行 **STAGE 0：智能等待**

- 自动检测有没有 `train_sft / eval_cloze / train_domain / run_fork_c` 在跑
- 有 → 每 60 秒轮询一次，直到它结束（最多等 6 小时，可用 `MAX_WAIT` 调整）
- 没有 → 立刻开跑
- 不想等：`SKIP_WAIT=1 bash scripts/supp/run_supp.sh --bg`

**所以你不用先确认 `final_exp2` 跑没跑完，直接启动就行，它会自己排队。**

### 可选参数

| 变量 | 默认 | 说明 |
|---|---|---|
| `PAR` | 3 | GPU 并行路数 |
| `MAX_WAIT` | 21600 | 等待上一个实验的最长秒数 |
| `MIN_FREE` | 6000 | 启动新 job 前要求的最小空闲显存（MiB） |
| `EVAL_LIMIT` | 999999 | 评测样本上限。**要和 07 稿表格里的数字可比，必须与之前一致** |
| `SKIP_TRAIN` | 0 | 设为 1 则跳过训练，只评测已有变体 |
| `STAMP` | 自动 | 版本标记，所有输出目录都带它，**不会覆盖旧结果** |

---

## 四、产物在哪

```
ckpts_supp/
  r64_bin_s42/  r64_tri_s42/  r64_bin_s123/  r64_bin_s2024/     ← 过参数化对照
  r64_bin_r4/   r64_bin_r8/   r64_bin_r16/   ...                 ← 截断版
  energy_e95_fpb_r16_<stamp>/  energy_e90_...                    ← 能量轴
  mask60_fpb_r16_<stamp>/      mask80_...                        ← SeLoRA 对照
  randdir_r4_fpb_r16_<stamp>/                                    ← 随机方向

outputs/reports/
  supp_rank_metrics_<stamp>.json      ← A1–A4 全量结果（含逐矩阵记录）
  variants_bin_<stamp>.json           ← 变体清单与体积
  variants_tri_<stamp>.json
  eval_*.json                         ← 每次评测

outputs/logs/supp/
  run_supp_<stamp>.log     ← 主日志
  cpu_line.log             ← CPU 线
  gpu_queue.log            ← GPU 队列
  r64_*.log  eval_*.log    ← 每个 job 单独一份

outputs/supp_<stamp>/
  supplementary_tables.md  ← ⭐ 论文用的 A1/A2/S1–S4 六张表
  eval_accuracy_raw.json   ← 原始准确率，方便人工核对
```

---

## 五、跑完之后该看什么

跑完先看 `outputs/supp_<stamp>/supplementary_tables.md`，重点三件事：

1. **Table A1 的 `ratio` 列** —— 必须 **< 1**。
   如果某个 adapter 的 stable rank 和同形状随机矩阵差不多（ratio ≈ 1），那"有效秩低"这个说法就站不住，得换度量或换任务。

2. **Table S2** —— r=64 训出来再截到 1/16，精度掉多少。
   - 若基本不掉 → 主张升级为「**更新本身是低秩的**」，这是最强版本
   - 若明显掉 → 说明 r=16 训出的低秩是**构造使然**，我们只能主张"压缩可行"，不能主张"更新低秩"
   **这张表决定 Abstract 怎么写，必须先看它。**

3. **Table S3 的 `sparse/dense` 列** —— mask 80% 时稀疏存储估算是稠密的多少倍。
   这个数字直接进 Discussion 的反驳段。

---

## 六、风险与应对

| 风险 | 表现 | 应对 |
|---|---|---|
| r=64 训练 OOM | `CUDA out of memory` | `PAR=2` 重跑；或 `--bs 4` |
| 评测结果全是 1.0000 | 数据泄漏 | 检查 `--split-seed 42` 和 `--holdout 0.2` 是否与训练一致 |
| 找不到 `ckpts_sft/fpb_r16` | STAGE1 打印 fallback | 脚本会自动搜 rank=16 的 adapter；找不到就手动 `SRC_BIN=... ` 指定 |
| 变体造出来但没评测 | 表里显示 pending | `SKIP_TRAIN=1 bash scripts/supp/s3_gpu_queue.sh` 补评测 |
| `final_exp2` 其实没跑完 | 结果里 seed 全是 1.0000 | 单独重跑那组，别和本套混在一起 |

---

## 七、文件清单

| 文件 | 作用 |
|---|---|
| `supp_common.py` | 共享：adapter 读写、QR 加速 SVD、四种秩度量、噪声基线、子空间诊断 |
| `s1_rank_metrics.py` | A1–A4 纯 CPU 谱审计 |
| `s2_make_variants.py` | 造变体：能量轴 / 随机方向 / SeLoRA 式 mask |
| `s3_gpu_queue.sh` | GPU 队列：训练 → 截断 → 评测，显存闸门 + 分组并行 |
| `run_supp.sh` | 总调度：智能等待 → CPU 线与 GPU 线并行 → 汇总 |
| `s4_summarize.py` | 汇总成六张论文表 |
| `status_supp.sh` | 一屏状态面板 |

---

## 八、我（如烟）建议的执行顺序

1. **先跑 `bash scripts/supp/run_supp.sh --bg`**，别的先不管
2. 半小时后 `status_supp.sh` 看一眼，确认 r=64 三个都在跑、没有 OOM
3. **跑完先看 Table S2**，它决定论文的 claim 强度
4. 再看 Table A1 的 ratio 列，确认噪声基线能撑住
5. 都 OK 了再动笔写 Introduction —— 这样每一句都有表格兜底
