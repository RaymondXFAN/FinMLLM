#!/usr/bin/env bash
# ============================================================
# FinMLLM / run_gates.sh
# One-click gate runner: nogpu (G0-G2) or gpu (G0-G5).
# 一键 gate：nogpu 跑 G0-G2，gpu 跑 G0-G5。
#
# Author : Raymond Xiaohu Fan
# Note   : Never trust a model you haven't gated. / 没跑过 gate 的模型不值得信。
# Updated: 2026-10-19
# ============================================================

# 一键跑 gate
#   bash scripts/run_gates.sh nogpu   # G0 G1 G2（无卡）
#   bash scripts/run_gates.sh gpu     # G0..G5（开卡）
set -uo pipefail
PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
MODE="${1:-nogpu}"
LOG="$PROJ/outputs/logs"; mkdir -p "$LOG"
cd "$PROJ" || exit 1
[ -f setup_env.sh ] && source setup_env.sh

run () {
  local name="$1"; shift
  echo ""; echo "================ $name ================"
  python "$@" 2>&1 | tee "$LOG/${name}.log"
  local rc=${PIPESTATUS[0]}
  echo "[$name] exit=$rc"
  return $rc
}

declare -a FAILED=()
run g0 scripts/gates/g0_env.py   || FAILED+=("g0")
run g1 scripts/gates/g1_ops.py   || FAILED+=("g1")
run g2 scripts/gates/g2_data.py  || FAILED+=("g2")

if [ "$MODE" = "gpu" ]; then
  run g3 scripts/gates/g3_train.py    || FAILED+=("g3")
  run g4 scripts/gates/g4_profile.py  || FAILED+=("g4")
  run g5 scripts/gates/g5_transfer.py || FAILED+=("g5")
fi

echo ""
echo "==============================================="
if [ ${#FAILED[@]} -eq 0 ]; then
  echo "🎉 全部 gate 通过（mode=$MODE）"
else
  echo "⚠️ 以下 gate 未通过：${FAILED[*]}"
  echo "   日志目录：$LOG"
  exit 1
fi
