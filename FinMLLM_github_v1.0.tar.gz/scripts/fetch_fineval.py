#!/usr/bin/env python3
# ============================================================
# FinMLLM / fetch_fineval.py
# Pull the whole FinEval bundle as a single zip and carve out the
# insurance-related subjects as a backup business line.
# 把 FinEval 整包当 zip 拉下来，切出保险相关科目作为保险业务线的备选数据。
#
# Author : Raymond Xiaohu Fan
# Note   : When a repo only ships one zip, that zip is a gift. / 仓库只给一个 zip，那是天上掉的礼物。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/fetch_fineval.py            # download + unpack + convert
#   python scripts/fetch_fineval.py --list     # just list subjects / 只看有哪些科目
# ============================================================
import os, sys, json, zipfile, glob, re, argparse

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
RAW = os.path.join(ROOT, "data", "raw")
OUT = os.path.join(RAW, "fineval")
UNI = os.path.join(ROOT, "data", "unified")
os.makedirs(OUT, exist_ok=True)
os.makedirs(UNI, exist_ok=True)

REPO = "SUFE-AIFLM-Lab/FinEval"

# Anything matching these is treated as an insurance subject.
# 文件名命中这些关键词的，视为保险类科目。
INSURANCE_KEYS = ["insurance", "actuar", "保险", "精算", "underwrit"]


def download_zip():
    from huggingface_hub import hf_hub_download
    print(f"[1/4] downloading {REPO}/FinEval.zip ...")
    p = hf_hub_download(repo_id=REPO, filename="FinEval.zip", repo_type="dataset",
                        local_dir=os.path.join(RAW, "fineval_pkg"))
    print(f"      saved -> {p}  ({os.path.getsize(p)/1024**2:.1f} MB)")
    return p


def unpack(zip_path):
    print("[2/4] unpacking ...")
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(OUT)
        names = zf.namelist()
    print(f"      {len(names)} entries")
    for n in names[:15]:
        print(f"      · {n}")
    return names


def find_subject_files():
    """Return {subject_name: filepath} for every json/csv/xlsx found.
    返回 {科目名: 文件路径}。"""
    hits = {}
    for f in glob.glob(os.path.join(OUT, "**", "*"), recursive=True):
        if not os.path.isfile(f):
            continue
        if not f.lower().endswith((".json", ".csv", ".xlsx", ".xls")):
            continue
        name = os.path.splitext(os.path.basename(f))[0]
        hits[name] = f
    return hits


def is_insurance(name):
    low = name.lower()
    return any(k in low for k in INSURANCE_KEYS)


def rows_from_file(path):
    """Best-effort parser for FinEval subject files.
    尽力解析 FinEval 科目文件（json / csv）。"""
    rows = []
    low = path.lower()
    if low.endswith(".json"):
        try:
            data = json.load(open(path, encoding="utf-8"))
        except Exception:
            return rows
        # Accept: list[dict] or dict[str, list] or dict[str, dict]
        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    items.extend(v)
                elif isinstance(v, dict):
                    items.append(v)
        for it in items:
            if not isinstance(it, dict):
                continue
            q = it.get("question") or it.get("Q") or it.get("stem")
            if not q:
                continue
            opts = {k: it.get(k) for k in ("A", "B", "C", "D") if it.get(k)}
            ans = it.get("answer") or it.get("Answer") or it.get("label")
            text = str(q)
            if opts:
                text += "\n" + "\n".join(f"{k}. {v}" for k, v in opts.items())
            rows.append({"text": text, "label": str(ans) if ans is not None else ""})
    elif low.endswith(".csv"):
        import csv
        try:
            with open(path, encoding="utf-8", errors="ignore") as fh:
                for r in csv.DictReader(fh):
                    q = r.get("question") or r.get("Q") or r.get("stem")
                    if not q:
                        continue
                    rows.append({"text": str(q), "label": str(r.get("answer", ""))})
        except Exception:
            pass
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true", help="only list subjects / 只列科目")
    args = ap.parse_args()

    print("=" * 70)
    print(" FinEval -> insurance business line / FinEval 保险科目提取")
    print("=" * 70)
    zp = download_zip()
    names = unpack(zp)
    subs = find_subject_files()
    print(f"[3/4] found {len(subs)} subject files")

    if args.list:
        for n in sorted(subs):
            flag = "  ← insurance" if is_insurance(n) else ""
            print(f"   {n}{flag}")
        return

    picked = {n: p for n, p in subs.items() if is_insurance(n)}
    print(f"      insurance subjects: {list(picked) or '(none matched)'}")

    if not picked:
        print("⚠️  no insurance subject matched. Run --list to inspect names.")
        print("    You can rename the pattern in INSURANCE_KEYS and re-run.")
        return

    rows = []
    for n, p in picked.items():
        part = rows_from_file(p)
        print(f"      {n}: {len(part)} rows")
        for r in part:
            rows.append({"id": f"fineval-ins-{len(rows)}", "text": r["text"],
                         "label": r["label"], "domain": "insurance",
                         "source": "fineval", "subject": n, "split": "test"})

    print(f"[4/4] writing {len(rows)} rows ...")
    out = os.path.join(UNI, "fineval_insurance.jsonl")
    with open(out, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"      ✅ {out}")

    # Also append to domains/insurance.jsonl so G2 sees it.
    dom = os.path.join(ROOT, "data", "domains", "insurance.jsonl")
    os.makedirs(os.path.dirname(dom), exist_ok=True)
    with open(dom, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps({"id": r["id"], "text": r["text"], "domain": "insurance",
                                "source": "fineval", "split": "test"}, ensure_ascii=False) + "\n")
    print(f"      ✅ appended -> {dom}")
    print("\nNext / 下一步: python scripts/gates/g2_data.py")


if __name__ == "__main__":
    main()
