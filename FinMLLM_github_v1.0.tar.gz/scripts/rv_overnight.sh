#!/usr/bin/env bash
# ============================================================
# FinMLLM / rv_overnight.sh
# 夜间串行：PARA 评测 -> FiQA 训练 -> 7B 六个 run
# Overnight serial queue: PARA eval -> FiQA train -> 7B runs.
#
# 为什么串行：冒烟测出 7B 单进程 LOAD=8.17 / nproc=8，CPU 已满，
# 并行只会互相拖慢（之前卡死的同款症状）。
# Why serial: one 7B process already saturates all eight cores.
#
# 谱分析不在这里 —— analyze_adapter_rank.py 的接口还没核实，
# 单独跑，避免 4 小时后才发现参数写错。
#
# Author : Raymond Xiaohu Fan
# Usage: nohup bash scripts/rv_overnight.sh > logs/overnight.log 2>&1 &
# ============================================================
set -u
cd /root/autodl-tmp/FinMLLM || exit 1
mkdir -p logs outputs/reports/rv_para ckpts_rv

stamp () { date '+[%F %T]'; }
say () { echo "$(stamp) $*"; }
fail=0

# ---------------- 1. PARA 基线评测 ----------------
say "=== [1/3] PARA baseline eval ==="
for pair in "bin 2" "tri 3"; do
  set -- $pair; TASK=$1; CLS=$2
  for f in ckpts_supp/para_${TASK}/*/; do
    [ -f "$f/adapter_config.json" ] || continue
    n=$(basename "$f")
    out="outputs/reports/rv_para/${n}__${TASK}.json"
    [ -s "$out" ] && { say "  skip $n"; continue; }
    say "  eval $TASK $n"
    python scripts/rv_eval_preds.py --dataset fpb --classes $CLS --adapter "$f" \
      --limit 0 --out "$out" >/dev/null 2>>logs/overnight_err.log \
      && say "    ok" || { say "    FAIL"; fail=$((fail+1)); }
  done
done

# ---------------- 2. FiQA adapter ----------------
if [ "$fail" -gt 2 ]; then
  say "!!! PARA 阶段失败 $fail 次，中止整个队列（先别烧 4 小时机时）"
  exit 1
fi

say "=== [2/3] FiQA adapter training ==="
for S in 42 123; do
  OUT=ckpts_rv/fiqa_r16_s${S}
  if [ -f "$OUT/adapter_model.safetensors" ]; then say "  skip $OUT"; continue; fi
  say "  train fiqa s$S"
  python scripts/rv_train_sft.py --dataset fiqa_sa --classes 3 --rank 16 \
    --seed $S --split-seed 42 --holdout 0.2 --split train \
    --out "$OUT" >> logs/train_fiqa.log 2>&1 \
    && say "    ok" || { say "    FAIL"; fail=$((fail+1)); }
done

# ---------------- 3. Qwen2.5-7B ----------------
if [ "$fail" -gt 2 ]; then
  say "!!! 前两阶段失败 $fail 次，中止（7B 太贵，不能带着错误跑）"
  exit 1
fi

say "=== [3/3] Qwen2.5-7B runs ==="
B7=/root/autodl-tmp/models/Qwen2.5-7B
for spec in "2 16 42" "3 16 42" "2 64 42" "3 64 42" "2 16 123" "3 16 123"; do
  set -- $spec
  CLS=$1; RK=$2; SD=$3
  OUT=ckpts_rv/7b_c${CLS}_r${RK}_s${SD}
  if [ -f "$OUT/adapter_model.safetensors" ]; then say "  skip $OUT"; continue; fi
  say "  train 7B classes=$CLS r=$RK seed=$SD"
  python scripts/rv_train_sft.py --dataset fpb --classes $CLS --rank $RK \
    --seed $SD --split-seed 42 --holdout 0.2 --split train \
    --base $B7 --out "$OUT" >> logs/train_7b.log 2>&1 \
    && say "    ok" || { say "    FAIL"; fail=$((fail+1)); }
done

say "=== ALL DONE, failures=$fail ==="
