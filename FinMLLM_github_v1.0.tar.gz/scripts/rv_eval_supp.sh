#!/usr/bin/env bash
# FinMLLM / rv_eval_supp.sh
# 评测 ckpts_supp 下所有变体，全量测试集。
# Evaluate every variant under ckpts_supp on the full partition.
# Author: Raymond Xiaohu Fan
set -u
cd /root/autodl-tmp/FinMLLM || exit 1
OUT=outputs/reports/rv_supp
mkdir -p "$OUT" logs

run_one () {   # $1=dir  $2=task
  local d="$1" t="$2"
  local name; name=$(basename "$d")
  local cls=3; [ "$t" = "bin" ] && cls=2
  local out="$OUT/${name}__${t}.json"
  [ -s "$out" ] && { echo "  skip $out"; return; }
  python scripts/rv_eval_preds.py --dataset fpb --classes $cls \
      --adapter "$d" --limit 0 --out "$out" >/dev/null 2>>logs/rv_supp_err.log \
      && echo "  ok ${name}__${t}" || echo "  FAIL ${name}__${t}"
}

echo "=== bin $(date '+%T') ==="
for d in ckpts_supp/bin/*/; do run_one "$d" bin; done
echo "=== tri $(date '+%T') ==="
for d in ckpts_supp/tri/*/; do run_one "$d" tri; done
echo "ALL_DONE $(date '+%T')"
