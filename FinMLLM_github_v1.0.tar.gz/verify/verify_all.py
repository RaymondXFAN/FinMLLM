#!/usr/bin/env python3
# ============================================================
# FinMLLM / verify_all.py
# 一键复现校验：把论文里每一个数字从 raw json 重算一遍，逐项和论文声称值比对。
# One-shot reproducibility check: recompute every number in the paper from the
# raw evaluation json and compare it against the value the paper claims.
#
# 我为什么非要写这个脚本：
# 之前论文的 ternary 增量在四个地方写着四套数（+3.72 / +3.31 / +0.41 / 均值 4.27），
# 传上去就是让审稿人拿计算器打我脸。所以现在反过来——让代码去审论文。
# 只要这个脚本全绿，说明论文里没有一个数字是手抄的。
#
# Why this script exists: the paper once carried four different values for the
# same ternary delta. Now the code cross-examines the paper instead of the other
# way round. All green here means no number was copied by hand.
#
# 用法 / Usage:
#   python3 verify/verify_all.py                      # 用包内 results/
#   python3 verify/verify_all.py --results /path      # 指定结果目录
#   python3 verify/verify_all.py --ckpts /path/ckpts_rv   # 额外校验体积(MB)
#
# 退出码 / Exit code: 0 = 全部通过, 1 = 有不一致
# 作者 / Author: Raymond Xiaohu Fan
# ============================================================
import os, sys, json, glob, math, argparse
from itertools import combinations

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_RESULTS = os.path.join(os.path.dirname(HERE), "results")

# ---------- 基础工具 ----------
def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def acc_of(path):
    return load(path)["accuracy"]

def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs)

def sd(xs):
    xs = list(xs)
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))

def mcnemar(p16, p1):
    """从两个带 preds 的评测 json 算配对 McNemar。
       Paired McNemar from two evaluations that carry per-item predictions.
       返回 (n, b, c, delta_pp, p_two_sided)。b = r16 错 r1 对，c = 反之。"""
    a, b_ = load(p16), load(p1)
    n = a["n"]
    if b_["n"] != n:
        raise ValueError(f"n 不一致: {a['n']} vs {b_['n']}")
    ok16 = {p["i"]: p["ok"] for p in a["preds"]}
    ok1 = {p["i"]: p["ok"] for p in b_["preds"]}
    g16 = {p["i"]: p["gold"] for p in a["preds"]}
    g1 = {p["i"]: p["gold"] for p in b_["preds"]}
    if g16 != g1:
        raise ValueError("两条评测的 gold 标签对不上，说明不是同一批测试项")
    nb = sum(1 for i in ok16 if ok16[i] == 0 and ok1[i] == 1)
    nc = sum(1 for i in ok16 if ok16[i] == 1 and ok1[i] == 0)
    N = nb + nc
    k = min(nb, nc)
    # 双侧精确二项检验 / two-sided exact binomial
    p = 1.0 if N == 0 else min(1.0, 2 * sum(math.comb(N, j) for j in range(k + 1)) / 2 ** N)
    return n, nb, nc, (nb - nc) / n * 100, p

# ---------- 比对器 ----------
class Checker:
    def __init__(self):
        self.rows = []
        self.n_fail = 0
    def check(self, section, name, claimed, got, tol=5e-5, fmt="{:.4f}"):
        ok = claimed is not None and abs(claimed - got) <= tol
        if not ok:
            self.n_fail += 1
        self.rows.append((section, name, claimed, got, ok))
        return ok
    def report(self):
        cur = None
        for section, name, claimed, got, ok in self.rows:
            if section != cur:
                print(f"\n{'='*74}\n{section}\n{'='*74}")
                cur = section
            mark = "OK  " if ok else "FAIL"
            c = "-" if claimed is None else (f"{claimed:.4f}" if isinstance(claimed, float) else str(claimed))
            g = f"{got:.4f}" if isinstance(got, float) else str(got)
            print(f"  [{mark}] {name:44s} 论文={c:>9s}  实算={g:>9s}")
        print("\n" + "-" * 74)
        if self.n_fail == 0:
            print(f"✅ 全部 {len(self.rows)} 项通过 —— 论文里的数字与 raw json 完全一致。")
            print("   All {n} checks passed. Every number in the paper is traceable.".format(n=len(self.rows)))
        else:
            print(f"❌ {self.n_fail} / {len(self.rows)} 项不一致，见上方 FAIL 行。")
        print("-" * 74)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=DEFAULT_RESULTS)
    ap.add_argument("--ckpts", default=None, help="可选：adapter 目录，用于校验体积(MB)")
    ap.add_argument("--strict", action="store_true", help="缺失文件也算 FAIL")
    args = ap.parse_args()
    R = args.results
    if not os.path.isdir(R):
        print(f"❌ 结果目录不存在: {R}")
        return 1
    ck = Checker()

    def path(*p):
        return os.path.join(R, *p)

    def missing(sec, name, why):
        if args.strict:
            ck.check(sec, name, None, float("nan"))
        else:
            print(f"  [SKIP] {name} —— {why}")

    # =========================================================
    # 1. Table 1 —— 压缩-精度前沿
    #    论文取数：r16 / r1 用三 seed 均值；r8 / r4 / r2 只有 reference seed 42
    # =========================================================
    S1 = "Table 1 · Compression–accuracy frontier"
    # 表格正文用的是 reference seed (42)，所以这里先逐格校验 s42；
    # r16 / r1 另外再校验三 seed 均值（正文里报的就是均值）。
    # The table reports the reference seed; the text reports three-seed means.
    for task in ("bin", "tri"):
        for r in (16, 8, 4, 2, 1):
            p42 = path("rv_final", f"{task}_s42_r{r}.json")
            if os.path.exists(p42):
                ck.check(S1, f"{task} r={r}  (table, seed 42)", CLAIM_T1[(task, r)], acc_of(p42))
            else:
                missing(S1, f"{task} r={r} seed42", "文件缺失")
        for r in (16, 1):
            vs = []
            for sd_ in ("s42", "s123", "s2024"):
                p_ = path("rv_final", f"{task}_{sd_}_r{r}.json")
                if os.path.exists(p_):
                    vs.append(acc_of(p_))
            if len(vs) == 3:
                ck.check(S1, f"{task} r={r}  (text, 3-seed mean)", CLAIM_T1_MEAN3[(task, r)], mean(vs))
                print(f"        · {task} r={r} 三 seed: {[round(v,4) for v in vs]} → mean {mean(vs):.4f} sd {sd(vs):.4f}")
            else:
                missing(S1, f"{task} r={r} mean3", f"只有 {len(vs)} 个 seed")

    # =========================================================
    # 2. McNemar —— r=16 vs r=1 逐样本配对
    # =========================================================
    S2 = "Paired McNemar · r16 vs r1 (16× compression)"
    for task in ("bin", "tri"):
        for s in ("s42", "s123", "s2024"):
            p16, p1 = path("rv_final", f"{task}_{s}_r16.json"), path("rv_final", f"{task}_{s}_r1.json")
            if not (os.path.exists(p16) and os.path.exists(p1)):
                missing(S2, f"{task} {s}", "文件缺失"); continue
            n, b, c, d, p = mcnemar(p16, p1)
            cb, cc, cd = CLAIM_MC[(task, s)]
            ck.check(S2, f"{task} {s}  b (r16 wrong, r1 right)", float(cb), float(b), tol=0)
            ck.check(S2, f"{task} {s}  c (r16 right, r1 wrong)", float(cc), float(c), tol=0)
            ck.check(S2, f"{task} {s}  delta (pp)", cd, d, tol=5e-3)   # 论文报两位小数
            print(f"        · {task} {s}: n={n}  b={b} c={c}  Δ={d:+.2f}pp  p={p:.4f}")
    # FiQA
    for s in ("s42", "s123"):
        p16, p1 = path("fiqa", f"fiqa_{s}_r16.json"), path("fiqa", f"fiqa_{s}_r1.json")
        if not (os.path.exists(p16) and os.path.exists(p1)):
            missing(S2, f"fiqa {s}", "文件缺失"); continue
        n, b, c, d, p = mcnemar(p16, p1)
        cb, cc, cd = CLAIM_MC[("fiqa", s)]
        ck.check(S2, f"fiqa {s}  b", float(cb), float(b), tol=0)
        ck.check(S2, f"fiqa {s}  c", float(cc), float(c), tol=0)
        ck.check(S2, f"fiqa {s}  delta (pp)", cd, d, tol=5e-3)
        print(f"        · fiqa {s}: n={n}  b={b} c={c}  Δ={d:+.2f}pp  p={p:.4f}")

    # =========================================================
    # 3. Table 3 —— 有效秩诊断（9 行 + FiQA 第二 seed）
    # =========================================================
    S3 = "Table 3 · Effective-rank diagnostics"
    for key, fname in CLAIM_T3_FILES.items():
        p = path("table3", fname)
        if not os.path.exists(p):
            missing(S3, key, f"缺 {fname}"); continue
        a = load(p)["aggregate"]
        claim = CLAIM_T3[key]
        # 容差按论文的有效位数定：stable/pr/erank/n90/noise 报两位小数，
        # ratio 报三位。不能拿 5e-5 去卡 2 位小数的值，那是自己骗自己。
        # Tolerances follow the precision printed in the paper (2 dp, ratio 3 dp).
        for field in ("stable", "pr", "erank", "n90", "noise", "ratio"):
            tol = 5e-4 if field == "ratio" else 5e-3
            ck.check(S3, f"{key}  {field}", claim[field], a[field], tol=tol)

    # =========================================================
    # 4. 参数 mask 对照
    # =========================================================
    S4 = "Table S3 · Parameter masking (full test set)"
    for pct in (40, 60, 80):
        for t in ("bin", "tri"):
            fs = glob.glob(path("rv_supp") + f"/mask_p{pct}_*__{t}.json")
            if not fs:
                missing(S4, f"mask {pct}% {t}", "缺失"); continue
            ck.check(S4, f"mask {pct}%  {t}", CLAIM_MASK[(pct, t)], acc_of(fs[0]))

    # =========================================================
    # 5. 随机方向对照（5 次抽样取均值）
    # =========================================================
    S5 = "Table S4 · Random-direction truncation (mean of 5 draws)"
    for r in (8, 4, 2, 1):
        for t in ("bin", "tri"):
            fs = sorted(glob.glob(path("rv_supp") + f"/randdir_r{r}_d*__{t}.json"))
            if len(fs) < 2:
                missing(S5, f"randdir r={r} {t}", f"抽样数 {len(fs)} < 2"); continue
            vs = [acc_of(f) for f in fs]
            key = (r, t)
            if key in CLAIM_RANDDIR:
                ck.check(S5, f"randdir r={r} {t} mean(n={len(vs)})",
                         CLAIM_RANDDIR[key], mean(vs), tol=2e-3)
                print(f"        · r={r} {t}: mean={mean(vs):.4f} sd={sd(vs):.4f}")

    # =========================================================
    # 6. PARA 全局阈值基线
    # =========================================================
    S6 = "PARA baseline · global energy threshold"
    for q, (b_claim, t_claim) in CLAIM_PARA.items():
        for t, cv in (("bin", b_claim), ("tri", t_claim)):
            p = path("rv_para", f"para_q{q}__{t}.json")
            if not os.path.exists(p):
                missing(S6, f"PARA q{q} {t}", "缺失"); continue
            ck.check(S6, f"PARA q{q}  {t}", cv, acc_of(p))

    # =========================================================
    # 7. §4.6 跨域迁移（FiQA，FPB adapter 迁移过去）
    #    注意：这跟 results/fiqa/ 里"FiQA 自训 adapter"是两件不同的事，
    #    别搞混 —— 那个是 Table 3 的 ratio 0.163，这个是 §4.6 的迁移。
    # =========================================================
    S7x = "§4.6 Cross-domain transfer to FiQA (n=243)"
    tr = {}
    for tag in ("base", "r16", "r1"):
        p_ = path("fiqa_transfer", f"transfer_{tag}.json")
        if os.path.exists(p_):
            tr[tag] = load(p_)
            ck.check(S7x, f"transfer {tag}", CLAIM_TRANSFER[tag], tr[tag]["accuracy"])
        else:
            missing(S7x, f"transfer {tag}", "文件缺失")
    if "r16" in tr and "r1" in tr:
        _n, _b, _c, _d, _pval = mcnemar(path("fiqa_transfer", "transfer_r16.json"),
                                       path("fiqa_transfer", "transfer_r1.json"))
        ck.check(S7x, "r16→r1 delta (pp)", CLAIM_TRANSFER_DELTA, _d, tol=5e-3)
        print(f"        · r16→r1: b={_b} c={_c} Δ={_d:+.2f}pp p={_pval:.4f}")
        ok_ns = _pval > 0.05
        if not ok_ns:
            ck.n_fail += 1
            print("        [FAIL] 论文说「无显著差异」，但实测 p<=0.05")
        else:
            print("        [OK  ] 不显著，与论文表述一致")
    if "base" in tr and "r16" in tr:
        gain = (tr["r16"]["accuracy"] - tr["base"]["accuracy"]) * 100
        ck.check(S7x, "base→r16 gain (pp)", CLAIM_TRANSFER_GAIN, gain, tol=0.1)

    # =========================================================
    # 8. 体积（可选，需要 adapter 目录）
    # =========================================================
    if args.ckpts:
        S7 = "Adapter size (MB)"
        for r, claim in CLAIM_SIZE.items():
            # 必须精确到 "_r{r}" 结尾，否则 *r1* 会把 fpb_r16 也匹配进来
            # (匹配到 r16 的 114.3 MB 去校验 r1 的 7.2 MB，然后报一个假 FAIL)
            hits = glob.glob(os.path.join(args.ckpts, f"*_r{r}", "adapter_model.safetensors"))
            if not hits:
                missing(S7, f"r={r}", "找不到 adapter_model.safetensors"); continue
            mb = os.path.getsize(hits[0]) / 1024 / 1024
            ck.check(S7, f"r={r} size MB", claim, mb, tol=0.6)
    else:
        print("\n[提示] 未传 --ckpts，跳过体积校验（论文报的是 115.0 / 57.1 / 28.5 / 14.3 / 7.1 MB）")

    ck.report()
    return 0 if ck.n_fail == 0 else 1


# =============================================================
# 论文声称值 —— 这张表就是"论文"本身，改论文时必须同步改这里
# Claimed values. This table IS the paper; keep it in sync with the manuscript.
# =============================================================
# Table 1 里的值 —— reference seed (42)，与论文表格逐格对应
CLAIM_T1 = {
    ("bin", 16): 0.9873, ("bin", 8): 0.9898, ("bin", 4): 0.9898,
    ("bin", 2): 0.9924,  ("bin", 1): 0.9898,
    ("tri", 16): 0.7831, ("tri", 8): 0.7831, ("tri", 4): 0.7800,
    ("tri", 2): 0.7810,  ("tri", 1): 0.8161,
}
# 正文里的三 seed 均值
CLAIM_T1_MEAN3 = {
    ("bin", 16): 0.9873, ("bin", 1): 0.9898,
    ("tri", 16): 0.7968, ("tri", 1): 0.8382,
}

# (b, c, delta_pp) —— delta 的定义是 r1 减 r16，正数表示压缩后更好
CLAIM_MC = {
    ("bin", "s42"):   (2, 1,  +0.25),
    ("bin", "s123"):  (2, 1,  +0.25),
    ("bin", "s2024"): (3, 2,  +0.25),
    ("tri", "s42"):   (44, 12, +3.31),
    ("tri", "s123"):  (37, 10, +2.79),
    ("tri", "s2024"): (70, 9,  +6.30),
    ("fiqa", "s42"):  (1, 4,  -1.23),
    ("fiqa", "s123"): (5, 8,  -1.23),
}

CLAIM_T3_FILES = {
    "3B binary  r16":  "3b_bin_r16.json",
    "3B ternary r16":  "3b_tri_r16.json",
    "3B FiQA    r16":  "fiqa_r16_s42.json",
    "3B binary  r64":  "3b_bin_r64_s42.json",
    "3B ternary r64":  "3b_tri_r64_s42.json",
    "7B binary  r16":  "7b_bin_r16.json",
    "7B ternary r16":  "7b_tri_r16.json",
    "7B binary  r64":  "7b_bin_r64.json",
    "7B ternary r64":  "7b_tri_r64.json",
}
CLAIM_T3 = {
    "3B binary  r16": dict(stable=1.98, pr=8.50, erank=11.40, n90=6.46, noise=14.08, ratio=0.141),
    "3B ternary r16": dict(stable=1.86, pr=8.02, erank=11.04, n90=6.02, noise=14.08, ratio=0.133),
    "3B FiQA    r16": dict(stable=2.28, pr=9.42, erank=12.04, n90=7.40, noise=14.08, ratio=0.163),
    "3B binary  r64": dict(stable=2.33, pr=22.02, erank=37.06, n90=13.89, noise=50.09, ratio=0.047),
    "3B ternary r64": dict(stable=2.50, pr=23.90, erank=38.42, n90=16.24, noise=50.09, ratio=0.050),
    "7B binary  r16": dict(stable=1.94, pr=8.25, erank=11.20, n90=6.22, noise=14.51, ratio=0.134),
    "7B ternary r16": dict(stable=1.74, pr=7.54, erank=10.67, n90=5.42, noise=14.51, ratio=0.120),
    "7B binary  r64": dict(stable=2.08, pr=20.73, erank=36.46, n90=13.20, noise=52.96, ratio=0.039),
    "7B ternary r64": dict(stable=1.95, pr=18.87, erank=33.98, n90=12.25, noise=52.96, ratio=0.037),
}

CLAIM_MASK = {
    (40, "bin"): 0.9898, (40, "tri"): 0.7779,
    (60, "bin"): 0.9898, (60, "tri"): 0.7851,
    (80, "bin"): 0.9924, (80, "tri"): 0.7893,
}

CLAIM_RANDDIR = {
    (8, "bin"): 0.9873, (8, "tri"): 0.7709,
    (4, "bin"): 0.9848, (4, "tri"): 0.7789,
    (2, "bin"): 0.9797, (2, "tri"): 0.7839,
    (1, "bin"): 0.8487, (1, "tri"): 0.6231,
}

CLAIM_PARA = {
    40: (0.9898, 0.7810),
    60: (0.9898, 0.7810),
    80: (0.9924, 0.7810),
    90: (0.9924, 0.7831),
    98: (0.9898, 0.8161),
}

CLAIM_SIZE = {16: 114.3, 8: 57.2, 4: 28.6, 2: 14.3, 1: 7.2}

# §4.6 跨域迁移（2026-11-12 用重建后的 fiqa_sa 重跑定案）
CLAIM_TRANSFER = {"base": 0.2181, "r16": 0.6626, "r1": 0.6749}
CLAIM_TRANSFER_DELTA = 1.23    # r1 减 r16，正数表示压缩后略高
CLAIM_TRANSFER_GAIN = 44.44    # base 到 r16


if __name__ == "__main__":
    sys.exit(main())
