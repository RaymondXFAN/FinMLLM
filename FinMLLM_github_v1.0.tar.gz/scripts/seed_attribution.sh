#!/usr/bin/env bash
# ============================================================
# FinMLLM / seed_attribution.sh
# Train a second seed of ONE domain, then ask: is "same domain, different seed"
# closer in spectral direction than "different domain, same seed"?
# 训第二个种子的同一业务线，回答：同域不同种子，是否比跨域同种子更"像"？
#
# Author : Raymond Xiaohu Fan
# Note   : If seed beats domain, the spectral story is dead — and that is publishable.
#          如果种子比域更能决定谱方向，这个故事就该结束了——而这本身可以发表。
# Updated: 2026-10-23
# ============================================================
set -uo pipefail
cd /root/autodl-tmp/FinMLLM || exit 1
source setup_env.sh 2>/dev/null || true
export BASE_MODEL="${BASE_MODEL:-/root/autodl-tmp/models/Qwen2.5-3B}"
export OMP_NUM_THREADS=2

echo "=== Training bank with seed 123 (same data, same config) ==="
nohup setsid python scripts/train_domain.py \
  --domain bank --seed 123 --limit 4000 \
  > outputs/logs/train_bank_s123.log 2>&1 < /dev/null &
echo "PID=$!"
echo "Log: outputs/logs/train_bank_s123.log"
echo ""
echo "After it finishes (~50 min), run:"
echo "  python scripts/e0d_seed_attribution.py --ckpt_dir ckpts"
