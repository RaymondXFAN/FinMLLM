#!/usr/bin/env bash
# ============================================================
# FinMLLM / supp / run_supp.sh
# ONE command. Waits for whatever is running, then saturates BOTH the CPU and
# the GPU instead of letting either idle.
# 一条命令搞定：先等当前实验收尾，然后 CPU 和 GPU 同时压满，谁都不许空转。
#
# Timeline / 时间线:
#   t0        wait for the running experiment to finish (if any) / 等当前实验收尾
#   t0+0m     CPU line starts  : spectral audit + variant building (no GPU)
#             CPU 线启动：谱审计 + 变体生成（不占显卡）
#   t0+0m     GPU line starts  : r=64 over-parameterised training, 3-way parallel
#             GPU 线启动：r=64 过参数化训练，三路并行
#   t0+~1h    GPU line continues: evaluate every variant, 3-way parallel
#   t_all     summarize into paper-ready tables / 汇总成论文表
#
# Author : Raymond Xiaohu Fan
# Note   : Your laptop lid will close. tmux will not care.
#          你合盖，它不管。所以全程 setsid + nohup。
# Updated: 2026-10-25
#
# Usage / 用法:
#   bash scripts/supp/run_supp.sh              # foreground, watch it
#   bash scripts/supp/run_supp.sh --bg         # detach (recommended) / 后台（推荐）
#   MAX_WAIT=7200 PAR=3 bash scripts/supp/run_supp.sh --bg
#   SKIP_WAIT=1 bash scripts/supp/run_supp.sh --bg   # do not wait, go now
# ============================================================
set -uo pipefail

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
cd "$PROJ" || { echo "FATAL: $PROJ not found"; exit 1; }

STAMP="${STAMP:-$(date +%Y%m%d_%H%M)}"
export STAMP
MAX_WAIT="${MAX_WAIT:-21600}"     # 6h max wait for the previous run / 最多等 6 小时
PAR="${PAR:-3}"
OUTD="outputs/supp_${STAMP}"
LOGD="outputs/logs/supp"
mkdir -p "$OUTD" "$LOGD" outputs/reports ckpts_supp

say() { echo "[$(date +%H:%M:%S)] $*"; }

# ------------------------------------------------------------
# --bg : re-launch detached, survive lid close / 后台模式，合盖也不死
# ------------------------------------------------------------
if [ "${1:-}" = "--bg" ]; then
  mkdir -p "$LOGD"
  LOG="$LOGD/run_supp_${STAMP}.log"
  echo "detaching -> $LOG"
  setsid nohup env STAMP="$STAMP" PAR="$PAR" MAX_WAIT="$MAX_WAIT" \
    bash "$0" >>"$LOG" 2>&1 &
  sleep 3
  echo
  echo "✅ started detached. Watch it with:"
  echo "   tail -f $PROJ/$LOG"
  echo "   bash scripts/supp/status_supp.sh"
  echo
  echo " pid tree:"
  pgrep -fa "run_supp.sh" | head -5
  exit 0
fi

echo "============================================================"
echo " SUPPLEMENTARY EXPERIMENT SUITE"
echo " stamp=$STAMP  PAR=$PAR  MAX_WAIT=${MAX_WAIT}s"
echo " proj =$PROJ"
echo "============================================================"
nvidia-smi --query-gpu=name,memory.total,memory.used,utilization.gpu --format=csv 2>/dev/null || echo "nvidia-smi unavailable"

# ------------------------------------------------------------
# STAGE 0 · wait for the previous experiment / 等上一个实验收尾
# ------------------------------------------------------------
running_jobs() {
  # anything that looks like OUR training/eval, excluding this suite itself
  # 看起来像我们自己的训练/评测进程，排除本套脚本
  pgrep -fa "python.*\(train_sft\|eval_cloze\|train_domain\|run_fork_c\)" 2>/dev/null \
    | grep -v "supp/" | grep -v "run_supp" || true
}

if [ "${SKIP_WAIT:-0}" != "1" ]; then
  waited=0
  while :; do
    J=$(running_jobs)
    if [ -z "$J" ]; then
      say "STAGE0: no running experiment detected -> go"
      break
    fi
    if [ "$waited" -ge "$MAX_WAIT" ]; then
      say "STAGE0: waited ${waited}s (>= MAX_WAIT), proceeding anyway"
      say "        still running:"
      echo "$J" | sed 's/^/        /'
      break
    fi
    if [ $((waited % 300)) -eq 0 ]; then
      say "STAGE0: waiting for previous run (${waited}s elapsed)"
      echo "$J" | sed 's/^/        /'
      nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader | sed 's/^/        GPU /'
    fi
    sleep 60; waited=$((waited+60))
  done
else
  say "STAGE0: SKIP_WAIT=1 -> starting immediately"
fi

# ------------------------------------------------------------
# STAGE 1 · CPU line (starts NOW, never touches the GPU)
#           CPU 线：立刻启动，全程不碰显卡
# ------------------------------------------------------------
say "STAGE1: launching CPU line (spectral audit + variant building)"

# locate the rank-16 reference adapters, with a fallback search
# 定位 rank-16 基准 adapter，找不到就自动搜
SRC_BIN="${SRC_BIN:-ckpts_sft/fpb_r16}"
SRC_TRI="${SRC_TRI:-ckpts_sft3/fpb_r16}"
if [ ! -f "$SRC_BIN/adapter_model.safetensors" ]; then
  ALT=$(find . -path ./ckpts_supp -prune -o -name adapter_config.json -print 2>/dev/null \
        | xargs -r grep -lE '"r"[: ]+16' 2>/dev/null | head -1 | xargs -r dirname)
  [ -n "${ALT:-}" ] && { say "  fallback SRC_BIN=$ALT"; SRC_BIN="$ALT"; }
fi
if [ ! -f "$SRC_TRI/adapter_model.safetensors" ]; then
  ALT=$(find . -path ./ckpts_supp -prune -o -name adapter_config.json -print 2>/dev/null \
        | xargs -r grep -lE '"r"[: ]+16' 2>/dev/null | sed -n '2p' | xargs -r dirname)
  [ -n "${ALT:-}" ] && { say "  fallback SRC_TRI=$ALT"; SRC_TRI="$ALT"; }
fi
say "  SRC_BIN=$SRC_BIN"
say "  SRC_TRI=$SRC_TRI"

(
  echo "=== CPU LINE START $(date '+%F %T') ==="
  echo "--- A1-A4 spectral audit ---"
  # Last run spent 2h20m here because three training jobs ate every CPU core.
  # Trim the audit to the adapters the paper actually uses unless FULL_AUDIT=1.
  # 上次这里跑了 2 小时 20 分，因为三个训练进程把 CPU 吃干了。
  # 默认只审计论文真正用到的 adapter；要看全量就 FULL_AUDIT=1。
  if [ "${FULL_AUDIT:-0}" = "1" ]; then
    AUDIT_ARGS="--noise-draws 20"
  else
    AUDIT_ARGS="--noise-draws 8 --include ckpts_sft --include ckpts_sft3 --include ckpts_supp --include ckpts_seed"
  fi
  echo "audit args: $AUDIT_ARGS"
  python scripts/supp/s1_rank_metrics.py $AUDIT_ARGS \
    --out "outputs/reports/supp_rank_metrics_${STAMP}.json" \
    2>&1 | tee "$LOGD/cpu_rank_metrics.log"

  echo "--- build variants from r=16 binary ---"
  if [ -f "$SRC_BIN/adapter_model.safetensors" ]; then
    python scripts/supp/s2_make_variants.py --src "$SRC_BIN" \
      --kinds energy,mask,randdir --stamp "$STAMP" \
      --out "outputs/reports/variants_bin_${STAMP}.json" 2>&1 | tee "$LOGD/cpu_variants_bin.log"
  else
    echo "SKIP: $SRC_BIN missing"
  fi

  echo "--- build variants from r=16 ternary ---"
  if [ -f "$SRC_TRI/adapter_model.safetensors" ]; then
    python scripts/supp/s2_make_variants.py --src "$SRC_TRI" \
      --kinds energy,mask,randdir --stamp "$STAMP" \
      --out "outputs/reports/variants_tri_${STAMP}.json" 2>&1 | tee "$LOGD/cpu_variants_tri.log"
  else
    echo "SKIP: $SRC_TRI missing"
  fi
  echo "=== CPU LINE DONE $(date '+%F %T') ==="
) >"$LOGD/cpu_line.log" 2>&1 &
CPU_PID=$!
say "  CPU line pid=$CPU_PID -> $LOGD/cpu_line.log"

# ------------------------------------------------------------
# STAGE 2 · GPU line (parallel with STAGE 1)
#           GPU 线：与 CPU 线同时跑，互不干扰
# ------------------------------------------------------------
say "STAGE2: launching GPU queue (parallel=${PAR})"
STAMP="$STAMP" PAR="$PAR" bash scripts/supp/s3_gpu_queue.sh 2>&1 | tee "$LOGD/gpu_queue.log"
GPU_RC=${PIPESTATUS[0]}
say "STAGE2: GPU queue exited rc=$GPU_RC"

# ------------------------------------------------------------
# STAGE 3 · wait for CPU line, then summarize / 等 CPU 线，然后汇总
# ------------------------------------------------------------
if kill -0 "$CPU_PID" 2>/dev/null; then
  say "STAGE3: waiting for CPU line (pid=$CPU_PID)"
  wait "$CPU_PID" || say "  CPU line exited non-zero (see $LOGD/cpu_line.log)"
else
  say "STAGE3: CPU line already finished"
fi

say "STAGE4: summarizing"
python scripts/supp/s4_summarize.py --stamp "$STAMP" 2>&1 | tee "$LOGD/summarize.log"

echo
echo "============================================================"
say "ALL DONE  stamp=$STAMP"
echo " logs      : $LOGD/"
echo " metrics   : outputs/reports/supp_rank_metrics_${STAMP}.json"
echo " variants  : outputs/reports/variants_*_${STAMP}.json"
echo " evals     : outputs/reports/eval_*.json"
echo " paper tbl : outputs/supp_${STAMP}/"
echo "============================================================"
