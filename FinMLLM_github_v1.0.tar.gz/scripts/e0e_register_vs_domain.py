#!/usr/bin/env python3
# ============================================================
# FinMLLM / e0e_register_vs_domain.py
# E0e — a 2-factor analysis on EXISTING adapters: does the weight spectrum
# encode DOMAIN or REGISTER (writing style)? No new training required.
# E0e —— 用现有 adapter 做双因子分析：权重谱编码的是"领域"还是"文体"？
# 不需要重新训练。
#
# Author : Raymond Xiaohu Fan
# Note   : A zero result becomes a finding the moment you ask the right factor question.
#          问对因子，零结果就变成了发现。
# Updated: 2026-10-23
#
# Usage / 用法:
#   python scripts/e0e_register_vs_domain.py --ckpt_dir ckpts
# ============================================================
import os, sys, json, glob, argparse, itertools
import numpy as np
from scipy.fftpack import dct

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)

# domain label and register label for each adapter we already have.
# 现有 adapter 的领域标签与文体标签。
# Two-level labelling: superdomain (finance vs general) and subdomain (business line).
# 两级标签：超领域（金融 vs 通用）与子域（业务线）。
META = {
    "bank":         {"super": "finance", "sub": "banking",    "register": "10-K"},
    "insurance":    {"super": "finance", "sub": "insurance",  "register": "10-K"},
    "securities":   {"super": "finance", "sub": "securities", "register": "10-K"},
    "general":      {"super": "finance", "sub": "finance-news", "register": "news"},
    "general_real": {"super": "general", "sub": "general",     "register": "wiki"},
}
# Registers that count as "different" from 10-K / from each other.
# 视为不同文体的登记。
ALL_REG = ["10-K", "news", "wiki"]


def dct2(x):
    return dct(dct(x.T, norm="ortho").T, norm="ortho")


def load_deltas(adapter_dir, max_layers=16, size=512):
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files:
        return []
    sd = load_file(files[0])
    out = []
    for k in sorted([k for k in sd if "lora_A" in k])[:max_layers]:
        kb = k.replace("lora_A", "lora_B")
        if kb not in sd:
            continue
        W = sd[kb].float().cpu().numpy() @ sd[k].float().cpu().numpy()
        h, w = W.shape
        sh, sw = min(h, size), min(w, size)
        i0, j0 = (h - sh) // 2, (w - sw) // 2
        out.append(W[i0:i0 + sh, j0:j0 + sw])
    return out


def coords_of(ws, k_pct):
    cs = []
    for W in ws:
        C = dct2(W); E = C ** 2
        flat = E.ravel()
        k = max(1, int(flat.size * k_pct / 100.0))
        cs.append(set(np.argpartition(flat, -k)[-k:].tolist()))
    return cs


def mean_jac(a, b):
    vals = []
    for x in a:
        for y in b:
            u = len(x | y)
            vals.append(len(x & y) / u if u else 0.0)
    return float(np.mean(vals))


def classify(a, b):
    """A = same register, different business line (does domain matter?)
       B = same superdomain (finance), different register (does register matter?)
       C = both differ
    对比：A 同文体不同业务线；B 同属金融但文体不同；C 两者都不同。"""
    ma, mb = META[a], META[b]
    same_reg = ma["register"] == mb["register"]
    same_sub = ma["sub"] == mb["sub"]
    same_super = ma["super"] == mb["super"]
    if same_reg and not same_sub:
        return "A: same-register / diff-business-line"
    if (not same_reg) and same_super:
        return "B: diff-register / same-finance-domain"
    if (not same_reg) and (not same_super):
        return "C: diff-register / diff-superdomain"
    return "identical"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_dir", default=os.path.join(ROOT, "ckpts"))
    ap.add_argument("--ks", default="0.5,1,2,5")
    ap.add_argument("--layers", type=int, default=16)
    ap.add_argument("--size", type=int, default=512)
    ap.add_argument("--perm", type=int, default=2000)
    args = ap.parse_args()

    ks = [float(x) for x in args.ks.split(",")]

    print("=" * 86)
    print(" E0e · REGISTER vs DOMAIN (2-factor) / 文体 vs 领域 双因子分析")
    print("=" * 86)

    packs = {}
    for d in sorted(glob.glob(os.path.join(args.ckpt_dir, "*_qlora*"))):
        name = os.path.basename(d).split("_qlora")[0]
        if name not in META:
            print(f"  ⏭️  {name}: 未登记在 META 中，跳过")
            continue
        ws = load_deltas(d, args.layers, args.size)
        if ws:
            packs[name] = ws
            m = META[name]
            print(f"  ✅ {name:<14}super={m['super']:<8}sub={m['sub']:<14}register={m['register']:<6}{len(ws)} layers")

    if len(packs) < 3:
        print("❌ adapter 不足 3 个")
        return 2

    names = list(packs)
    sem = {}
    print(f"\n{'k%':>6}  {'contrast':<34}{'pairs':<28}{'mean J':>9}")
    print("-" * 86)
    for k in ks:
        cs = {n: coords_of(packs[n], k) for n in names}
        bucket = {}
        for a, b in itertools.combinations(names, 2):
            c = classify(a, b)
            j = mean_jac(cs[a], cs[b])
            bucket.setdefault(c, []).append((f"{a}×{b}", j))
            print(f"{k:>6.1f}  {c:<34}{a+'×'+b:<28}{j:>9.4f}")
        sem[k] = bucket

    # summary + statistical contrast
    print("\n" + "=" * 86)
    print(" 汇总 / Summary")
    print("=" * 86)
    print(f"{'k%':>6}{'A: same-reg':>20}{'B: diff-reg':>20}{'A−B':>10}{'rel':>9}{'p':>8}  bootstrap 95% CI")
    print("-" * 86)

    rows = []
    for k in ks:
        A = [v for _, v in sem[k].get("A: same-register / diff-business-line", [])]
        B = [v for _, v in sem[k].get("B: diff-register / same-finance-domain", [])]
        if not A or not B:
            continue
        a_m, b_m = np.mean(A), np.mean(B)
        obs = a_m - b_m            # A > B is the register hypothesis / A>B 才支持文体假设
        pooled = A + B
        rng = np.random.RandomState(0)

        # one-sided permutation test: P(perm >= observed) / 单侧置换检验
        cnt = 0
        for _ in range(args.perm):
            idx = rng.permutation(len(pooled))
            pa = [pooled[i] for i in idx[:len(A)]]
            pb = [pooled[i] for i in idx[len(A):]]
            if (np.mean(pa) - np.mean(pb)) >= obs:
                cnt += 1
        p = cnt / args.perm

        # bootstrap 95% CI for the difference / 差值自助法置信区间
        boot = []
        rng2 = np.random.RandomState(1)
        for _ in range(args.perm):
            sa = [A[rng2.randint(len(A))] for _ in range(len(A))]
            sb = [B[rng2.randint(len(B))] for _ in range(len(B))]
            boot.append(np.mean(sa) - np.mean(sb))
        lo, hi = np.percentile(boot, [2.5, 97.5])

        rel = obs / b_m * 100 if b_m else 0.0
        verdict = "🎯 文体主导" if (obs > 0 and lo > 0) else ("趋势" if obs > 0 else "无")
        print(f"{k:>6.1f}{a_m:>20.4f}{b_m:>20.4f}{obs:>+10.4f}"
              f"{rel:>8.1f}%{p:>8.3f}  [{lo:+.4f},{hi:+.4f}]  {verdict}")
        rows.append({"k": k, "A_same_register": a_m, "B_diff_register": b_m,
                     "A_minus_B": obs, "relative_pct": rel, "p": p,
                     "ci_lo": lo, "ci_hi": hi,
                     "register_dominant": bool(obs > 0 and lo > 0)})

    print("\n" + "=" * 86)
    any_sig = any(r["register_dominant"] for r in rows)
    consistent = all(r["A_minus_B"] > 0 for r in rows) if rows else False
    if any_sig:
        print(" 🎯 结论：谱结构编码的是「文体」，不是「业务领域」")
        print("    → 正向主张：Spectral structure encodes REGISTER, not DOMAIN.")
        print("    → 这解释了 V1 零结果（三条线全是 10-K），并预测 V2 会出现更大差异。")
    elif consistent:
        print(" 📈 方向一致但置信区间含 0：文体效应存在但较弱")
        print("    → 可写成「弱文体效应」，并用 V2 的强文体对照来放大信号")
    else:
        print(" ⚠️  文体效应不成立 → 转 Fork C（部署经济学）")
    print("=" * 86)

    path = os.path.join(REP, "e0e_register_vs_domain.json")
    json.dump({"rows": rows}, open(path, "w"), indent=2, ensure_ascii=False)
    print(f"💾 saved -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
