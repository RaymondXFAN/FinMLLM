#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_para_baseline.py
# PARA 式全局阈值基线：跨层统一取奇异值分位数，而不是我们按有效秩比值定 k。
# PARA-style global threshold baseline for comparison with our diagnostic.
#
# 审稿人问"PARA 的全局阈值在你的 adapter 上会得到什么"。
# 这个脚本扫 5 档分位数，每档记录实际保留比例 + 体积，再交给评测脚本。
#
# Reviewer 2 asked exactly this. We sweep five percentiles, record the realised
# rank ratio and size, and hand each variant to the same evaluator.
#
# Author : Raymond Xiaohu Fan
# ============================================================
import os, sys, json, shutil, argparse
import numpy as np, torch
from safetensors.torch import load_file, save_file


def pairs_of(sd):
    return [(k, k.replace("lora_A", "lora_B")) for k in sd
            if "lora_A" in k and k.replace("lora_A", "lora_B") in sd]


def spec_of(A, B):
    """QR-core: 只在 r×r 空间取奇异值"""
    Qb, Rb = np.linalg.qr(B.astype(np.float32))
    Qa, Ra = np.linalg.qr(A.astype(np.float32).T)
    s = np.linalg.svd(Rb @ Ra.T, compute_uv=False)
    return Qb, Rb, Qa, Ra, s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out-root", default="ckpts_supp/para")
    ap.add_argument("--qs", default="50,60,70,80,90", help="保留的奇异值能量百分位")
    a = ap.parse_args()

    sd = load_file(os.path.join(a.src, "adapter_model.safetensors"))
    pr = pairs_of(sd)
    cfg = json.load(open(os.path.join(a.src, "adapter_config.json"), encoding="utf-8"))
    r0 = int(cfg.get("r", 16))

    # 一次性收集全局奇异值
    cache, all_s = [], []
    for ka, kb in pr:
        A = sd[ka].float().numpy(); B = sd[kb].float().numpy()
        Qb, Rb, Qa, Ra, s = spec_of(A, B)
        cache.append((ka, kb, Qb, Rb, Qa, Ra, s))
        all_s.append(s)
    flat = np.concatenate(all_s)
    print(f"全局奇异值 {len(flat)} 个，中位 {np.median(flat):.5f}")

    os.makedirs(a.out_root, exist_ok=True)
    manifest = []
    for q in [float(x) for x in a.qs.split(",")]:
        thr = np.percentile(flat, q)

        # PARA 原式：每层保留 s > thr 的方向，各层秩不同。
        # 但 PEFT 的 lora r 是全局参数，必须所有层同秩。
        # 折中：先按阈值数出总保留量，再折算成一个统一 k；
        # 这样压缩比与 PARA 对齐，做法上退化为"每层取前 k"。
        per_layer = []
        for ka, kb, Qb, Rb, Qa, Ra, s_ in cache:
            Um, Sm, Vmt = np.linalg.svd(Rb @ Ra.T, full_matrices=False)
            per_layer.append((ka, kb, Qb, Qa, Um, Sm, Vmt,
                              int(np.sum(Sm > thr))))
        total_keep = sum(x[7] for x in per_layer)
        total_full = sum(len(x[5]) for x in per_layer)
        k_uni = max(1, int(round(r0 * total_keep / total_full)))
        k_uni = min(k_uni, r0)

        new_sd = {k2: v for k2, v in sd.items()
                  if "lora_A" not in k2 and "lora_B" not in k2}
        for ka, kb, Qb, Qa, Um, Sm, Vmt, _ in per_layer:
            kk = min(k_uni, len(Sm))
            Bn = (Qb @ Um[:, :kk]) * np.sqrt(Sm[:kk])
            An = np.sqrt(Sm[:kk])[:, None] * (Vmt[:kk] @ Qa.T)
            new_sd[ka] = torch.from_numpy(np.ascontiguousarray(An, dtype=np.float32))
            new_sd[kb] = torch.from_numpy(np.ascontiguousarray(Bn, dtype=np.float32))

        out = os.path.join(a.out_root, f"para_q{int(q)}")
        os.makedirs(out, exist_ok=True)
        save_file({k: v.contiguous() for k, v in new_sd.items()},
                  os.path.join(out, "adapter_model.safetensors"))
        c2 = dict(cfg)
        c2["r"] = k_uni
        c2["lora_alpha"] = int(round(k_uni * float(cfg.get("lora_alpha", r0)) / r0))
        json.dump(c2, open(os.path.join(out, "adapter_config.json"), "w"), indent=2)
        for f in ("tokenizer_config.json", "special_tokens_map.json",
                  "tokenizer.json", "vocab.json", "merges.txt"):
            pth = os.path.join(a.src, f)
            if os.path.exists(pth):
                shutil.copy2(pth, os.path.join(out, f))
        sz = os.path.getsize(os.path.join(out, "adapter_model.safetensors")) / 1024**2
        manifest.append(dict(q=q, thr=float(thr), k_uniform=k_uni,
                             rank_ratio=round(k_uni / r0, 4),
                             size_mb=round(sz, 1), dir=out))
        print(f"  q={q:>4}  thr={thr:.5f}  k={k_uni:>2} (ratio {k_uni/r0:.3f})  {sz:.1f}MB")

    json.dump(manifest, open(os.path.join(a.out_root, "_manifest.json"), "w"), indent=2)
    print(f"\n{len(manifest)} 个变体 -> {a.out_root}")


if __name__ == "__main__":
    sys.exit(main())
