#!/usr/bin/env python3
# ============================================================
# FinMLLM / check_data.py  (v2)
# Data quality audit on the unified jsonl — not on raw HF caches.
# 对 unified/*.jsonl 做数据质量体检（不再检查 raw/ 的 HF 缓存形态）。
#
# Author : Raymond Xiaohu Fan
# Note   : A silent empty string can ruin a whole experiment. / 一个空字符串就能毁掉一次实验。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/check_data.py              # full audit / 完整体检
#   python scripts/check_data.py --sample 3   # also print samples / 额外打印样例
# ============================================================
import os, sys, json, glob, hashlib, argparse, time
from collections import Counter

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
UNI = os.path.join(ROOT, "data", "unified")
DOM = os.path.join(ROOT, "data", "domains")
REP = os.path.join(ROOT, "outputs", "reports")
os.makedirs(REP, exist_ok=True)

FLOORS = {"fpb": 4000, "fiqa_sa": 900, "finqa": 7000, "tfns": 9000,
          "edgar": 1000, "edgar_sec": 1000, "fineval_insurance": 100}

def pct(v, q):
    if not v: return 0
    v = sorted(v); i = min(len(v) - 1, int(q * len(v)))
    return v[i]

def audit(path, sample=0):
    n = empty = short = dup = html_like = nonascii = 0
    lens = []
    labels = Counter()
    seen = set()
    samples = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                r = json.loads(line)
            except Exception:
                empty += 1
                continue
            t = str(r.get("text", ""))
            n += 1
            if not t.strip():
                empty += 1
                continue
            L = len(t); lens.append(L)
            if L < 20: short += 1
            if "<" in t and ">" in t and ("div" in t.lower() or "span" in t.lower()):
                html_like += 1
            if any(ord(c) > 0xFFFF for c in t[:500]):
                nonascii += 1
            h = hashlib.md5(t[:200].encode("utf-8", "ignore")).hexdigest()
            if h in seen: dup += 1
            else: seen.add(h)
            lab = r.get("label", r.get("domain", "-"))
            labels[str(lab)[:20]] += 1
            if sample and len(samples) < sample:
                samples.append(t[:220].replace("\n", " "))
    return {"file": os.path.basename(path), "rows": n, "empty": empty, "short": short,
            "dup": dup, "html_like": html_like, "nonascii": nonascii,
            "len_mean": round(sum(lens)/len(lens), 1) if lens else 0,
            "len_p50": pct(lens, .5), "len_p95": pct(lens, .95), "len_max": max(lens) if lens else 0,
            "labels": dict(labels.most_common(8)), "samples": samples}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=0)
    args = ap.parse_args()

    print("=" * 78)
    print(f" DATA QUALITY AUDIT / 数据质量体检   {time.strftime('%F %T')}")
    print(f" root={ROOT}")
    print("=" * 78)
    print(f"{'file':<22}{'rows':>8}{'empty':>7}{'short':>7}{'dup':>7}{'len_p50':>9}{'len_p95':>9}{'max':>8}")
    print("-" * 78)

    report, bad = [], []
    for f in sorted(glob.glob(os.path.join(UNI, "*.jsonl"))):
        a = audit(f, args.sample)
        name = os.path.splitext(a["file"])[0]
        flag = ""
        if a["rows"] < FLOORS.get(name, 0): flag = "  ❌ below floor"
        if a["empty"] > 0: flag += f"  ⚠️ empty={a['empty']}"
        if a["rows"] and a["dup"] / a["rows"] > 0.3: flag += f"  ⚠️ dup={a['dup']/a['rows']:.0%}"
        print(f"{a['file']:<22}{a['rows']:>8}{a['empty']:>7}{a['short']:>7}{a['dup']:>7}"
              f"{a['len_p50']:>9}{a['len_p95']:>9}{a['len_max']:>8}{flag}")
        report.append(a)
        if flag: bad.append(name)
        if args.sample and a["samples"]:
            for s in a["samples"]:
                print(f"      · {s}")

    print("\n── Business lines / 业务线 ─────────────────────────────────")
    for f in sorted(glob.glob(os.path.join(DOM, "*.jsonl"))):
        a = audit(f, 0)
        print(f"  {a['file']:<24}{a['rows']:>8} rows   dup={a['dup']}   "
              f"len_p50={a['len_p50']}   labels={a['labels']}")

    out = os.path.join(REP, f"data_audit_{time.strftime('%Y%m%d_%H%M%S')}.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, ensure_ascii=False)
    print(f"\n报告已保存 / report -> {out}")
    print("=" * 78)
    print("🎉 全部达标 / all good" if not bad else f"⚠️ 需关注 / check: {bad}")
    return 0 if not bad else 1

if __name__ == "__main__":
    raise SystemExit(main())
