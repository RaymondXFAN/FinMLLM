#!/usr/bin/env bash
# ============================================================
# FinMLLM / lib_probe.sh
# A tiny observability library: every step leaves a breadcrumb so a failure
# can be traced back to the exact file, line and command.
# 极简可观测性库：每一步都留面包屑，出错时能精确回溯到文件、行号、命令。
#
# Author : Raymond Xiaohu Fan
# Note   : A log line costs nothing; a silent failure costs a weekend. / 一行日志不花钱，一次静默失败能毁掉一个周末。
# Updated: 2026-10-19
#
# Usage / 用法:
#   source scripts/lib_probe.sh
#   probe_init "download"
#   step "parallel-download"
#   ... commands ...
#   step_done
# ============================================================

PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
PROBE_DIR="${PROBE_DIR:-$PROJ/outputs/logs}"
mkdir -p "$PROBE_DIR" 2>/dev/null || true
PROBE_TAG="${PROBE_TAG:-run}"
PROBE_LOG="$PROBE_DIR/probe_${PROBE_TAG}_$(date +%Y%m%d).log"
STEP_NO=0

# Colour only when attached to a terminal / 仅在终端下着色
if [ -t 1 ]; then C_G="\033[32m"; C_Y="\033[33m"; C_R="\033[31m"; C_0="\033[0m"; else C_G=""; C_Y=""; C_R=""; C_0=""; fi

probe_init () {
  PROBE_TAG="${1:-run}"
  PROBE_LOG="$PROBE_DIR/probe_${PROBE_TAG}_$(date +%Y%m%d).log"
  {
    echo "============================================================"
    echo "[$(date '+%F %T')] PROBE INIT tag=$PROBE_TAG pid=$$ host=$(hostname) user=$(whoami)"
    echo "  cwd=$(pwd)"
    echo "  script=${BASH_SOURCE[1]:-unknown}"
    echo "  argv=$*"
    echo "============================================================"
  } >> "$PROBE_LOG"
  # ERR trap: catch everything that fails / 捕获所有失败
  set -E
  trap '_probe_err $? $LINENO "${BASH_SOURCE[0]}" "$BASH_COMMAND"' ERR
  trap '_probe_exit $?' EXIT
}

_probe_err () {
  local rc="$1" line="$2" src="$3" cmd="$4"
  { echo "[$(date '+%F %T')] ❌ ERROR rc=$rc at ${src}:${line}"
    echo "    command: $cmd"
    echo "    cwd: $(pwd)"
    echo "    last steps:"; tail -5 "$PROBE_LOG" 2>/dev/null | sed 's/^/      /'
  } | tee -a "$PROBE_LOG"
}

_probe_exit () {
  local rc="$1"
  echo "[$(date '+%F %T')] PROBE EXIT rc=$rc tag=$PROBE_TAG" >> "$PROBE_LOG"
}

# step "name" -> prints and logs a numbered breadcrumb / 打印并记录编号面包屑
step () {
  STEP_NO=$((STEP_NO+1))
  local msg="[$(date '+%F %T')] ▶ step ${STEP_NO}: $*"
  echo -e "${C_G}${msg}${C_0}"
  echo "$msg" >> "$PROBE_LOG"
}

# step_ok "note" -> mark success / 标记成功
step_ok () {
  local msg="[$(date '+%F %T')] ✔ step ${STEP_NO} done: ${1:-ok} (${SECONDS}s elapsed)"
  echo -e "${C_G}${msg}${C_0}"
  echo "$msg" >> "$PROBE_LOG"
}

# step_warn "note" -> mark a non-fatal issue / 标记非致命问题
step_warn () {
  local msg="[$(date '+%F %T')] ⚠ step ${STEP_NO} warning: $*"
  echo -e "${C_Y}${msg}${C_0}"
  echo "$msg" >> "$PROBE_LOG"
}

# probe "free text" -> arbitrary breadcrumb / 任意面包屑
probe () {
  local msg="[$(date '+%F %T')] · $*"
  echo "$msg" >> "$PROBE_LOG"
  echo "$msg"
}

# run_step "name" cmd... -> timed + traced execution with rc handling
# 带计时与追踪的步骤执行；失败不退出（除非 STRICT=1）
run_step () {
  local name="$1"; shift
  step "$name"
  local t0=$SECONDS
  if "$@"; then
    echo "[$(date '+%F %T')] ✔ $name rc=0 dur=$((SECONDS-t0))s" >> "$PROBE_LOG"
    return 0
  else
    local rc=$?
    step_warn "$name failed rc=$rc dur=$((SECONDS-t0))s"
    [ "${STRICT:-0}" = "1" ] && return $rc
    return 0
  fi
}
