#!/usr/bin/env bash
# ============================================================
# FinMLLM / status.sh
# One-screen status panel for every background job: alive or dead, how long,
# what it is doing right now, and what broke.
# 一屏看板：所有后台任务是死是活、跑了多久、现在在干什么、哪里报错。
#
# Author : Raymond Xiaohu Fan
# Note   : Closing the lid shouldn't mean closing your eyes. / 合上盖子，不代表要闭上眼。
# Updated: 2026-10-19
#
# Usage / 用法:
#   bash scripts/status.sh            # one-shot / 单次
#   bash scripts/status.sh --watch    # refresh every 5s / 每5秒刷新
# ============================================================
PROJ="${PROJ:-/root/autodl-tmp/FinMLLM}"
INTERVAL="${INTERVAL:-5}"

render () {
  clear 2>/dev/null || true
  echo "================================================================"
  echo " FinMLLM STATUS  |  $(date '+%F %T')  |  host=$(hostname)"
  echo " proj=$PROJ"
  echo "================================================================"

  echo ""
  echo "── Disk / 磁盘 ──────────────────────────────────────────────"
  df -h /root/autodl-tmp 2>/dev/null | tail -1
  echo "  data/raw : $(du -sh "$PROJ/data/raw" 2>/dev/null | cut -f1 || echo '-')"
  echo "  runs     : $(du -sh "$PROJ/runs" 2>/dev/null | cut -f1 || echo '-')"

  echo ""
  echo "── GPU / 显卡 ───────────────────────────────────────────────"
  if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv,noheader 2>/dev/null \
      || echo "  GPU not available / 无 GPU（无卡模式正常）"
  else
    echo "  nvidia-smi not found（无卡模式正常）"
  fi

  echo ""
  echo "── Jobs / 任务 ──────────────────────────────────────────────"
  printf "%-28s %-8s %-10s %s\n" "RUN_ID" "STATE" "ELAPSED" "LAST LOG"
  local latest=""
  [ -f "$PROJ/runs/.latest" ] && latest="$(cat "$PROJ/runs/.latest")"

  for d in $(ls -1dt "$PROJ"/runs/*/ 2>/dev/null | head -10); do
    local id; id="$(basename "$d")"
    local pid=""; [ -f "$d/pid" ] && pid="$(cat "$d/pid")"
    local state="UNKNOWN"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      state="RUNNING"
    elif [ -f "$d/logs/.done" ]; then
      state="DONE"
    elif [ -f "$d/logs/.failed" ]; then
      state="FAILED"
    else
      state="STOPPED"
    fi
    local elapsed="-"
    if [ -f "$d/env_snapshot.txt" ]; then
      local st; st="$(grep '^started=' "$d/env_snapshot.txt" | cut -d= -f2-)"
      if [ -n "$st" ]; then
        local s0 s1; s0=$(date -d "$st" +%s 2>/dev/null || echo 0); s1=$(date +%s)
        [ "$s0" -gt 0 ] && elapsed="$(( (s1-s0)/60 ))m$(( (s1-s0)%60 ))s"
      fi
    fi
    local last=""
    if [ -f "$d/logs/stdout.log" ]; then
      last="$(tail -1 "$d/logs/stdout.log" 2>/dev/null | tr -d '\r' | cut -c1-60)"
    fi
    local mark=" "; [ "$id" = "$latest" ] && mark="*"
    printf "%s%-27s %-8s %-10s %s\n" "$mark" "$id" "$state" "$elapsed" "$last"
  done

  echo ""
  echo "── Failures / 失败项 ────────────────────────────────────────"
  if [ -s "$PROJ/data/raw/failed.txt" ]; then
    cat "$PROJ/data/raw/failed.txt" | sed 's/^/  ❌ /'
  else
    echo "  (none / 无)"
  fi

  echo ""
  echo "── Probe tail / 探针尾部 ────────────────────────────────────"
  local plog; plog="$(ls -1t "$PROJ"/outputs/logs/probe_*.log 2>/dev/null | head -1)"
  if [ -n "$plog" ]; then
    echo "  $plog"
    tail -6 "$plog" | sed 's/^/  /'
  else
    echo "  (no probe log yet / 暂无探针日志)"
  fi

  echo ""
  echo "================================================================"
  echo " Ctrl-C to exit. / Ctrl-C 退出。"
}

if [ "${1:-}" = "--watch" ]; then
  trap 'echo; echo "watch stopped / 已停止"; exit 0' INT
  while true; do render; sleep "$INTERVAL"; done
else
  render
fi
