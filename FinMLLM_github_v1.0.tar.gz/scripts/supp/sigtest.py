#!/usr/bin/env python3
# ============================================================
# FinMLLM / supp / sigtest.py
# Significance tests for the compression claims.
# 压缩主张的显著性检验 —— 审稿人一定会问"这两个点是不是噪声"。
#
# Two tools / 两个工具:
#   McNemar  paired test on the SAME samples (needs --save-preds evals)
#            McNemar 配对检验（需要评测时带 --save-preds）
#   bootstrap  95% CI for an accuracy difference / 准确率差的 bootstrap 置信区间
#
# Author : Raymond Xiaohu Fan
# Note   : "0.6749 vs 0.6543" is not a result. "0.6749 vs 0.6543, p=0.55" is.
#          光报两个数不叫结果，带上 p 值才叫结果。
# Updated: 2026-10-25
#
# Usage / 用法:
#   python scripts/supp/sigtest.py --auto
#   python scripts/supp/sigtest.py --pair outputs/reports/eval_fiqa_sft3_r16.json \
#                                        outputs/reports/eval_fiqa_sft3_r1.json
# ============================================================
import os, sys, json, glob, argparse, math, random
from itertools import combinations

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
REP = os.path.join(PROJ, "outputs", "reports")


def mcnemar_exact(n01, n10):
    """Two-sided exact McNemar p-value via the binomial distribution.
    双侧精确 McNemar 检验（二项分布，小样本比卡方更稳）。"""
    n = n01 + n10
    if n == 0:
        return 1.0
    k = min(n01, n10)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / (2 ** n)
    return min(1.0, 2 * tail)


def bootstrap_ci(correct_a, correct_b, n_boot=5000, seed=0):
    """Paired bootstrap CI for (acc_a - acc_b). 配对 bootstrap 置信区间。"""
    n = len(correct_a)
    rng = random.Random(seed)
    diffs = []
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        a = sum(correct_a[i] for i in idx) / n
        b = sum(correct_b[i] for i in idx) / n
        diffs.append(a - b)
    diffs.sort()
    return diffs[int(0.025 * n_boot)], diffs[int(0.975 * n_boot)]


def load_preds(path):
    d = json.load(open(path))
    pr = d.get("preds")
    if not pr:
        return None, d
    return pr, d


def compare(pa, pb, name_a="A", name_b="B"):
    a, da = load_preds(pa)
    b, db = load_preds(pb)
    if a is None or b is None:
        return {"error": "missing preds; rerun eval with --save-preds",
                "a": os.path.basename(pa), "b": os.path.basename(pb)}

    # align by sample index / 按样本索引对齐
    ma = {r["i"]: r for r in a}
    mb = {r["i"]: r for r in b}
    common = sorted(set(ma) & set(mb))
    if not common:
        return {"error": "no overlapping sample indices"}

    ca = [ma[i]["ok"] for i in common]
    cb = [mb[i]["ok"] for i in common]
    n = len(common)

    # McNemar contingency / 配对四格表
    n01 = sum(1 for x, y in zip(ca, cb) if x == 0 and y == 1)   # A wrong, B right
    n10 = sum(1 for x, y in zip(ca, cb) if x == 1 and y == 0)   # A right, B wrong
    p = mcnemar_exact(n01, n10)
    lo, hi = bootstrap_ci(ca, cb)

    acc_a, acc_b = sum(ca) / n, sum(cb) / n
    return {
        "a": os.path.basename(pa), "b": os.path.basename(pb), "n": n,
        "acc_a": acc_a, "acc_b": acc_b, "delta": acc_a - acc_b,
        "delta_pp": (acc_a - acc_b) * 100,
        "ci95_low_pp": lo * 100, "ci95_high_pp": hi * 100,
        "n_a_wrong_b_right": n01, "n_a_right_b_wrong": n10,
        "mcnemar_p": p,
        "significant_at_05": p < 0.05,
        "significant_at_01": p < 0.01,
    }


def fmt(r):
    if "error" in r:
        return f"  {r['a']} vs {r['b']}: ⚠️  {r['error']}"
    star = "***" if r["mcnemar_p"] < 0.001 else "**" if r["mcnemar_p"] < 0.01 \
        else "*" if r["mcnemar_p"] < 0.05 else "n.s."
    return (f"  {r['a'][:34]:<36} vs {r['b'][:34]:<36} "
            f"n={r['n']:<5} Δ={r['delta_pp']:+6.2f}pp  "
            f"CI[{r['ci95_low_pp']:+5.2f},{r['ci95_high_pp']:+5.2f}]  "
            f"p={r['mcnemar_p']:.4f} {star}")


def auto_pairs():
    """Find every (r16, r1) style pair that has preds saved. 自动配对。"""
    files = glob.glob(os.path.join(REP, "eval_*.json"))
    have = []
    for f in files:
        pr, d = load_preds(f)
        if pr:
            have.append((os.path.basename(f)[:-5], f))
    results = []
    for name, f in have:
        for other_name, other_f in have:
            if name == other_name:
                continue
            if name.endswith("_r16") and other_name == name[:-4] + "_r1":
                results.append(compare(f, other_f))
            if name.endswith("_full") and other_name == name[:-5] + "_r4":
                results.append(compare(f, other_f))
    return results, len(have)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pair", nargs=2, default=None)
    ap.add_argument("--auto", action="store_true")
    ap.add_argument("--out", default=os.path.join(REP, "sigtest_results.json"))
    args = ap.parse_args()

    print("=" * 118)
    print(" SIGNIFICANCE TESTS / 显著性检验")
    print("=" * 118)

    rows = []
    if args.pair:
        rows = [compare(args.pair[0], args.pair[1])]
    elif args.auto:
        rows, n_have = auto_pairs()
        print(f" found {n_have} eval files carrying per-sample predictions")
        if n_have == 0:
            print(" ⚠️  none. Re-run your evals with --save-preds first.")
            return 2

    if not rows:
        print(" nothing to compare / 没有可比较的配对")
        return 2

    print()
    print(f" {'A':<36}   {'B':<36} {'n':<7} {'delta':>10}  {'95% CI (pp)':>18}  p-value")
    print(" " + "-" * 116)
    for r in rows:
        print(fmt(r))

    print(" " + "-" * 116)
    print(" Interpretation / 解读:")
    sig = [r for r in rows if "error" not in r and r["significant_at_05"]]
    if sig:
        print(f"  {len(sig)} of {len(rows)} pairs differ significantly at p<0.05.")
        print(f"  {len(sig)}/{len(rows)} 对在 p<0.05 水平显著不同 —— 这些不能再写'零损失'。")
    else:
        print(f"  None of the {len(rows)} pairs differ significantly at p<0.05.")
        print("  → 可以写 'no statistically significant degradation (McNemar, p>0.05)'。")
        print(f"  {len(rows)} 对全部不显著 —— 可以放心写'无统计显著退化'。")

    json.dump({"pairs": rows}, open(args.out, "w"), indent=2, ensure_ascii=False)
    print(f"\n💾 saved -> {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
