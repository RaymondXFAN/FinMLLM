#!/usr/bin/env python3
# ============================================================
# FinMLLM / g5_transfer.py
# G5 cross-domain gate: verify that Gamma_D profiles actually differ.
# G5 跨域 gate：验证 Γ_D 谱轮廓真的能区分业务线。
#
# Author : Raymond Xiaohu Fan
# Note   : If the spectra look identical, the story is over. / 谱如果一样，故事就结束了。
# Updated: 2026-10-19
# ============================================================

"""G5 · 跨域 gate（需 GPU 或已有 adapter）。

目标：确认 Γ_D 能区分不同业务线（KL 非对角 > 0），即"谱身份"真的存在。
若 ckpts 下已有 adapter -> 用真实 ΔW；否则用合成 ΔW 只验证流程。
"""
import os, sys, glob, json, itertools
import numpy as np
from scipy.fftpack import dct, idct

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
CKPT = os.path.join(ROOT, "ckpts")
OUT = os.path.join(ROOT, "outputs/logs"); os.makedirs(OUT, exist_ok=True)

def dct2(x):  return dct(dct(x.T, norm="ortho").T, norm="ortho")
def idct2(X): return idct(idct(X.T, norm="ortho").T, norm="ortho")

def gamma_profile(X, n_bands=10):
    """Γ_D：10 个频率环带（比 3 带敏感得多；3 带在随机权重下几乎不可分）。"""
    C = dct2(X); E = np.abs(C) ** 2
    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    r = np.sqrt((yy/max(h-1,1))**2 + (xx/max(w-1,1))**2); r /= r.max()
    edges = np.linspace(0, 1, n_bands+1)
    p = np.array([E[(r>=edges[i])&(r<=edges[i+1]+1e-12)].sum() for i in range(n_bands)])
    return p / p.sum() if p.sum() > 0 else p

def spectral_stats(X, n_bands=10):
    """附加两个细粒度指标：低频能量占比、谱熵（越低越集中）。"""
    C = dct2(X); E = np.abs(C) ** 2
    h, w = E.shape
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    r = np.sqrt((yy/max(h-1,1))**2 + (xx/max(w-1,1))**2); r /= r.max()
    low = float(E[r <= 0.3].sum() / max(E.sum(), 1e-12))
    p = (E / max(E.sum(), 1e-12)).ravel()
    H = float(-np.sum(p * np.log(p + 1e-12)))
    return low, H

def kl(p, q, eps=1e-12):
    p = np.asarray(p)+eps; q = np.asarray(q)+eps
    p /= p.sum(); q /= q.sum()
    return float(np.sum(p*np.log(p/q)))

def load_delta(adapter_dir):
    """从 safetensors 读 lora_A / lora_B，拼成 ΔW=B@A 的 2D 矩阵集合。"""
    from safetensors.torch import load_file
    files = glob.glob(os.path.join(adapter_dir, "*.safetensors"))
    if not files: return None
    sd = load_file(files[0])
    As = {k: v for k, v in sd.items() if "lora_A" in k}
    Bs = {k: v for k, v in sd.items() if "lora_B" in k}
    keys = [k for k in As if k.replace("lora_A", "lora_B") in Bs]
    if not keys: return None
    ws = []
    for k in sorted(keys)[:16]:
        A = As[k].float().numpy(); B = Bs[k.replace("lora_A","lora_B")].float().numpy()
        W = B @ A
        # 截成方阵便于 DCT
        n = min(W.shape) 
        ws.append(W[:n, :n])
    return ws

def synthetic(seed, n=64):
    rng = np.random.default_rng(seed)
    return [rng.standard_normal((n, n)) * 0.02 for _ in range(8)]

if __name__ == "__main__":
    print("=" * 70); print("G5 · 跨域谱身份 gate"); print("=" * 70)
    doms = ["bank", "insurance", "securities", "regulator"]
    profiles, mode = {}, "synthetic"

    for d in doms:
        cand = os.path.join(CKPT, f"{d}_qlora")
        ws = load_delta(cand) if os.path.isdir(cand) else None
        if ws:
            mode = "real"
            profiles[d] = np.mean([gamma_profile(w) for w in ws], axis=0)
            print(f"✅ {d}: 读取真实 adapter（{len(ws)} 层）")
        else:
            profiles[d] = np.mean([gamma_profile(w) for w in synthetic(hash(d) % 1000)], axis=0)
            print(f"⚠️  {d}: 无 adapter，用合成 ΔW 验证流程")

    print(f"\n模式：{'真实权重' if mode=='real' else '合成权重（仅流程验证）'}")
    print("\nΓ_D 谱轮廓（低/中/高频能量占比）：")
    for d, p in profiles.items():
        print(f"  {d:<11} {np.round(p, 4)}")

    print("\nKL 矩阵（行=源，列=目标）：")
    names = list(profiles)
    M = np.zeros((len(names), len(names)))
    for i, j in itertools.product(range(len(names)), repeat=2):
        M[i, j] = kl(profiles[names[i]], profiles[names[j]])
    print("            " + "".join(f"{n[:10]:>12}" for n in names))
    for i, n in enumerate(names):
        print(f"{n:<12}" + "".join(f"{M[i,j]:>12.4f}" for j in range(len(names))))

    offdiag = [M[i, j] for i, j in itertools.permutations(range(len(names)), 2)]
    nonzero = sum(1 for x in offdiag if x > 1e-6)
    print(f"\n{'✅' if nonzero == len(offdiag) else '❌'} 非对角 KL > 0 : {nonzero}/{len(offdiag)}")
    if mode == "real":
        print("🎉 G5 PASS（真实权重下谱身份可分）" if nonzero == len(offdiag)
              else "⚠️ G5 FAIL：谱轮廓雷同，回到 G3 查 lora_B")
    else:
        print("ℹ️ G5 流程验证通过；待真实 adapter 产出后必须重跑")

    with open(os.path.join(OUT, "g5_kl_matrix.json"), "w") as f:
        json.dump({"mode": mode, "domains": names, "profiles": {k: v.tolist() for k, v in profiles.items()},
                   "kl": M.tolist()}, f, indent=2, ensure_ascii=False)
    print(f"已保存 -> {OUT}/g5_kl_matrix.json")
