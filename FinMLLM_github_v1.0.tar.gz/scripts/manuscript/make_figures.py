#!/usr/bin/env python3
# ============================================================
# FinMLLM / make_figures.py
# 莫兰迪色系 / 300 DPI / 全英文标注，直接能进论文。
# Morandi palette, 300 DPI, English labels — drop-in for the manuscript.
#
# 说实话，前面几个月我一直在跟数字较劲，表格拉了七八张，读者肯定看困了。
# 这一版把"趋势"和"对比"都画出来，能一眼看明白的就别让人读表。
# I have been staring at these numbers for months. Time to let the reader
# see the shape of them instead of reading a wall of digits.
#
# Fig 2  compression–accuracy frontier   （趋势：体积 vs 精度）
# Fig 3  effective rank vs nominal rank  （对比：adapter vs 噪声）
# Fig 4  energy axis vs rank axis        （对比：两种准则的保守程度）
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-11-08
#
# Usage / 用法:
#   python scripts/make_figures.py
#   python scripts/make_figures.py --only fig2
# ============================================================
import os, sys, argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

OUT = os.environ.get("FIGDIR", "outputs/figs")
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------
# 莫兰迪色板：低饱和、带灰调，打印和投影都不刺眼
# Morandi palette: desaturated, grey-shifted, easy on both paper and screen
# ------------------------------------------------------------
M = dict(
    sage="#A3B18A",    # 灰绿  — 二分类 / binary
    clay="#B5838D",    # 灰粉  — 三分类 / ternary
    stone="#8E9AAF",   # 灰蓝  — 噪声基线 / noise baseline
    sand="#DDBEA9",    # 浅米  — 辅助填充
    mist="#A5A58D",    # 灰橄榄
    slate="#6D6875",   # 深灰紫 — 参考线
    ink="#4A4A4A",     # 文字
    grid="#E4E0DC",    # 网格
)

plt.rcParams.update({
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.edgecolor": M["ink"],
    "axes.labelcolor": M["ink"],
    "xtick.color": M["ink"],
    "ytick.color": M["ink"],
    "axes.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "savefig.bbox": "tight",
})

# ------------------------------------------------------------
# 数据：全部来自 10_实验结果总表.md（FINAL）
# Data: verbatim from the results table. If a number changes, change it here.
# ------------------------------------------------------------
RANK = [16, 8, 4, 2, 1]
SIZE_MB = [115.0, 57.1, 28.5, 14.3, 7.1]

BIN_MEAN = [0.98778, 0.99000, 0.98889, 0.99000, 0.98667]
BIN_SD = [0.00419, 0.00000, 0.00419, 0.00000, 0.00272]

TRI_SEEDS = {
    16: [0.7933, 0.8400, 0.7967],
    8: [0.7900, 0.8400, 0.8033],
    4: [0.7800, 0.8433, 0.8200],
    2: [0.7800, 0.8533, 0.8300],
    1: [0.8233, 0.8667, 0.8567],
}
TRI_MEAN = [float(np.mean(TRI_SEEDS[k])) for k in RANK]
TRI_SD = [float(np.std(TRI_SEEDS[k])) for k in RANK]

# effective rank（Table 3），只取 r>=2：rank-1 的 stable rank 恒为 1，没有信息量
ER = {
    "binary r=16": dict(r=16, s=[1.98], n=[13.55]),
    "ternary r=16": dict(r=16, s=[1.86], n=[13.55]),
    "r=64 (3 seeds)": dict(r=64, s=[2.33, 2.31, 2.36], n=[45.29]),
}
# 沿 r 的曲线，升序排列（之前写成降序，线是倒着画的，加上对数轴更乱）
# Ascending order: I had it descending before and the line ran backwards on a
# log axis. Lesson: sort your x before you plot.
ER_R = [2, 4, 8, 16]
ER_S_BIN = [1.32, 1.58, 1.81, 1.98]     # ckpts_sft/fpb_r{2,4,8,16}
ER_S_TRI = [1.28, 1.51, 1.71, 1.86]     # ckpts_sft3/fpb_r{2,4,8,16}
NOISE_R = [1.93, 3.73, 7.20, 13.55]     # same-shape Gaussian, by r
ER_RATIO_BIN = [0.68, 0.42, 0.25, 0.15]


def save(fig, name):
    for ext in ("png", "pdf"):
        p = os.path.join(OUT, f"{name}.{ext}")
        fig.savefig(p)
    print(f"  ✅ {name}.png / .pdf  -> {OUT}")
    plt.close(fig)


# ------------------------------------------------------------
# Fig 2 · 压缩-精度前沿
# 横轴用体积(对数)而不是 rank —— 读者关心的是"省了多少硬盘"
# X axis is file size on a log scale, not rank: readers budget in megabytes.
# ------------------------------------------------------------
def fig2():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=False)

    for ax, mean, sd, color, label, ylim in [
        (axes[0], BIN_MEAN, BIN_SD, M["sage"], "Binary (pos / neg)", (0.96, 1.005)),
        (axes[1], TRI_MEAN, TRI_SD, M["clay"], "Ternary (pos / neu / neg)", (0.74, 0.90)),
    ]:
        ax.axhspan(mean[0] - sd[0], mean[0] + sd[0], color=M["grid"], alpha=0.55, zorder=0,
                   label="±1 SD of uncompressed")
        ax.errorbar(SIZE_MB, mean, yerr=sd, color=color, marker="o", ms=5,
                    lw=1.8, capsize=3, capthick=0.9, elinewidth=0.9,
                    markeredgecolor="white", markeredgewidth=0.8, zorder=3,
                    label=label)
        for x, y, r in zip(SIZE_MB, mean, RANK):
            if r == 16:
                ax.annotate(f"r={r}", (x, y), textcoords="offset points",
                            xytext=(-2, 11), ha="right", fontsize=7.5, color=M["ink"])
            elif r == 1:
                ax.annotate(f"r={r}", (x, y), textcoords="offset points",
                            xytext=(2, 11), ha="left", fontsize=7.5, color=M["ink"])
        ax.set_xscale("log")
        ax.set_xticks(SIZE_MB)
        ax.set_xticklabels([f"{s:g}" for s in SIZE_MB], fontsize=7.5)
        ax.set_xlabel("Adapter size (MB, log scale)", fontsize=8.5)
        ax.set_ylim(*ylim)
        ax.grid(axis="y", color=M["grid"], lw=0.7, zorder=0)
        ax.set_axisbelow(True)
        ax.legend(fontsize=7, loc="best")

    axes[0].set_ylabel("Accuracy", fontsize=8.5)
    axes[0].set_title("(a) Binary task", fontsize=9, color=M["ink"], pad=6)
    axes[1].set_title("(b) Ternary task", fontsize=9, color=M["ink"], pad=6)

    # 16x 箭头
    for ax in axes:
        y0 = ax.get_ylim()[0] + 0.06 * (ax.get_ylim()[1] - ax.get_ylim()[0])
        ax.annotate("", xy=(7.1, y0), xytext=(115, y0),
                    arrowprops=dict(arrowstyle="<->", color=M["slate"], lw=0.9,
                                    shrinkA=2, shrinkB=2))
        ax.text(28.6, y0 + 0.012 * (ax.get_ylim()[1] - ax.get_ylim()[0]),
                "16× smaller", ha="center", fontsize=7.2, color=M["slate"], style="italic")

    fig.tight_layout(w_pad=2.0)
    save(fig, "fig2_compression_accuracy")


# ------------------------------------------------------------
# Fig 3 · 有效秩随配置秩的变化
# 这张图要说明一件事：adapter 的 stable rank 几乎不涨，噪声却线性涨
# One message: the adapter's stable rank barely moves while the noise baseline climbs.
# ------------------------------------------------------------
def fig3():
    fig, ax = plt.subplots(figsize=(4.6, 3.1))

    ax.plot(ER_R, NOISE_R, ls="--", lw=1.4, color=M["stone"],
            marker="s", ms=4.5, markeredgecolor="white", markeredgewidth=0.7,
            label="Gaussian baseline (same shape)")
    ax.plot(ER_R, ER_S_BIN, lw=1.8, color=M["sage"],
            marker="o", ms=5.5, markeredgecolor="white", markeredgewidth=0.8,
            label="Binary adapter (measured)")
    ax.plot(ER_R, ER_S_TRI, lw=1.5, ls="-.", color=M["clay"],
            marker="^", ms=4.5, markeredgecolor="white", markeredgewidth=0.7,
            label="Ternary adapter (measured)")

    # r=64 三个种子单点
    ax.scatter([64] * 3, ER["r=64 (3 seeds)"]["s"], s=26, color=M["sage"],
               edgecolor="white", linewidth=0.8, zorder=4)
    ax.scatter([64], [45.29], s=26, marker="s", color=M["stone"],
               edgecolor="white", linewidth=0.8, zorder=4)

    for r, n, ratio in zip(ER_R, NOISE_R, ER_RATIO_BIN):
        ax.annotate(f"{ratio:.2f}", (r, n), textcoords="offset points",
                    xytext=(9, 6), fontsize=6.5, color=M["slate"], style="italic")
    ax.annotate("0.05", (64, 45.29), textcoords="offset points", xytext=(6, 4),
                fontsize=6.5, color=M["slate"], style="italic")

    ax.annotate("binary / noise", (16, 13.55), textcoords="offset points",
                xytext=(-4, 14), ha="right", fontsize=6.5, color=M["slate"])

    ax.set_xscale("log", base=2)
    ax.set_xticks([2, 4, 8, 16, 32, 64])
    ax.set_xticklabels(["2", "4", "8", "16", "32", "64"], fontsize=8)
    ax.set_xlabel("Nominal rank $r$", fontsize=8.5)
    ax.set_ylabel("Stable rank (effective)", fontsize=8.5)
    ax.set_ylim(0, 50)
    ax.grid(color=M["grid"], lw=0.7)
    ax.set_axisbelow(True)
    ax.legend(fontsize=7, loc="upper left")
    ax.set_title("Effective rank does not follow the budget", fontsize=9, pad=6)

    fig.tight_layout()
    save(fig, "fig3_effective_rank")


# ------------------------------------------------------------
# Fig 4 · 能量轴 vs 秩轴
# 这条图就是"95% 能量太保守"的视觉版：能量曲线早就平了，秩轴还能再砍
# This is the picture version of "95% energy is too conservative".
# ------------------------------------------------------------
def fig4():
    e_kept = [99, 95, 90, 80, 70, 60]
    e_rank = [16, 14, 12, 9, 7, 5]
    e_size = [114.3, 100.0, 85.7, 64.3, 50.0, 35.7]
    e_acc_bin = [0.9867, 0.9900, 0.9900, 0.9900, 0.9900, 0.9900]
    e_acc_tri = [0.7900, 0.7900, 0.7867, 0.7933, 0.7867, 0.7933]

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))

    # 左：精度 vs 保留能量
    ax = axes[0]
    ax.plot(e_kept, e_acc_bin, lw=1.8, color=M["sage"], marker="o", ms=5,
            markeredgecolor="white", markeredgewidth=0.8, label="Binary")
    ax.plot(e_kept, e_acc_tri, lw=1.8, color=M["clay"], marker="^", ms=4.8,
            markeredgecolor="white", markeredgewidth=0.8, label="Ternary")
    ax.axvline(95, ls=":", color=M["slate"], lw=1.1)
    ax.annotate("95% rule\n(1.1× only)", (95, ax.get_ylim()[0] + 0.3),
                textcoords="offset points", xytext=(8, 0), fontsize=7,
                color=M["slate"], va="bottom")
    ax.invert_xaxis()
    ax.set_xlabel("Target energy retained (%)", fontsize=8.5)
    ax.set_ylabel("Accuracy", fontsize=8.5)
    ax.grid(color=M["grid"], lw=0.7)
    ax.set_axisbelow(True)
    ax.legend(fontsize=7)
    ax.set_title("(a) Accuracy is flat long before energy is", fontsize=8.8, pad=6)

    # 右：两个准则各自能达到的压缩比
    ax = axes[1]
    labels = ["95% energy\ncriterion", "rank axis\n(measured lossless)"]
    vals = [16 / 14, 16 / 1]
    colors = [M["stone"], M["sage"]]
    bars = ax.bar(labels, vals, color=colors, width=0.5, edgecolor="white", linewidth=1.2)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.3, f"{v:.1f}×",
                ha="center", fontsize=9, color=M["ink"], fontweight="bold")
    ax.set_ylabel("Compression achieved", fontsize=8.5)
    ax.set_ylim(0, 18.5)
    ax.set_yticks([0, 4, 8, 12, 16])
    ax.grid(axis="y", color=M["grid"], lw=0.7)
    ax.set_axisbelow(True)
    ax.set_title("(b) A factor of 14 apart", fontsize=8.8, pad=6)

    fig.tight_layout(w_pad=2.2)
    save(fig, "fig4_energy_vs_rank")


# ------------------------------------------------------------
# Fig 5 · 低秩 vs 稀疏 vs 随机方向
# 用点线图不用柱状图：柱状图必须截断 y 轴才看得清差异，那是骗人的
# Dot plot, not bars: a bar chart would need a truncated y-axis, which misleads.
# ------------------------------------------------------------
def fig5():
    # 数据全部来自 2026-11-08 全量重跑（n=394 bin / n=968 tri）。
    # 图 (b) 的随机方向是 5 次抽样的 mean±sd —— 早先单次抽样看起来"反转"，
    # 复测 5 次后消失，所以这里必须画误差棒，不能再画单点。
    # All numbers from the 2026-11-08 full-partition rerun. Panel (b) shows
    # mean±s.d. over five draws; the earlier single-draw "reversal" did not replicate.
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.1))

    # ---- (a) SVD vs parameter masking ----
    ax = axes[0]
    labels = ["SVD\n16× / 7.1 MB", "mask 40%\n103 MB", "mask 60%\n69 MB", "mask 80%\n34 MB"]
    x = np.arange(len(labels))
    bin_v = [0.9898, 0.9898, 0.9898, 0.9924]
    tri_v = [0.7913, 0.7779, 0.7851, 0.7893]

    ax.plot(x, bin_v, lw=1.8, color=M["sage"], marker="o", ms=5.5,
            markeredgecolor="white", markeredgewidth=0.8, label="Binary")
    ax.plot(x, tri_v, lw=1.8, color=M["clay"], marker="^", ms=5.0,
            markeredgecolor="white", markeredgewidth=0.8, label="Ternary")
    for i, v in enumerate(bin_v):
        if i == 1:          # 0.9898 连三点相同，只标一次
            continue
        ax.annotate(f"{v:.4f}", (i, v), textcoords="offset points", xytext=(0, 8),
                    ha="center", fontsize=6.2, color=M["sage"])
    ax.annotate("0.9898 (all masks)", (1, bin_v[1]), textcoords="offset points",
                xytext=(0, 9), ha="center", fontsize=6.0, color=M["sage"])
    for i, v in enumerate(tri_v):
        ax.annotate(f"{v:.4f}", (i, v), textcoords="offset points", xytext=(0, -13),
                    ha="center", fontsize=6.2, color=M["clay"])

    ax.axvspan(-0.45, 0.45, color=M["grid"], alpha=0.55, zorder=0)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=6.6)
    ax.set_ylabel("Accuracy", fontsize=8.5)
    ax.set_ylim(0.750, 1.014)
    ax.grid(axis="y", color=M["grid"], lw=0.7)
    ax.set_axisbelow(True)
    ax.legend(fontsize=7, loc="center right")
    ax.set_title("(a) Low rank vs parameter masking", fontsize=8.8, pad=6)

    # ---- (b) SVD vs random direction, five draws ----
    ax = axes[1]
    ranks = [8, 4, 2, 1]
    svd_b = [0.9898, 0.9898, 0.9924, 0.9898]
    rnd_b = [0.9873, 0.9848, 0.9797, 0.8487]
    rnd_b_sd = [0.0018, 0.0036, 0.0100, 0.3014]
    svd_t = [0.7831, 0.7800, 0.7810, 0.7913]
    rnd_t = [0.7709, 0.7789, 0.7839, 0.6231]
    rnd_t_sd = [0.0272, 0.0575, 0.0650, 0.2134]

    ax.plot(ranks, svd_b, lw=1.7, color=M["sage"], marker="o", ms=5,
            markeredgecolor="white", markeredgewidth=0.7, label="Binary, energy-ordered")
    ax.errorbar(ranks, rnd_b, yerr=rnd_b_sd, lw=1.4, ls="--", color=M["sage"],
                marker="o", ms=4.0, mfc="white", markeredgecolor=M["sage"],
                capsize=2.5, elinewidth=0.9, label="Binary, random (5 draws)")
    ax.plot(ranks, svd_t, lw=1.7, color=M["clay"], marker="^", ms=4.8,
            markeredgecolor="white", markeredgewidth=0.7, label="Ternary, energy-ordered")
    ax.errorbar(ranks, rnd_t, yerr=rnd_t_sd, lw=1.4, ls="--", color=M["clay"],
                marker="^", ms=3.8, mfc="white", markeredgecolor=M["clay"],
                capsize=2.5, elinewidth=0.9, label="Ternary, random (5 draws)")

    ax.annotate("collapses at r=1", xy=(1, 0.62), xytext=(1.9, 0.47), fontsize=6.6,
                color=M["slate"],
                arrowprops=dict(arrowstyle="->", color=M["slate"], lw=0.8))
    ax.set_xscale("log", base=2)
    ax.set_xticks(ranks)
    ax.set_xticklabels(["8", "4", "2", "1"], fontsize=8)
    ax.set_xlabel("Rank kept", fontsize=8.5)
    ax.set_ylim(0.335, 1.035)
    ax.grid(color=M["grid"], lw=0.7)
    ax.set_axisbelow(True)
    ax.legend(fontsize=5.6, loc="lower left", ncol=2, framealpha=0.92,
              handlelength=1.6, columnspacing=0.9)
    ax.set_title("(b) Energy-ordered vs random directions", fontsize=8.8, pad=6)

    fig.tight_layout(w_pad=2.0)
    save(fig, "fig5_lowrank_vs_sparse")


def fig1():
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    fig, ax = plt.subplots(figsize=(7.4, 2.6))
    ax.set_xlim(0, 10.1)
    ax.set_ylim(0, 4.25)
    ax.axis("off")

    W, H, Y = 2.0, 1.12, 2.30
    xs = [0.30, 2.80, 5.30, 7.80]

    boxes = [
        ("Train", "QLoRA on Qwen2.5-3B\n$r$ = 16 or 64",
         "115 MB  /  456.8 MB", M["sand"]),
        ("Diagnose", "QR-core SVD of $\\Delta W$\nstable rank vs Gaussian",
         "ratio 0.15  /  0.05", M["mist"]),
        ("Truncate", "$\\Delta W_k = U_k\\Sigma_k V_k^{\\top}$\nno retraining",
         "16× by rank  ·  3.2× by energy", M["sage"]),
        ("Deploy", "$W + B'A'$\nmerged, no extra latency",
         "7.1 MB", M["clay"]),
    ]

    for x, (title, sub, num, color) in zip(xs, boxes):
        ax.add_patch(FancyBboxPatch((x, Y), W, H,
                                    boxstyle="round,pad=0.03,rounding_size=0.13",
                                    facecolor=color, edgecolor=M["ink"],
                                    lw=0.9, alpha=0.50, zorder=2))
        ax.text(x + W / 2, Y + H * 0.74, title, ha="center", va="center",
                fontsize=9.5, fontweight="bold", color=M["ink"], zorder=3)
        ax.text(x + W / 2, Y + H * 0.36, sub, ha="center", va="center",
                fontsize=6.6, color=M["ink"], zorder=3, linespacing=1.5)
        ax.text(x + W / 2, Y - 0.42, num, ha="center", va="center",
                fontsize=7.0, color=M["slate"], style="italic", zorder=3)

    for i in range(3):
        x0 = xs[i] + W + 0.03
        x1 = xs[i + 1] - 0.05
        ax.add_patch(FancyArrowPatch((x0, Y + H / 2), (x1, Y + H / 2),
                                     arrowstyle="-|>", mutation_scale=10,
                                     color=M["slate"], lw=1.1, zorder=1))

    # 顶部：论文的一句话逻辑
    ax.text(5.05, 3.92, "measure the spectrum  →  cut where nothing lives  →  ship a sixteenth",
            ha="center", va="center", fontsize=8.0, color=M["ink"], style="italic")

    # 底部：三个任务的结果
    ax.text(5.05, 0.95, "Binary:  0 of 300 predictions change   (McNemar $p$ = 1.000)",
            ha="center", va="center", fontsize=7.2, color=M["sage"])
    ax.text(5.05, 0.58, "Ternary:  +2.67 to +6.00 points,  3/3 seeds significant",
            ha="center", va="center", fontsize=7.2, color=M["clay"])

    ax.plot([2.6, 7.5], [1.22, 1.22], color=M["grid"], lw=0.9, zorder=0)

    fig.tight_layout()
    save(fig, "fig1_pipeline")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None)
    a = ap.parse_args()
    todo = {"fig1": fig1, "fig2": fig2, "fig3": fig3, "fig4": fig4, "fig5": fig5}
    print(f"rendering to {OUT}  (300 dpi, Morandi palette)")
    for k, fn in todo.items():
        if a.only and a.only != k:
            continue
        fn()
    print("done.")
