#!/usr/bin/env python3
# FinMLLM / make_rv_train_patch.py
# 从 train_sft.py 生成 rv_train_sft.py：把「数据划分种子」和「训练种子」拆开。
# Split-seed / train-seed disentanglement. Original file is NOT modified.
# Author: Raymond Xiaohu Fan
import re, sys, os

SRC = "scripts/train_sft.py"
DST = "scripts/rv_train_sft.py"

src = open(SRC, encoding="utf-8").read()
orig = src

# ---- 1) 新增 --split-seed 参数 ----
old_arg = 'ap.add_argument("--seed", type=int, default=42, help="random seed / 随机种子")'
new_arg = ('ap.add_argument("--seed", type=int, default=42, help="training seed / 训练随机种子")\n'
           '    ap.add_argument("--split-seed", type=int, default=42,\n'
           '                    help="data split seed, keep FIXED at 42 / 数据划分种子，固定 42 不要动")')
assert old_arg in src, "!! 没找到 --seed 参数行"
src = src.replace(old_arg, new_arg)

# ---- 2) load_pairs 用 split_seed，而不是训练 seed ----
old_call = "split=args.split, holdout=args.holdout, seed=args.seed)"
new_call = "split=args.split, holdout=args.holdout, seed=args.split_seed)"
assert old_call in src, "!! 没找到 load_pairs 调用"
src = src.replace(old_call, new_call)

# ---- 3) meta 里两个种子都记下来 ----
old_meta = '"seed": args.seed,'
new_meta = '"seed": args.seed, "split_seed": args.split_seed,'
if old_meta in src:
    src = src.replace(old_meta, new_meta)
else:
    print("⚠️  meta 行没找到，跳过（不影响训练）")

# ---- 4) 顶部加警示注释 ----
header = ("# ============================================================\n"
          "# AUTO-GENERATED from train_sft.py by make_rv_train_patch.py\n"
          "# 与 train_sft.py 唯一区别：划分种子固定 --split-seed（默认42），\n"
          "# 训练种子 --seed 只影响初始化与 shuffle，不影响谁是训练/测试集。\n"
          "# Only difference vs train_sft.py: split seed is fixed and separate.\n"
          "# ============================================================\n")
src = header + src

open(DST, "w", encoding="utf-8").write(src)
print(f"✅ 生成 {DST}")
print(f"   原文件 {SRC} 未改动")
