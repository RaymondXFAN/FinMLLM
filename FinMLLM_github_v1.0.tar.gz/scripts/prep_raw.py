#!/usr/bin/env python3
# ============================================================
# FinMLLM / prep_raw.py
# Convert whatever raw files landed (zip / csv / json / tar.gz) into the
# unified jsonl used by the training and evaluation pipelines.
# 把落地的原始文件（zip / csv / json / tar.gz）统一转换成 jsonl，
# 供训练与评测管线直接使用。
#
# Author : Raymond Xiaohu Fan
# Note   : Formats change, my patience doesn't. / 格式天天变，我的耐心不变。
# Updated: 2026-10-19
#
# Usage / 用法:
#   python scripts/prep_raw.py
# Output / 输出:
#   data/unified/{fpb,fiqa_sa,finqa,edgar}.jsonl
# ============================================================
import os, sys, json, glob, zipfile, tarfile, csv, io, re

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
RAW = os.path.join(ROOT, "data", "raw")
UNI = os.path.join(ROOT, "data", "unified")
os.makedirs(UNI, exist_ok=True)

def dump(name, rows):
    p = os.path.join(UNI, f"{name}.jsonl")
    with open(p, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  ✅ {name:<12}{len(rows):>7} rows -> {p}")
    return len(rows)

# ---------- FPB: zip -> Sentences_*.txt, format "sentence@label" ----------
def prep_fpb():
    """FPB official splits:
         Sentences_50Agree.txt  -> 4846 rows  (train)
         Sentences_AllAgree.txt -> 2259 rows  (test, fully agreed)
    FPB 官方口径：50Agree 用作训练（4846），AllAgree 用作测试（2259）。"""
    base = os.path.join(RAW, "fpb_files")
    zips = glob.glob(os.path.join(base, "**", "*.zip"), recursive=True)
    rows, seen = [], set()
    if zips:
        for z in zips:
            with zipfile.ZipFile(z) as zf:
                names = zf.namelist()
                jobs = [("train", [m for m in names if "50Agree" in m and m.endswith(".txt")]),
                        ("test",  [m for m in names if "AllAgree" in m and m.endswith(".txt")])]
                for split, targets in jobs:
                    for member in targets:
                        raw = zf.read(member).decode("latin-1")
                        added = 0
                        for line in raw.splitlines():
                            if "@" not in line:
                                continue
                            text, label = line.rsplit("@", 1)
                            key = (text.strip(), label.strip().lower())
                            if key in seen:
                                continue
                            seen.add(key)
                            rows.append({"id": f"fpb-{len(rows)}", "text": key[0],
                                         "label": key[1], "source": "fpb", "split": split})
                            added += 1
                        print(f"    {split}: +{added} from {os.path.basename(member)}")
    print(f"  fpb: {len(rows)} rows total")
    return dump("fpb", rows) if rows else 0

# ---------- FiQA: csv files with text + label ----------
def prep_fiqa():
    base = os.path.join(RAW, "fiqa_sa_files")
    rows = []
    for f in glob.glob(os.path.join(base, "**", "*.csv"), recursive=True):
        split = os.path.basename(f).replace(".csv", "")
        try:
            with open(f, encoding="utf-8", errors="ignore") as fh:
                sample = fh.read(4096); fh.seek(0)
                try:
                    dialect = csv.Sniffer().sniff(sample)
                except Exception:
                    dialect = csv.excel
                reader = csv.DictReader(fh, dialect=dialect)
                cols = reader.fieldnames or []
                tcol = next((c for c in cols if c.lower() in ("sentence","text","content","headline")), None)
                lcol = next((c for c in cols if c.lower() in ("label","sentiment","target","score")), None)
                if not tcol or not lcol:
                    print(f"  ⚠️  fiqa {os.path.basename(f)}: 字段不认识 {cols}")
                    continue
                for r in reader:
                    rows.append({"id": f"fiqa-{len(rows)}", "text": str(r[tcol]),
                                 "label": str(r[lcol]), "source": "fiqa_sa", "split": split})
        except Exception as e:
            print(f"  ⚠️  fiqa {f}: {type(e).__name__} {e}")
    print(f"  fiqa_sa: {len(rows)} rows")
    return dump("fiqa_sa", rows) if rows else 0

# ---------- FinQA: official GitHub json ----------
def prep_finqa():
    base = os.path.join(RAW, "finqa_files")
    rows = []
    for f in glob.glob(os.path.join(base, "**", "*.json"), recursive=True):
        split = os.path.basename(f).replace(".json", "")
        try:
            data = json.load(open(f, encoding="utf-8"))
        except Exception as e:
            print(f"  ⚠️  finqa {f}: {e}"); continue
        if not isinstance(data, list):
            continue
        for item in data:
            qa = item.get("qa") or {}
            q = qa.get("question") or item.get("question")
            a = qa.get("exe_ans") or qa.get("answer") or item.get("answer")
            if q is None:
                continue
            rows.append({"id": f"finqa-{len(rows)}", "text": f"Q: {q}\nA:",
                         "label": str(a), "source": "finqa", "split": split})
    print(f"  finqa: {len(rows)} rows")
    return dump("finqa", rows) if rows else 0

# ---------- EDGAR: per-company tar.gz of markdown filings ----------
# Business-line mapping by ticker (hand-curated, auditable).
# 按 ticker 手工映射业务线（可审计、可复现）。
TICKER_DOMAIN = {
    "JPM": "bank", "BAC": "bank", "WFC": "bank", "C": "bank", "USB": "bank", "COF": "bank",
    "AIG": "insurance", "MET": "insurance", "PRU": "insurance", "ALL": "insurance",
    "PGR": "insurance", "TRV": "insurance",
    "GS": "securities", "MS": "securities", "SCHW": "securities", "BLK": "securities",
}

def prep_edgar():
    base = os.path.join(RAW, "edgar_10k_files")
    tars = glob.glob(os.path.join(base, "**", "*_filings.tar.gz"), recursive=True)
    rows = []
    for t in tars:
        ticker = os.path.basename(t).replace("_filings.tar.gz", "")
        try:
            with tarfile.open(t, "r:gz") as tf:
                for m in tf.getmembers():
                    if not m.isfile() or m.size > 5_000_000:
                        continue
                    if not re.search(r"\.(md|txt|html?)$", m.name, re.I):
                        continue
                    fh = tf.extractfile(m)
                    if fh is None: continue
                    txt = fh.read().decode("utf-8", errors="ignore")
                    if len(txt) < 500:
                        continue
                    # Chunk long filings so a handful of documents yield usable samples.
                    # 长文档切块，让少量 filing 也能产出可用样本。
                    CH, OV = 1500, 200
                    for i in range(0, max(1, len(txt) - OV), CH - OV):
                        piece = txt[i:i + CH].strip()
                        if len(piece) < 300:
                            continue
                        rows.append({"id": f"edgar-{ticker}-{len(rows)}", "text": piece,
                                     "ticker": ticker, "domain": TICKER_DOMAIN.get(ticker.upper()),
                                     "chunk": i // (CH - OV), "source": "edgar_10k"})
        except Exception as e:
            print(f"  ⚠️  edgar {ticker}: {type(e).__name__} {e}")
    print(f"  edgar: {len(rows)} filings from {len(tars)} companies")
    return dump("edgar", rows) if rows else 0

# ---------- TFNS: plain HF dataset -> jsonl ----------
def prep_tfns():
    base = os.path.join(RAW, "tfns")
    if not os.path.isdir(base):
        print("  (no tfns dir, skip)")
        return 0
    try:
        from datasets import load_from_disk
        ds = load_from_disk(base)
    except Exception as e:
        print(f"  ⚠️  tfns load failed: {e}")
        return 0
    rows = []
    for split in ds.keys():
        d = ds[split]
        tcol = next((c for c in ("text","sentence","content") if c in d.column_names), None)
        lcol = next((c for c in ("label","sentiment","target") if c in d.column_names), None)
        if not tcol:
            print(f"  ⚠️  tfns[{split}] columns={d.column_names}")
            continue
        for i, ex in enumerate(d):
            t = str(ex[tcol]).strip()
            if len(t) < 5:
                continue
            rows.append({"id": f"tfns-{split}-{i}", "text": t,
                         "label": str(ex[lcol]) if lcol else "",
                         "source": "tfns", "split": split})
    print(f"  tfns: {len(rows)} rows")
    return dump("tfns", rows) if rows else 0


# ---------- SEC-official EDGAR (data/raw/edgar_sec/<TICKER>/*.md) ----------
def prep_edgar_sec():
    base = os.path.join(RAW, "edgar_sec")
    if not os.path.isdir(base):
        print("  (no edgar_sec dir, skip SEC source)")
        return 0
    rows = []
    for tdir in sorted(glob.glob(os.path.join(base, "*"))):
        if not os.path.isdir(tdir):
            continue
        ticker = os.path.basename(tdir).upper()
        domain = TICKER_DOMAIN.get(ticker)
        for f in sorted(glob.glob(os.path.join(tdir, "*.md"))):
            try:
                txt = open(f, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            if len(txt) < 500:
                continue
            CH, OV = 1500, 200
            for i in range(0, max(1, len(txt) - OV), CH - OV):
                piece = txt[i:i + CH].strip()
                if len(piece) < 300:
                    continue
                rows.append({"id": f"sec-{ticker}-{len(rows)}", "text": piece,
                             "ticker": ticker, "domain": domain,
                             "chunk": i // (CH - OV), "source": "edgar_sec"})
    print(f"  edgar_sec: {len(rows)} chunks from "
          f"{len(glob.glob(os.path.join(base, '*')))} companies")
    return dump("edgar_sec", rows) if rows else 0


# ---------- Split EDGAR rows into business-line files ----------
def split_domains():
    sources = [os.path.join(UNI, f) for f in ("edgar.jsonl", "edgar_sec.jsonl")]
    sources = [s for s in sources if os.path.exists(s)]
    if not sources:
        print("  ⚠️  no edgar jsonl, skip domain split")
        return 0
    dom_dir = os.path.join(ROOT, "data", "domains")
    os.makedirs(dom_dir, exist_ok=True)
    buckets = {}
    for src in sources:
        with open(src, encoding="utf-8") as f:
            for line in f:
                r = json.loads(line)
                d = r.get("domain")
                if d:
                    buckets.setdefault(d, []).append(r)
    n = 0
    for d, rows in sorted(buckets.items()):
        out = os.path.join(dom_dir, f"{d}.jsonl")
        with open(out, "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  ✅ domains/{d}.jsonl   {len(rows)} rows")
        n += len(rows)
    if not buckets:
        print("  ⚠️  no domain labels found (ticker not in TICKER_DOMAIN?)")
    return n


if __name__ == "__main__":
    print("=" * 70)
    print(" RAW -> UNIFIED JSONL / 原始数据转统一格式")
    print("=" * 70)
    total = 0
    for name, fn in [("fpb", prep_fpb), ("fiqa_sa", prep_fiqa),
                     ("finqa", prep_finqa), ("edgar", prep_edgar),
                     ("edgar_sec", prep_edgar_sec), ("tfns", prep_tfns)]:
        try:
            total += fn()
        except Exception as e:
            print(f"  ❌ {name}: {type(e).__name__}: {e}")
    print("-" * 70)
    print("-" * 70)
    print(" Domain split / 业务线拆分")
    split_domains()
    print("-" * 70)
    print(f" total rows / 总行数: {total}")
    print(" next / 下一步: python scripts/check_data.py --deep")
