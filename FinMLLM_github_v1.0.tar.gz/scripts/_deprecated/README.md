# _deprecated —— 知道为什么被弃用，比不知道更安全

> 这个目录里的脚本**不要用来出数**。放在这里是因为"删掉就没人知道我们踩过什么了"，
> 而审稿人恰恰会问"你们有没有意识到这个问题"。

---

## `eval_adapter.py` —— 不按 split 过滤（ERRATA E-02）

**问题**：`load_rows()` 从 100% 的数据里随机抽样，没有 `split="test"` 过滤。
用它评出来的数字会**同时包含了训练集**，虚高且不可比。

**症状**：换成 `eval_cloze.py` 之后同一批 adapter 的 accuracy 掉了一截。

**现在用**：`rv_eval_preds.py`（内部调 `eval_cloze.py`，强制 `split="test"`）。

---

## `rv_spectral_table3.py` —— 高斯基线写死成常数（ERRATA E-18）

**问题**：注释里写着"验证锚点：3B r=16 必须复现 stable=1.98 / **noise=13.55** / **ratio=0.15**"，
这两个数都是错的：

- `noise=13.55` 是**假设所有层 d=2048** 算出来的，但实际 MLP 层 d=11008，
  逐层算完加权均值是 **14.08**
- 因此 `ratio` 也从 `0.15` 变成 **0.141**

**另外两个问题**：
- 数值秩没有按配置秩封顶（E-17），应该 `k_eff = min(rank_int, r_cfg)`
- 没有 `d_side = max(dW.shape)`，导致 [11008, 2048] 的矩阵用错了边长

**现在用**：`spectral_table3.py`（2026-11-10 版），三处修复都在里面，
产出 `results/table3/*.json` 的那 9 行就是它算的。

---

## `verify_ternary_numbers.py` —— 已完成使命（ERRATA E-24）

它是为了查"ternary 增量到底是 +3.72 还是 +3.31"临时写的只会读的探针。

**结论已定案**：真值是 **+3.31**（b=44, c=12），`+3.72` 的来源是
`make_docx.py` 里 McNemar 表的 `c` 手写成了 **8**（实际 12），
`(44−8)/968×100 = 3.72`。已修正。

现在常驻的校验工具是 `../verify/verify_all.py`，比这个全面得多。
