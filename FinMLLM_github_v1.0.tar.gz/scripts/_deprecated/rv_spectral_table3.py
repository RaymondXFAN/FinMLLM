#!/usr/bin/env python3
# ============================================================
# FinMLLM / rv_spectral_table3.py
# 完全对齐 Table 3 的有效秩诊断：stable rank / PR / eRank / n90 / noise / ratio。
# Reproduce the Table-3 diagnostics exactly, including the Gaussian baseline.
#
# 为什么另写一个：
#   analyze_adapter_rank.py 报的是 n50/n90/n99 和 top-1 share，
#   那不是 Table 3 的指标，两者不能混着比。
#   这个脚本对每个 lora_A（形状 [r, d]）算谱统计量，再用同形状高斯矩阵做基线。
#
# Why a separate script:
#   analyze_adapter_rank.py reports n90 and top-1 share, which is a different
#   metric set. Table 3 reports stable rank, participation ratio, entropy eRank
#   and a Gaussian noise baseline. Mixing them would be a silent error.
#
# 验证锚点：3B r=16 必须复现 stable=1.98 / noise=13.55 / ratio=0.15。
# Replication anchor: 3B r=16 must give stable=1.98, noise=13.55, ratio=0.15.
#
# Author : Raymond Xiaohu Fan
# Usage:
#   python scripts/rv_spectral_table3.py --adapter ckpts_sft/fpb_r16 --tag 3b_bin_r16
# ============================================================
import os, sys, json, argparse
import numpy as np
from safetensors.torch import load_file

PROJ = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")


def metrics(sv):
    """sv: 降序奇异值数组 / singular values in descending order."""
    e = sv ** 2                     # 能量 / energy
    e_tot = e.sum()
    if e_tot <= 0:
        return None
    # stable rank = ||W||_F^2 / ||W||_2^2
    stable = float(e_tot / (sv[0] ** 2))
    # participation ratio = (sum sv)^2 / sum sv^2
    pr = float(sv.sum() ** 2 / e_tot)
    # entropy effective rank
    p = sv / sv.sum()
    p = p[p > 0]
    erank = float(np.exp(-(p * np.log(p)).sum()))
    # n90: 累计 90% 能量所需的方向数
    cum = np.cumsum(e) / e_tot
    n90 = int(np.searchsorted(cum, 0.90) + 1)
    return dict(stable=stable, pr=pr, erank=erank, n90=n90, r=len(sv))


def gaussian_noise_stable(m, n, trials=8, seed=0):
    """同形状高斯矩阵的 stable rank 经验值 / empirical baseline, same shape."""
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(trials):
        G = rng.standard_normal((m, n))
        sv = np.linalg.svd(G, compute_uv=False)   # m<=n 时只需奇异值
        vals.append((sv ** 2).sum() / sv[0] ** 2)
    return float(np.mean(vals))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--tag", default=None)
    ap.add_argument("--max-layers", type=int, default=0)
    ap.add_argument("--out-dir", default=os.path.join(PROJ, "outputs", "reports"))
    a = ap.parse_args()

    sd = load_file(os.path.join(a.adapter, "adapter_model.safetensors"))
    keys = [k for k in sd if "lora_A" in k]        # 形状 [r, d]
    if a.max_layers:
        keys = keys[:a.max_layers]
    if not keys:
        print("❌ 没找到 lora_A")
        return 2

    rows, noises = [], []
    for k in keys:
        A = sd[k].float().numpy()                  # [r, d]
        if A.shape[0] > A.shape[1]:                # 确保短边在前
            A = A.T
        sv = np.linalg.svd(A, compute_uv=False)
        m = metrics(sv)
        if m is None:
            continue
        m["noise"] = gaussian_noise_stable(A.shape[0], A.shape[1])
        m["ratio"] = m["stable"] / m["noise"]
        rows.append(m)
        noises.append(m["noise"])

    agg = {key: float(np.mean([r_[key] for r_ in rows]))
           for key in ("stable", "pr", "erank", "n90", "noise", "ratio")}

    tag = a.tag or os.path.basename(a.adapter.rstrip("/"))
    print("=" * 74)
    print(f" TABLE-3 DIAGNOSTICS  adapter={tag}")
    print(f" matrices={len(rows)}  configured r={rows[0]['r']}")
    print("=" * 74)
    print(f"{'metric':<12} {'mean':>10} {'median':>10} {'p95':>10}")
    for key in ("stable", "pr", "erank", "n90", "noise", "ratio"):
        v = np.array([r_[key] for r_ in rows])
        print(f"{key:<12} {v.mean():>10.3f} {np.median(v):>10.3f} {np.percentile(v,95):>10.3f}")
    print("-" * 74)
    print(f" stable rank 只有同形状高斯噪声的 {agg['ratio']:.3f} 倍")

    os.makedirs(a.out_dir, exist_ok=True)
    outp = os.path.join(a.out_dir, f"table3_{tag}.json")
    json.dump(dict(tag=tag, adapter=a.adapter, n_matrices=len(rows),
                   configured_rank=rows[0]["r"], aggregate=agg, per_layer=rows),
              open(outp, "w"), indent=2, ensure_ascii=False)
    print(f"💾 {outp}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
