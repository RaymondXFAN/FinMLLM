#!/usr/bin/env python3
# ============================================================
# FinMLLM / renumber_refs.py
# 把正文里的 [A1] [C3, C4] 占位符按「首次出现顺序」重编为 [1] [2, 3]。
# Renumber placeholder citations to sequential numbers by first appearance.
#
# 这活儿必须脚本干。手动数到第 30 条一定出错，然后 References 全乱。
# This has to be scripted. By the 30th entry your hand count is wrong and the
# whole reference list is off by one.
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-11-08
#
# Usage / 用法:
#   python scripts/renumber_refs.py --dry-run     # 只看映射
#   python scripts/renumber_refs.py --apply       # 写入新文件
# ============================================================
import os, re, sys, json, argparse

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
MS = os.path.join(PROJ, "12_论文正文_v1.md")
REF = os.path.join(PROJ, "08_参考文献池.md")
OUT_MS = os.path.join(PROJ, "12_论文正文_v2_numbered.md")
OUT_MAP = os.path.join(PROJ, "14_引用号映射表.md")

# 匹配 [A1] / [A1, B2] / [C3,C4]  （大小写字母+数字）
CITE = re.compile(r"\[([A-Z]\d+(?:\s*[,;]\s*[A-Z]\d+)*)\]")


def parse_pool(path):
    """从文献池 md 表格抽取条目。表头列数不统一（3/4/5 列），
    所以按 '|' 切分后按位置取，不依赖固定列数。
    Tables have 3/4/5 columns; split on '|' and take by position."""
    pool = {}
    for line in open(path, encoding="utf-8"):
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        key = cells[0]
        if not re.fullmatch(r"[A-Z]\d+", key):
            continue
        title = cells[1]
        venue = cells[2] if len(cells) > 2 else ""
        status = cells[3] if len(cells) > 3 else ""
        pool[key] = dict(title=title, venue=venue, status=status,
                         use=cells[4] if len(cells) > 4 else "")
    return pool


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    ms = open(MS, encoding="utf-8").read()
    pool = parse_pool(REF)

    # ---- 按首次出现顺序收集 ----
    order, seen = [], set()
    seq_log = []            # (position, raw_token_block, keys)
    for m in CITE.finditer(ms):
        keys = [k.strip() for k in re.split(r"[,;]", m.group(1))]
        seq_log.append((m.start(), m.group(0), keys))
        for k in keys:
            if k not in seen:
                seen.add(k)
                order.append(k)

    num = {k: i + 1 for i, k in enumerate(order)}

    print("=" * 78)
    print(f" 正文共 {len(seq_log)} 处引用，{len(order)} 条不同文献")
    print("=" * 78)
    print(f"{'序号':>4}  {'原名':>5}  文献")
    print("-" * 78)
    for k in order:
        p = pool.get(k, {})
        t = re.sub(r"\*+", "", p.get("title", "!! 文献池无此条 !!"))
        print(f"{num[k]:>4}  {k:>5}  {t[:58]}")

    missing = [k for k in order if k not in pool]
    if missing:
        print(f"\n❌ 文献池缺这些条目: {missing}")
    unused = [k for k in pool if k not in seen]
    print(f"\n文献池未引用（不进 References）: {len(unused)} 条 → {', '.join(sorted(unused))}")

    # ---- 替换 ----
    def repl(m):
        keys = [k.strip() for k in re.split(r"[,;]", m.group(1))]
        nums = sorted(num[k] for k in keys)
        return "[" + ", ".join(str(n) for n in nums) + "]"

    new = CITE.sub(repl, ms)
    print(f"\n替换完成：{len(seq_log)} 处")

    if a.apply:
        open(OUT_MS, "w", encoding="utf-8").write(new)
        # 映射表
        rows = ["# 引用号映射表（按首次出现）\n",
                "> 旧占位符 → 新编号 → 文献 → 出处\n",
                "| 新号 | 旧号 | 文献 | 出处 | 状态 |", "|---|---|---|---|---|"]
        for k in order:
            p = pool.get(k, {})
            rows.append(f"| {num[k]} | {k} | {re.sub(r'[*|]', '', p.get('title','?'))} "
                        f"| {re.sub(r'[*|]', '', p.get('venue','?'))} | {p.get('status','?')} |")
        open(OUT_MAP, "w", encoding="utf-8").write("\n".join(rows) + "\n")
        print(f"✅ 已写入 {OUT_MS}")
        print(f"✅ 已写入 {OUT_MAP}")
    else:
        print("\n（dry-run，未写文件。加 --apply 落盘）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
