#!/usr/bin/env python3
# FinMLLM / make_frl_frontmatter.py
# 生成 FRL 投稿的两份前台文件：Cover Letter 与独立的 Highlights。
# Elsevier 要求 Highlights 作为单独的可编辑文件提交，文件名要含 "highlights"，
# 所以不能只放在正文里 —— 我第一版就漏了这一点。
# Elsevier requires Highlights as a separate editable file whose name contains
# "highlights"; putting them only inside the manuscript is not enough.
# Author: Raymond Xiaohu Fan
import os
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
OUT = os.path.join(PROJ, "outputs")

def newdoc():
    d = Document()
    st = d.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(11)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.paragraph_format.space_after = Pt(0); st.paragraph_format.line_spacing = 1.15
    s = d.sections[0]
    s.left_margin = s.right_margin = Cm(2.5); s.top_margin = s.bottom_margin = Cm(2.5)
    return d

def para(d, text, size=11, bold=False, space=8, indent=False, align=None):
    p = d.add_paragraph()
    p.paragraph_format.space_after = Pt(space)
    if indent: p.paragraph_format.first_line_indent = Cm(0.75)
    if align: p.alignment = align
    r = p.add_run(text); r.bold = bold; r.font.size = Pt(size)
    r.font.name = "Times New Roman"
    return p

# ---------------- Cover Letter ----------------
d = newdoc()
para(d, "10 November 2026", size=10, space=18)
para(d, "The Editors in Chief", size=11, space=0)
para(d, "Finance Research Letters", size=11, space=18)

para(d, 'Re: submission of "Compressing financial sentiment adapters: effective rank, '
        'not spectral energy, sets the limit"', bold=True, space=14)

para(d, "Dear Editors,", space=12)
para(d, "I submit the enclosed manuscript for consideration as a research letter in Finance "
        "Research Letters. The main text is 2,077 words, within the journal's limit; there are "
        "two tables, one figure and twelve references.", space=12, indent=True)

para(d, "The paper challenges a methodological convention that the adapter-compression literature "
        "has adopted without testing. The convention is to keep the singular directions that carry "
        "95% of an update's spectral energy. Applied to LoRA adapters fine-tuned on financial text, "
        "that rule permits only 1.1-fold compression. Measuring the same spectra against a Gaussian "
        "baseline of identical shape shows that the updates occupy an effective rank of 1.98 where "
        "noise would occupy 14.08, so sixteenfold compression is available. Truncating to a sixteenth "
        "of the size changes three of 394 held-out predictions (McNemar p = 1.000) and raises accuracy "
        "on a three-class variant in every seed. The conventional criterion "
        "is wrong by a factor of fourteen, and it errs in the direction of leaving money on the table.",
     space=12, indent=True)

para(d, "This is, I believe, the kind of contribution the journal's scope invites: a challenge to an "
        "existing methodological approach, demonstrated on a setting where the answer is checkable. "
        "The result is not a better compressor but a better instrument for deciding how far to compress. "
        "The diagnostic — the ratio of an adapter's stable rank to that of a matched Gaussian matrix — "
        "predicts the cost of truncation rather than merely permitting it, and it orders three tasks "
        "correctly (0.133, 0.141, 0.163: the first gains several points at sixteenfold, the second a "
        "quarter point, the third loses 1.23). A reader holding "
        "an adapter can compute the ratio in about a minute of singular value decomposition and know, "
        "before training anything, whether a sixteenth of the update will survive.",
     space=12, indent=True)

para(d, "The paper also carries a cost argument that I hope is of use to the journal's readership. Adapter "
        "size is almost never reported in the finance literature, yet it decides which hardware tier an "
        "institution must provision. Over three years the storage saving from 16-fold compression is about "
        "seven dollars; the saving in deployment cost, once twelve adapters no longer force a move off a "
        "24 GB card, is $45,000 to $85,000 per branch. The reason to compress is the second number, and it "
        "is a step function rather than a slope.", space=12, indent=True)

para(d, "Rapid publication matters here because the rule being challenged is embedded in tooling: several "
        "open-source compression utilities default to an energy threshold, and practitioners who follow "
        "them are under-compressing by an order of magnitude without knowing it. A short, decisive "
        "correction seems better suited to a letters format than a long methodological treatment.",
     space=12, indent=True)

para(d, "The manuscript is original, has not been published elsewhere, and is not under consideration by "
        "another journal. All experiments were run by me; the adapters, the truncation script and the "
        "diagnostic are available to referees on request and will be released publicly upon acceptance. "
        "I have no conflicts of interest to declare, and no funding supported this work.",
     space=12, indent=True)

para(d, "Thank you for considering the submission.", space=14, indent=True)
para(d, "Yours sincerely,", space=16)
para(d, "Xiaohu Fan", bold=True, space=0)
para(d, "Associate Professor", size=10, space=0)
para(d, "School of Finance and Economics, Wuhan City Vocational College", size=10, space=0)
para(d, "Wuhan, Hubei, China", size=10, space=0)

cl = os.path.join(OUT, "FRL_Cover_Letter.docx"); d.save(cl)
print("✅", cl)

# ---------------- Highlights（独立文件）----------------
d2 = newdoc()
para(d2, "Highlights", bold=True, size=14, space=14)
para(d2, "Manuscript: Compressing financial sentiment adapters: effective rank, not spectral energy, "
         "sets the limit", size=10, space=4)
para(d2, "Author: Xiaohu Fan", size=10, space=14)
for h in [
    "Spectral energy is the wrong criterion for compressing financial LoRA adapters",
    "Effective rank is 1.98 against 14.08 for a matched Gaussian baseline",
    "Sixteenfold compression changes 3 of 394 predictions; McNemar p = 1.000",
    "The 95%-energy rule permits 1.1-fold where the spectrum supports sixteenfold",
    "The rank ratio predicts which financial task pays for compression",
]:
    p = d2.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.6)
    p.paragraph_format.first_line_indent = Cm(-0.35)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run("\u2022 " + h); r.font.size = Pt(11); r.font.name = "Times New Roman"
    assert len(h) <= 85, (len(h), h)

hl = os.path.join(OUT, "FRL_Highlights.docx"); d2.save(hl)
print("✅", hl)
