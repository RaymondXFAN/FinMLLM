#!/usr/bin/env python3
# ============================================================
# FinMLLM / g0_env.py
# G0 environment self-check (runs on CPU, no GPU needed).
# G0 环境自检（CPU 可跑，不需要 GPU）。
#
# Author : Raymond Xiaohu Fan
# Note   : Check the boring stuff first. / 先查最无聊的东西，往往最致命。
# Updated: 2026-10-19
# ============================================================

"""G0 · 环境自检（无卡可跑）。判定标准：全部 PASS。"""
import sys, os, importlib, json, shutil

ROOT = os.environ.get("PROJ", "/root/autodl-tmp/FinMLLM")
results = []

def check(name, fn):
    try:
        ok, msg = fn()
    except Exception as e:
        ok, msg = False, f"{type(e).__name__}: {e}"
    results.append((name, ok, msg))
    print(f"{'✅' if ok else '❌'} {name:<28} {msg}")
    return ok

def _py():
    v = sys.version_info
    return (v.major == 3 and v.minor >= 10), f"Python {v.major}.{v.minor}.{v.micro}"

def _pkg():
    # datasets is optional: the pipeline reads jsonl directly.
    # datasets 为可选项：主流程直接读 jsonl。
    need = ["torch", "transformers", "peft", "accelerate", "bitsandbytes", "scipy", "numpy", "pandas", "sklearn", "yaml"]
    optional = ["datasets"]
    # If anything is missing, print the exact fix. / 缺包时直接给修复命令。
    miss = []
    vers = []
    for m in need:
        try:
            mod = importlib.import_module(m)
            vers.append(f"{m}={getattr(mod,'__version__','?')}")
        except Exception:
            miss.append(m)
    for m in optional:
        try:
            importlib.import_module(m)
        except Exception:
            print(f"     ℹ️  optional '{m}' unavailable (not required / 非必需)")
    if miss:
        print(f"     ↳ fix / 修复: python -m pip install -U {' '.join(miss)}")
    return (len(miss) == 0), ("missing: " + ",".join(miss)) if miss else "all present"

def _torch_cuda():
    import torch
    if not torch.cuda.is_available():
        return True, "CPU only（无卡模式正常）"
    p = torch.cuda.get_device_properties(0)
    return True, f"{torch.cuda.get_device_name(0)} | {p.total_memory/1024**3:.1f}GB | {torch.cuda.device_count()} GPU(s)"

def _paths():
    # Auto-create non-critical dirs instead of failing the gate.
    # 非关键目录自动补建，而不是直接判失败。
    for d in ("code", "ckpts", "data", "outputs"):
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)
    need = ["code", "data", "ckpts", "outputs"]
    miss = [d for d in need if not os.path.isdir(os.path.join(ROOT, d))]
    return (not miss), f"root={ROOT}" + ("" if not miss else f" | missing:{miss}")

def _hf():
    hf = os.environ.get("HF_HOME", "")
    return bool(hf), f"HF_HOME={hf or '(unset)'} | endpoint={os.environ.get('HF_ENDPOINT','(default)')}"

def _disk():
    # 15 GB is plenty: QLoRA adapters are tens of MB, datasets ~20 GB, model ~6 GB.
    # 15GB 足够：QLoRA adapter 只有几十 MB，数据 ~20GB，模型 ~6GB。
    t = shutil.disk_usage(ROOT if os.path.isdir(ROOT) else "/")
    gb = t.free / 1024**3
    return gb > 10, f"free {gb:.1f} GB (threshold 10 GB)"

def _data():
    d = os.path.join(ROOT, "data")
    if not os.path.isdir(d):
        return False, "data dir missing"
    items = [x for x in os.listdir(d) if os.path.isdir(os.path.join(d, x))]
    return len(items) > 0, f"found {len(items)}: {items[:6]}"

if __name__ == "__main__":
    print("=" * 70)
    print("G0 · 环境自检")
    print("=" * 70)
    check("Python 版本", _py)
    check("依赖包", _pkg)
    check("GPU / 承载", _torch_cuda)
    check("项目目录结构", _paths)
    check("HF 缓存配置", _hf)
    check("剩余磁盘", _disk)
    check("已下载数据", _data)

    n_fail = sum(1 for _, ok, _ in results if not ok)
    print("-" * 70)
    print(f"结果：{len(results)-n_fail}/{len(results)} PASS")
    if n_fail:
        print("⚠️ 有失败项。无卡模式下『GPU 承载』不算失败；其余需修复后再往下走。")
        sys.exit(2)
    print("🎉 G0 PASS")
