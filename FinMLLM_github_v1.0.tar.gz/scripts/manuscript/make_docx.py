#!/usr/bin/env python3
# ============================================================
# FinMLLM / make_docx.py
# 把干净稿转成给导师和师兄内审的 Word：双倍行距 + 行号 + 页码 + 三线表 + 嵌图。
# Build the internal-review DOCX: double spacing, line numbers, page numbers,
# booktabs-style tables and embedded figures.
#
# 内审稿的关键不是好看，是**好批注**。行号必须连续，图不能跑到下一页，
# 表格不能跨页断成两截。这三点做到了，导师的红笔才落得下去。
# An internal review copy is not about looking pretty — it is about being easy
# to mark up. Continuous line numbers, figures that stay put, tables that do not
# split across pages. Everything else is decoration.
#
# Author : Raymond Xiaohu Fan
# Updated: 2026-11-08
# ============================================================
import os, re, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

PROJ = os.environ.get("PROJ", "/sandbox/workspace/FinMLLM")
SRC = os.path.join(PROJ, "17_论文正文_SUBMISSION.md")
REFS = os.path.join(PROJ, "15_References_Springer.md")
FIGD = os.path.join(PROJ, "outputs", "figs")
import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--mode", default="review", choices=["review", "final"],
                 help="review=双倍行距+行号；final=1.5倍行距+无行号")
_a, _ = _ap.parse_known_args()
MODE = _a.mode
_ap2 = argparse.ArgumentParser()
_ap2.add_argument("--mode", default="review")
_b, _ = _ap2.parse_known_args()

OUT = os.path.join(PROJ, "outputs",
                   "FinMLLM_manuscript_internal_review.docx" if MODE == "review"
                   else "FinMLLM_manuscript.docx")

TITLE = ("Effective Rank, Not Spectral Energy: Compressing Financial Sentiment "
         "Adapters Sixteen-Fold at No Measurable Accuracy Cost")
AUTHORS = "Xiaohu Fan"
AFFIL = ("School of Finance and Economics, Wuhan City Vocational College, "
         "Wuhan, Hubei, China")

# ---------------- 表格数据 / table data ----------------
TABLE1 = {
    "no": 1,
    "cap": "Compression–accuracy frontier on the Financial PhraseBank. Values are the reference seed "
           "(split seed 42, training seed 42); binary n = 394, ternary n = 968. Three-seed means for "
           "ranks 16 and 1 are reported in the text.",
    "head": ["Rank", "CR", "Size (MB)", "Binary acc.", "Ternary acc."],
    "rows": [
        ["16", "1×", "115.0", "0.9873", "0.7831"],
        ["8",  "2×", "57.1",  "0.9898", "0.7831"],
        ["4",  "4×", "28.5",  "0.9898", "0.7800"],
        ["2",  "8×", "14.3",  "0.9924", "0.7810"],
        ["1",  "16×", "7.1",  "0.9898", "0.8161"],
    ],
}
TABLE2 = {
    "no": 2,
    "cap": "Paired McNemar tests comparing the untruncated adapter (r = 16) with the sixteen-fold "
           "compressed one (r = 1). b counts items the uncompressed adapter gets wrong and the "
           "compressed one gets right; c counts the reverse. Δ is the compressed-minus-uncompressed "
           "difference in percentage points.",
    "head": ["Task", "n", "Seed", "b", "c", "Δ (pp)", "95% CI", "p"],
    "rows": [
        ["Binary",  "394", "42",   "2",  "1",  "+0.25", "[−0.61, +1.12]", "1.0000"],
        ["Binary",  "394", "123",  "2",  "1",  "+0.25", "[−0.61, +1.12]", "1.0000"],
        ["Binary",  "394", "2024", "3",  "2",  "+0.25", "[−0.86, +1.37]", "1.0000"],
        ["Ternary", "968", "42",   "44", "12", "+3.31", "[+1.80, +4.81]", "<0.0001***"],
        ["Ternary", "968", "123",  "37", "10", "+2.79", "[+1.41, +4.17]", "0.0001***"],
        ["Ternary", "968", "2024", "70", "9",  "+6.30", "[+4.55, +8.06]", "<0.0001***"],
    ],
}
TABLE3 = {
    "no": 3,
    "cap": "Effective rank of every trained adapter against a Gaussian baseline of identical shape. "
           "Noise is the closed-form stable rank kd/(√k+√d)² of a [k, d] Gaussian matrix, applied per "
           "layer (attention d = 2048, MLP d = 11008). Ratio is the adapter's stable rank divided by it. "
           "The FiQA row reports seed 42; seed 123 gives 2.14 and a ratio of 0.153.",
    "head": ["Model", "r", "Stable", "PR", "eRank", "n90", "Noise", "Ratio"],
    "rows": [
        ["3B binary",  "16", "1.98", "8.50",  "11.40", "6.46",  "14.08", "0.141"],
        ["3B ternary", "16", "1.86", "8.02",  "11.04", "6.02",  "14.08", "0.133"],
        ["3B FiQA",    "16", "2.28", "9.42",  "12.04", "7.40",  "14.08", "0.163"],
        ["3B binary",  "64", "2.33", "22.02", "37.06", "13.89", "50.09", "0.047"],
        ["3B ternary", "64", "2.50", "23.90", "38.42", "16.24", "50.09", "0.050"],
        ["7B binary",  "16", "1.94", "8.25",  "11.20", "6.22",  "14.51", "0.134"],
        ["7B ternary", "16", "1.74", "7.54",  "10.67", "5.42",  "14.51", "0.120"],
        ["7B binary",  "64", "2.08", "20.73", "36.46", "13.20", "52.96", "0.039"],
        ["7B ternary", "64", "1.95", "18.87", "33.98", "12.25", "52.96", "0.037"],
    ],
}
FIGURES = {
    1: ("fig1_pipeline.png",
        "Overview of the procedure. Adapters are trained on the Financial PhraseBank, the "
        "singular value spectrum of each merged update is measured, a truncation is chosen "
        "from that measurement, and the result is merged back into the base weights."),
    2: ("fig2_compression_accuracy.png",
        "The compression–accuracy frontier. Accuracy is plotted against adapter file size on a "
        "logarithmic axis; both curves are flat across the sixteen-fold range, and the ternary "
        "curve rises rather than falls."),
    3: ("fig3_effective_rank.png",
        "Effective rank against compression budget. Every trained adapter sits far below the "
        "Gaussian baseline of identical shape, and the gap widens with nominal rank."),
    4: ("fig4_energy_vs_rank.png",
        "Energy retention against the rank it would require. Reaching ninety-five per cent of "
        "the update's energy demands only a 1.1× reduction, while the measured spectrum supports 16×."),
    5: ("fig5_lowrank_vs_sparse.png",
        "Low-rank truncation against magnitude sparsity at matched compression. Sparsity "
        "preserves accuracy on the binary task but delivers a larger artifact; at the smallest "
        "budget, truncation is both smaller and more accurate on the ternary task."),
}


# ---------------- helpers ----------------
def set_base_font(doc):
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    if MODE == "review":
        pf.line_spacing_rule = WD_LINE_SPACING.DOUBLE       # 内审：双倍，方便批注
        pf.line_spacing = None
    else:
        pf.line_spacing = 1.5                                # 正式版：1.5 倍
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)


def add_line_numbers(section):
    sectPr = section._sectPr
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    ln.set(qn("w:distance"), "360")
    sectPr.append(ln)


def add_page_number(par):
    run = par.add_run()
    f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
    run._r.append(f1); run._r.append(it); run._r.append(f2)
    run.font.size = Pt(10)
    run.font.name = "Times New Roman"


def md_runs(par, text, size=12):
    """把 **粗体** / *斜体* 转成 run。Convert inline markdown to runs."""
    for tok in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", text):
        if not tok:
            continue
        if tok.startswith("**") and tok.endswith("**") and len(tok) > 4:
            r = par.add_run(tok[2:-2]); r.bold = True
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            r = par.add_run(tok[1:-1]); r.italic = True
        else:
            r = par.add_run(tok)
        r.font.size = Pt(size)
        r.font.name = "Times New Roman"


def booktabs(table):
    """三线表：顶/底 1.5pt，表头下 0.75pt，无竖线无内部横线。
    w:tblBorders 必须按 OOXML schema 顺序插入，否则 Word/LibreOffice 会静默忽略。"""
    tblPr = table._tbl.tblPr
    for e in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(e)
    borders = OxmlElement("w:tblBorders")
    for edge, sz in [("top", 12), ("bottom", 12), ("left", 0),
                     ("right", 0), ("insideH", 0), ("insideV", 0)]:
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single" if sz else "none")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        borders.append(el)
    # schema 顺序：tblBorders 必须在 shd / tblLayout / tblCellMar / tblLook 之前
    tblPr.insert_element_before(borders, "w:shd", "w:tblLayout", "w:tblCellMar",
                                "w:tblLook", "w:tblCaption", "w:tblDescription")

    # 表头下加一条细线
    for cell in table.rows[0].cells:
        tcPr = cell._tc.get_or_add_tcPr()
        for e in tcPr.findall(qn("w:tcBorders")):
            tcPr.remove(e)
        tb = OxmlElement("w:tcBorders")
        b = OxmlElement("w:bottom")
        b.set(qn("w:val"), "single"); b.set(qn("w:sz"), "6"); b.set(qn("w:color"), "000000")
        tb.append(b)
        tcPr.insert_element_before(tb, "w:shd", "w:noWrap", "w:tcMar",
                                   "w:textDirection", "w:tcFitText", "w:vAlign")


def add_table(doc, spec):
    cap = doc.add_paragraph()
    cap.paragraph_format.space_before = Pt(16)
    cap.paragraph_format.space_after = Pt(4)
    cap.paragraph_format.keep_with_next = True
    cap.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    r = cap.add_run(f"Table {spec['no']}. "); r.bold = True; r.font.size = Pt(10)
    r2 = cap.add_run(spec["cap"]); r2.font.size = Pt(10)

    t = doc.add_table(rows=1, cols=len(spec["head"]))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = True
    for i, h in enumerate(spec["head"]):
        c = t.rows[0].cells[i]
        c.text = ""
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        rr = p.add_run(h); rr.bold = True; rr.font.size = Pt(8)
        rr.font.name = "Times New Roman"
    for row in spec["rows"]:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            rr = p.add_run(v); rr.font.size = Pt(8)
            rr.font.name = "Times New Roman"
    booktabs(t)
    for row in t.rows:
        trPr = row._tr.get_or_add_trPr()
        trPr.append(OxmlElement("w:cantSplit"))
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(14)
    spacer.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE


def add_figure(doc, no):
    fn, caption = FIGURES[no]
    path = os.path.join(FIGD, fn)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.keep_together = True
    if os.path.exists(path):
        p.add_run().add_picture(path, width=Cm(14.5))
    else:
        rr = p.add_run(f"[MISSING FIGURE: {fn}]")
        rr.font.color.rgb = RGBColor(0xC0, 0, 0)

    cp = doc.add_paragraph()
    cp.paragraph_format.space_after = Pt(18)
    cp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    cp.paragraph_format.keep_together = True
    r = cp.add_run(f"Figure {no}. "); r.bold = True; r.font.size = Pt(10)
    r2 = cp.add_run(caption); r2.font.size = Pt(10)


# ---------------- build ----------------
def main():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    for attr in ("left_margin", "right_margin"):
        setattr(sec, attr, Cm(2.5))
    sec.top_margin = sec.bottom_margin = Cm(2.5)
    set_base_font(doc)
    if MODE == "review":
        add_line_numbers(sec)      # 正式版不加行号

    # 页脚页码
    fp = sec.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_page_number(fp)

    # ---- 标题区 ----
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.space_after = Pt(10)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run(TITLE); r.bold = True; r.font.size = Pt(15)

    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(AUTHORS); r.font.size = Pt(12)

    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(AFFIL); r.font.size = Pt(10); r.italic = True

    # 内审提示
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.space_after = Pt(10)
    if MODE == "review":
        r = p.add_run("Internal review draft — 10 November 2026. Line numbers are continuous "
                      "throughout for ease of comment.")
        r.font.size = Pt(9); r.italic = True
        r.font.color.rgb = RGBColor(0x60, 0x60, 0x60)
    else:
        p.paragraph_format.space_after = Pt(6)

    # ---- 正文 ----
    lines = open(SRC, encoding="utf-8").read().split("\n")
    inserted = set()
    after_abstract = [False]   # Abstract 段落之后插 Keywords

    KEYWORDS = ("Keywords: financial sentiment analysis · low-rank adaptation · "
                "model compression · effective rank · singular value decomposition · "
                "parameter-efficient fine-tuning")

    def maybe_insert(par_text):
        """在这一段之后，把首次提及的图表插进来。"""
        # 表格优先于图（正文通常先引表）
        for spec in (TABLE1, TABLE2, TABLE3):
            k = ("T", spec["no"])
            if k in inserted:
                continue
            if re.search(rf"Table\s+{spec['no']}\b", par_text):
                add_table(doc, spec); inserted.add(k)
        for no in (1, 2, 3, 4, 5):
            k = ("F", no)
            if k in inserted:
                continue
            if re.search(rf"Figure\s+{no}\b", par_text):
                add_figure(doc, no); inserted.add(k)

    i = 0
    cur_section = ""
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln.strip():
            i += 1
            continue
        if ln.startswith("# "):
            txt = ln[2:].strip()
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(16)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.keep_with_next = True
            r = p.add_run(txt); r.bold = True; r.font.size = Pt(14)
            cur_section = txt
            i += 1; continue
        if ln.startswith("## "):
            txt = ln[3:].strip()
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.keep_with_next = True
            r = p.add_run(txt); r.bold = True; r.font.size = Pt(12); r.italic = True
            i += 1; continue

        # 普通段落
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0.75)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if MODE == "final":
            p.paragraph_format.line_spacing = 1.5
        if cur_section == "Abstract":
            # 摘要用单倍行距（学术稿常规），否则双倍行距会把摘要挤到第二页
            p.paragraph_format.line_spacing = 1.15
            p.paragraph_format.space_after = Pt(8)
            p.paragraph_format.keep_together = True
        md_runs(p, ln.strip())
        maybe_insert(ln.strip())

        # Abstract 段落结束 → 补 Keywords
        if not after_abstract[0] and cur_section == "Abstract":
            kp = doc.add_paragraph()
            kp.paragraph_format.space_before = Pt(10)
            kp.paragraph_format.space_after = Pt(4)
            kp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            kr = kp.add_run(KEYWORDS)
            kr.font.size = Pt(10)
            kr.font.name = "Times New Roman"
            after_abstract[0] = True
        i += 1

    # ---- Keywords（放 Abstract 后不合适，统一放文末前）----
    # ---- References ----
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    p.paragraph_format.keep_with_next = True
    r = p.add_run("References"); r.bold = True; r.font.size = Pt(14)

    ref_text = open(REFS, encoding="utf-8").read().split("\n")
    for ln in ref_text:
        s = ln.strip()
        m = re.match(r"^(\d+)\.\s+(.*)$", s)
        if not m:
            continue
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.9)
        p.paragraph_format.first_line_indent = Cm(-0.9)
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        p.paragraph_format.space_after = Pt(4)
        md_runs(p, f"{m.group(1)}. {m.group(2)}", size=10)

    cp = doc.core_properties
    cp.title = TITLE
    cp.author = AUTHORS
    cp.subject = "Internal review draft"
    cp.keywords = "financial sentiment analysis; low-rank adaptation; effective rank"
    cp.comments = "Internal review copy, 2026-11-08"

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc.save(OUT)

    # ---- 报告 ----
    print("=" * 68)
    print(f"✅ {OUT}")
    print(f"   大小: {os.path.getsize(OUT)/1024:.0f} KB")
    print(f"   表格: {sorted(k[1] for k in inserted if k[0]=='T')}")
    print(f"   图片: {sorted(k[1] for k in inserted if k[0]=='F')}")
    miss = [f for f in FIGURES if ("F", f) not in inserted]
    if miss:
        print(f"   ⚠️ 未插入的图: {miss}")
    print("=" * 68)


if __name__ == "__main__":
    main()
