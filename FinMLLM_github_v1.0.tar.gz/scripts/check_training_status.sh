#!/usr/bin/env bash
# ============================================================
# FinMLLM / check_training_status.sh
# Forensic status check after a lid-close / SSH drop: what finished, what died,
# and what is safe to reuse without retraining.
# 合盖/断连后的现场勘查：哪些跑完了、哪些中断了、哪些可以直接复用。
#
# Author : Raymond Xiaohu Fan
# Note   : A closed lid is not a license to guess. / 合上盖子可以，但不能靠猜。
# Updated: 2026-10-23
# ============================================================
cd /root/autodl-tmp/FinMLLM 2>/dev/null || { echo "❌ 项目目录不存在"; exit 1; }
[ -f setup_env.sh ] && source setup_env.sh 2>/dev/null

echo "================================================================"
echo " TRAINING STATUS  |  $(date '+%F %T')  |  pwd=$(pwd)"
echo "================================================================"

echo ""
echo "── 1. 进程 / Processes ──────────────────────────────────────"
if ps aux | grep -E "train_domain|e0b_spectral|run_gates" | grep -v grep > /tmp/p.txt; then
  cat /tmp/p.txt | awk '{print "  PID "$2"  CPU="$3"%  MEM="$4"%  "$12" "$13" "$14" "$15}'
else
  echo "  (无相关进程 —— 任务已结束或被中断)"
fi

echo ""
echo "── 2. Adapter 完成度 / Completion ───────────────────────────"
printf "  %-26s %8s %10s %10s  %s\n" "ADAPTER" "SIZE" "WEIGHTS" "META" "VERDICT"
for d in ckpts/*_qlora_s42; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  sz=$(du -sh "$d" 2>/dev/null | cut -f1)
  w=$([ -f "$d/adapter_model.safetensors" ] && echo YES || echo NO)
  m=$([ -f "$d/train_meta.json" ] && echo YES || echo NO)
  if [ "$w" = "YES" ] && [ "$m" = "YES" ]; then v="✅ 完成"
  elif [ "$w" = "YES" ]; then v="⚠️ 有权重无meta（可用）"
  else v="❌ 未完成"; fi
  printf "  %-26s %8s %10s %10s  %s\n" "$name" "$sz" "$w" "$m" "$v"
done

echo ""
echo "── 3. 日志尾部 / Log tails ──────────────────────────────────"
for f in outputs/logs/train_*.log outputs/logs/e0b*.log; do
  [ -f "$f" ] || continue
  echo "  ▸ $(basename "$f")  ($(stat -c%s "$f" 2>/dev/null) bytes, mtime $(stat -c%y "$f" 2>/dev/null | cut -d. -f1))"
  tail -4 "$f" | sed 's/^/     /'
  echo ""
done

echo "── 4. 已有分析报告 / Reports ────────────────────────────────"
ls -lt outputs/reports/ 2>/dev/null | head -6 | sed 's/^/  /'

echo ""
echo "── 5. GPU / 磁盘 ────────────────────────────────────────────"
nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv,noheader 2>/dev/null | sed 's/^/  /'
df -h /root/autodl-tmp 2>/dev/null | tail -1 | sed 's/^/  /'

echo ""
echo "================================================================"
echo " 判读 / How to read:"
echo "   ✅ 完成        -> 直接可用，不用重跑"
echo "   ⚠️ 有权重无meta -> 可用，仅缺统计信息"
echo "   ❌ 未完成      -> 需要重跑该域"
echo "================================================================"
